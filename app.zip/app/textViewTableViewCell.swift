//
//  textViewTableViewCell.swift
//  App
//
//  Created by Shuang Wang on 12/20/14.
//  Copyright (c) 2014 Shuang Wang. All rights reserved.
//

import UIKit

class textViewTableViewCell: UITableViewCell, UITextViewDelegate {

    @IBOutlet weak var inputTextView: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        //inputTextView.delegate = self
        if (inputTextView.text == "") {
            textViewDidEndEditing(inputTextView)
        }
        //var tapDismiss = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        //self.  view.addGestureRecognizer(tapDismiss)
        
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
//    func dismissKeyboard(){
//        inputTextView.resignFirstResponder()
//    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if (textView.text == "") {
            textView.text = "Description"
            textView.textColor = UIColor.lightGrayColor()
        }
        textView.resignFirstResponder()
    }
    
//    func textViewDidBeginEditing(textView: UITextView){
//        if (textView.text == "Description"){
//            textView.text = ""
//            textView.textColor = UIColor.blackColor()
//        }
//        println("textView selected cell 1")
//        textView.becomeFirstResponder()
//    }
    
}
