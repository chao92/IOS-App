//
//  ViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.

import UIKit
import Alamofire

class loginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var usernameTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var scroller:UIScrollView!
    
    
    
    @IBAction func loginTapped(sender: AnyObject) {
        var username:String = usernameTextField.text!
        var password:String = passwordTextField.text!
        
        var saltedPW = password + saltKey
        
        let param = [
            "username" : username,
            "hash1" : saltedPW.md5(),
            "hash2" : saltedPW.sha1(),
            "hash3" : saltedPW.sha256()
        ] as [String:AnyObject]
        
        let manager = Alamofire.Manager.sharedInstance
        
        manager.delegate.sessionDidReceiveChallenge = { session, challenge in
            var disposition: NSURLSessionAuthChallengeDisposition = .PerformDefaultHandling
            var credential: NSURLCredential?
            
            if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
                disposition = NSURLSessionAuthChallengeDisposition.UseCredential
                credential = NSURLCredential(forTrust: challenge.protectionSpace.serverTrust!)
            } else {
                if challenge.previousFailureCount > 0 {
                    disposition = .CancelAuthenticationChallenge
                } else {
                    credential = manager.session.configuration.URLCredentialStorage?.defaultCredentialForProtectionSpace(challenge.protectionSpace)
                    
                    if credential != nil {
                        disposition = .UseCredential
                    }
                }
            }
            
            return (disposition, credential)
        }

        
        manager.request(.POST, "\(urlGlobalBase)jsonLogin.php", parameters: param)
            .validate()
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var dic = response.result.value as! [String: AnyObject]
                    let suc = dic["success"] as! Int
                    if(suc == 1) {
                        let userID:Int = Int(dic["ID"] as! String)!
                        let userRole:String = dic["role"] as! String
                        let emailAddr:String = dic["email"] as! String
                        let picLink:String = pv(dic["piclink"] as? String)
                        let firstName:String = pv(dic["firstName"] as? String)
                        let lastName:String = pv(dic["lastName"] as? String)
                        
                        var prefs:NSUserDefaults = NSUserDefaults.standardUserDefaults()
                        prefs.setObject(username as String, forKey: "USERNAME")
                        prefs.setObject(userID, forKey: "USERID")
                        prefs.setObject(userRole, forKey: "USERROLE")
                        prefs.setObject(firstName, forKey: "USERFIRSTNAME")
                        prefs.setObject(lastName, forKey: "USERLASTNAME")
                        prefs.setObject(emailAddr, forKey: "USEREMAIL")
                        prefs.setInteger(1, forKey: "HASLOGGEDIN")
                        prefs.setObject(saltedPW.md5(), forKey: "PWHASH1")
                        prefs.setObject(saltedPW.sha1(), forKey: "PWHASH2")
                        prefs.setObject(saltedPW.sha256(), forKey: "PWHASH3")
                        prefs.setObject(1, forKey: "ISLOGGEDIN")
                        prefs.synchronize()
                        
                        NSLog("Login SUCCESS as \(userRole)");
                        NSLog("userID: %ld", userID);
                        NSLog("userRole: %ld", userRole);
                        self.dismissViewControllerAnimated(true, completion: nil)
                    }
                    else {
                        
                        var alertView:UIAlertView = UIAlertView()
                        alertView.title = "Sign in Failed!"
                        alertView.message = "Username/Password Invalid"
                        alertView.delegate = self
                        alertView.addButtonWithTitle("OK")
                        alertView.show()
                    }
                }
                else {
                    var alertView:UIAlertView = UIAlertView()
                    alertView.title = "Sign in Failed!"
                    alertView.message = "Cannot connect to server!"
                    alertView.delegate = self
                    alertView.addButtonWithTitle("OK")
                    alertView.show()
                }
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        scroller.scrollEnabled = true;
        scroller.contentSize = CGSizeMake(320, 624);
        let defaults:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        defaults.setObject(0, forKey: "HASLOGGEDIN")
        defaults.synchronize()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
}

