//
//  homeVCViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.

import UIKit
import Alamofire

class homeViewController: UIViewController {
    
    @IBOutlet weak var usernameLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let prefs:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        prefs.setObject(0, forKey: "ISLOGGEDIN")
        prefs.synchronize()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        self.usernameLabel.text = pv(NSUserDefaults.standardUserDefaults().objectForKey("USERNAME") as? String)
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(true)
        
        let prefs:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        var isLoggedIn = prefs.objectForKey("ISLOGGEDIN") as? Int
        var userRole = prefs.objectForKey("USERROLE") as? String
        
        if(isLoggedIn == 1) { // back from login view
            if (userRole == "teacher"){
                self.performSegueWithIdentifier("goto_teacher", sender: self)
            }
            else{
                self.performSegueWithIdentifier("goto_student", sender: self)
            }
        }
        else { // when app just launched
            let hasLoggedIn:Int = prefs.integerForKey("HASLOGGEDIN") as Int
            if (hasLoggedIn == 1) { // account logged in before
                let param = [
                    "username" : pv(prefs.objectForKey("USERNAME") as? String),
                    "hash1" : pv(prefs.objectForKey("PWHASH1") as? String),
                    "hash2" : pv(prefs.objectForKey("PWHASH2") as? String),
                    "hash3" : pv(prefs.objectForKey("PWHASH3") as? String)
                    ] as [String:AnyObject]
                
                let manager = Alamofire.Manager.sharedInstance
                
                manager.delegate.sessionDidReceiveChallenge = { session, challenge in
                    var disposition: NSURLSessionAuthChallengeDisposition = .PerformDefaultHandling
                    var credential: NSURLCredential?
                    
                    if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
                        disposition = NSURLSessionAuthChallengeDisposition.UseCredential
                        credential = NSURLCredential(forTrust: challenge.protectionSpace.serverTrust!)
                    } else {
                        if challenge.previousFailureCount > 0 {
                            disposition = .CancelAuthenticationChallenge
                        } else {
                            credential = manager.session.configuration.URLCredentialStorage?.defaultCredentialForProtectionSpace(challenge.protectionSpace)
                            
                            if credential != nil {
                                disposition = .UseCredential
                            }
                        }
                    }
                    
                    return (disposition, credential)
                }
                
                
                manager.request(.POST, "\(urlGlobalBase)jsonLogin.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var dic = response.result.value as! [String: AnyObject]
                            let suc = dic["success"] as! Int
                            if(suc == 1) {
                                let userID:Int = Int(dic["ID"] as! String)!
                                let userRole:String = dic["role"] as! String
                                let emailAddr:String = dic["email"] as! String
                                let picLink:String = pv(dic["piclink"] as? String)
                                let firstName:String = pv(dic["firstName"] as? String)
                                let lastName:String = pv(dic["lastName"] as? String)
                                
                                var defaults:NSUserDefaults = NSUserDefaults.standardUserDefaults()
                                //prefs.setObject(username as String, forKey: "USERNAME")
                                defaults.setInteger(userID, forKey: "USERID")
                                defaults.setObject(userRole, forKey: "USERROLE")
                                defaults.setObject(firstName, forKey: "USERFIRSTNAME")
                                defaults.setObject(lastName, forKey: "USERLASTNAME")
                                defaults.setObject(emailAddr, forKey: "USEREMAIL")
                                defaults.setObject(1, forKey: "ISLOGGEDIN")
                                //defaults.setInteger(1, forKey: "HASLOGGEDIN")
                                defaults.synchronize()
                                
                                NSLog("Login SUCCESS as \(userRole)");
                                NSLog("userID: %ld", userID);
                                NSLog("userRole: \(userRole)");
                                if (userRole == "teacher"){
                                    self.performSegueWithIdentifier("goto_teacher", sender: self)
                                }
                                else{
                                    self.performSegueWithIdentifier("goto_student", sender: self)
                                }
                                
                            }
                            else {
                                let appDomain = NSBundle.mainBundle().bundleIdentifier
                                NSUserDefaults.standardUserDefaults().removePersistentDomainForName(appDomain!)
                                self.performSegueWithIdentifier("goto_login", sender: self)
                                var alertView:UIAlertView = UIAlertView()
                                alertView.title = "Auto Login Failed!"
                                alertView.message = "Account last time logged in changed! Please log in again"
                                //alertView.delegate = self
                                alertView.addButtonWithTitle("OK")
                                alertView.show()
                            }
                        }
                        else {
                            self.performSegueWithIdentifier("goto_login", sender: self)
                            var alertView:UIAlertView = UIAlertView()
                            alertView.title = "Sign in Failed!"
                            alertView.message = "Cannot connect to server!"
                            //alertView.delegate = self
                            alertView.addButtonWithTitle("OK")
                            alertView.show()
                        }
                }
                //self.usernameLabel.text = prefs.valueForKey("USERNAME") as NSString
            }
            else { // no account info stored
                self.performSegueWithIdentifier("goto_login", sender: self)
            }
            
        }
        
    }
    
    
    //    @IBAction func logoutTapped(sender: AnyObject) {
    //        let appDomain = NSBundle.mainBundle().bundleIdentifier
    //        NSUserDefaults.standardUserDefaults().removePersistentDomainForName(appDomain!)
    //
    //        self.performSegueWithIdentifier("goto_login", sender: self)
    //    }
    //
    //
    //    @IBAction func teacherTapped(sender: AnyObject) {
    //        self.performSegueWithIdentifier("goto_teacher", sender: self)
    //    }
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
