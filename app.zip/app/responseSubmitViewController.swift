//
//  responseSubmitViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/30/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

class responseSubmitViewController: UIViewController,UITextViewDelegate {
    
    @IBOutlet weak var responseTextView: UITextView!
    
    @IBOutlet weak var submit: UIButton!
    
    var responseText: String = ""
    var userID: String = ""
    var reportID: String = ""
    var from: String = "" // T or S stand for teacher/student
    var preResponseID: String = ""
    var reportTopic: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        submit.addTarget(self, action: "submitText:", forControlEvents: UIControlEvents.TouchUpInside)
        responseTextView.text = "your response"
        responseTextView.textColor = UIColor.lightGrayColor()
        
        // Do any additional setup after loading the view.
    }
    
    func submitText(sender:UIButton!)
    {
        self.responseText = self.responseTextView.text
        var currentDatetimeNSDate = NSDate()
        var currentDatetime = DateTimeOperation.date2String(currentDatetimeNSDate, dateFormat: "yyyy-MM-dd hh:mm:ss")
        let param = [
            "reportID" : self.reportID,
            "responsor" : self.userID,
            "description" : self.responseText,
            "responseTime" : currentDatetime,
            "preResponseID" : self.preResponseID
            ] as [String: AnyObject]
        print(param)
        sender.enabled = false
        Alamofire.request(.POST, "\(urlGlobalBase)jsonAddResponse.php", parameters: param)
            .validate()
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var res = response.result.value as! [String: AnyObject]
                    var suc = res["success"] as! Int
                    if(suc==1) {
                        self.setSelectedMenu(0)
                        var alertView:UIAlertView = UIAlertView()
                        alertView.title = "Add response success!"
                        alertView.message = "New response Added!"
                        //alertView.delegate = self
                        alertView.addButtonWithTitle("OK")
                        alertView.show()
                        self.navigationController?.presentingViewController?.dismissViewControllerAnimated(true, completion: nil)
                    }
                    else {
                        sender.enabled = true
                        var alertView:UIAlertView = UIAlertView()
                        alertView.title = "Add response failed!"
                        alertView.message = "Parameters Error, please try again"
                        //alertView.delegate = self
                        alertView.addButtonWithTitle("OK")
                        alertView.show()
                    }
                }
                else {
                    sender.enabled = true
                    var alertView:UIAlertView = UIAlertView()
                    alertView.title = "Add response failed!"
                    alertView.message = "Server side error, please try again"
                    //alertView.delegate = self
                    alertView.addButtonWithTitle("OK")
                    alertView.show()
                }
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textViewDidBeginEditing(textView: UITextView){
        textView.text = ""
    }
    func textViewDidEndEditing(textView: UITextView){
        responseText = textView.text
        print(responseText)
    }
    
    func textViewDidChange(textView: UITextView) { //Handle the text changes here
        responseText = textView.text
        //print(textView.text); //the textView parameter is the textView where text was changed
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
