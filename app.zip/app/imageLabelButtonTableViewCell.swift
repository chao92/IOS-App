//
//  imageLabelButtonTableViewCell.swift
//  App
//
//  Created by Shuang Wang on 12/23/14.
//  Copyright (c) 2014 Shuang Wang. All rights reserved.
//

import UIKit

class imageLabelButtonTableViewCell: UITableViewCell {

    @IBOutlet weak var faceImageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var actionButton: UIButton!
    @IBOutlet weak var moreInfLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
