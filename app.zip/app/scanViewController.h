//
//  ViewController.h
//  Integrity_APP
//
//  Created by chao on 2/2/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

#ifndef scanViewController_h
#define scanViewController_h

#import <ZXingObjC/ZXingObjC.h>
#include <UIKit/UIKit.h>
@interface scanViewController : UIViewController <ZXCaptureDelegate>

@end

#endif /* scanViewController.h */
