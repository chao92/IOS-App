//
//  T4ViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.

import UIKit
import MessageUI

class userHelpViewController: UIViewController, MFMailComposeViewControllerDelegate {

    @IBOutlet weak var emailButton: UIButton!
    
    @IBAction func EmailTapped(sender: AnyObject) {
        let emailTitle = "Feedback"
        let messageBody = "Feature request or bug report?"
        let toRecipents = ["help@ewtalk.com"]
        let mc: MFMailComposeViewController = MFMailComposeViewController()
        mc.mailComposeDelegate = self
        mc.setSubject(emailTitle)
        mc.setMessageBody(messageBody, isHTML: false)
        mc.setToRecipients(toRecipents)
        
        self.presentViewController(mc, animated: true, completion: nil)
    }
    
    func mailComposeController(controller:MFMailComposeViewController, didFinishWithResult result:MFMailComposeResult, error:NSError?) {
        switch result.rawValue {
        case MFMailComposeResultCancelled.rawValue:
            print("Mail cancelled")
        case MFMailComposeResultSaved.rawValue:
            print("Mail saved")
        case MFMailComposeResultSent.rawValue:
            print("Mail sent")
        case MFMailComposeResultFailed.rawValue:
            print("Mail sent failure: %@", [error!.localizedDescription])
        default:
            break
        }
        self.dismissViewControllerAnimated(true, completion: nil)    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let backButton: UIButton = UIButton(type: UIButtonType.System) as UIButton
        backButton.frame = CGRectMake(0, 0, 60, 40)
        backButton.setTitle("Home", forState: UIControlState.Normal)
        backButton.titleLabel!.font =  UIFont(name: "System", size: 17)
        backButton.addTarget(self, action: "leftNavItemClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let leftBarButtonItemBack: UIBarButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.setLeftBarButtonItem(leftBarButtonItemBack, animated: true)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    func addLeftNavItemOnView()
//    {
//        
////        let buttonEdit: UIButton = UIButton.buttonWithType(UIButtonType.System) as UIButton
////        buttonEdit.frame = CGRectMake(0, 0, 40, 40)
////        buttonEdit.setTitle("test1", forState: UIControlState.Normal)
////        //buttonEdit.setImage(UIImage(named:"edit.png"), forState: UIControlState.Normal)
////        buttonEdit.addTarget(self, action: "rightNavItemEditClick:", forControlEvents: UIControlEvents.TouchUpInside)
////        var rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
//        
//        
//        
//        let buttonMenu: UIButton = UIButton.buttonWithType(UIButtonType.Custom) as UIButton
//        buttonMenu.frame = CGRectMake(0, 0, 15, 55)
//        buttonMenu.imageView?.tintColor = UIColor.blueColor()
//        buttonMenu.setTitle("Home", forState: UIControlState.Normal)
//        buttonMenu.setImage(UIImage(named: "menu")?.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate), forState: UIControlState.Normal)
//        buttonMenu.addTarget(self, action: "leftMenuNavItemDeleteClick:", forControlEvents: UIControlEvents.TouchUpInside)
//        
//        
//        var leftBarButtonItemMenu: UIBarButtonItem = UIBarButtonItem(customView: buttonMenu)
//        
//        
//        // add multiple right bar button items    
//        //self.navigationItem.setRightBarButtonItems([rightBarButtonItemDelete, rightBarButtonItemEdit], animated: true)
//        
//        // uncomment to add single right bar button item
//        self.navigationItem.setLeftBarButtonItem(leftBarButtonItemMenu, animated: false)
//        
//    }
    
    
    func leftNavItemClick(sender:UIButton!)
    {
        setSelectedMenu(0)
    }
    
    
    @IBAction func TapDetected(sender: AnyObject) {
        self.hideSideMenuView()
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
