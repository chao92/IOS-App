//
//  userAppointmentDetailTableViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/31/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

class userAppointmentDetailTableViewController: UITableViewController {
    
    var appointmentInfCell: appointmentInf = appointmentInf()
    var sections : [tableViewSection] = []
    let statusDictionary = ["initiated": "Published", "selected" : "Reserved", "confirmed" : "Confirmed", "finished": "Finished"]
    let studentButtonDictionary = ["initiated": "", "selected" : "Confirm", "confirmed" : "Cancel", "finished": ""]
    let teacherButtonDictionary = ["initiated": "Reserve", "selected" : "Cancel", "confirmed" : "", "finished": ""]
    var userID : String = ""
    var role : String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let prefs:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        self.userID = String(prefs.integerForKey("USERID") as Int)
        print("userID:\(self.userID)")
        self.role = prefs.stringForKey("USERROLE")!
        self.title = "Appointment Details"
        
        self.navigationItem.backBarButtonItem?.title = "Cancel"
        
        if(self.role == "student" && appointmentInfCell.status != "finished") {
            let editButton: UIButton = UIButton(type: UIButtonType.System) as UIButton
            editButton.frame = CGRectMake(0, 0, 40, 40)
            editButton.setTitle("Edit", forState: UIControlState.Normal)
            editButton.titleLabel!.font =  UIFont(name: "System", size: 17)
            editButton.addTarget(self, action: "rightNavItemEditClick:", forControlEvents: UIControlEvents.TouchUpInside)
            let rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: editButton)
            self.navigationItem.setRightBarButtonItem(rightBarButtonItemEdit, animated: false)
        }
        
        initializeSession()
        
        
        
        let textFieldTableViewCellNib = UINib(nibName: "textFieldTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "textFieldTableViewCell")
        
        let dateTimePickTableViewCellNib = UINib(nibName: "imageLabelButtonTableViewCell", bundle: nil)
        tableView.registerNib(dateTimePickTableViewCellNib, forCellReuseIdentifier: "imageLabelButtonTableViewCell")
        
        let textViewTableViewCellNib = UINib(nibName: "textViewTableViewCell", bundle: nil)
        tableView.registerNib(textViewTableViewCellNib, forCellReuseIdentifier: "textViewTableViewCell")
        
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "emptyTableViewCell")
        
        // set style for tableView
        //tableView.backgroundColor = tableSeparatorLightColor;
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
        refreshControlSetup()
    }
    
    func rightNavItemEditClick(sender: UIButton!) {
    print("rightNavItemEditClick")
    let destViewController:UIViewController = UIStoryboard(name: "Main",bundle: nil).instantiateViewControllerWithIdentifier("editAppointmentViewController") as UIViewController
    (destViewController as! editAppointmentViewController).appointmentInfCell = appointmentInfCell
    self.navigationController?.pushViewController(destViewController, animated: true)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        getAppointmentInf()
    }
    
    func getAppointmentInf(){
        
        var param = ["appointID" : appointmentInfCell.appointID] as [String : AnyObject]
        print("appointID\(appointmentInfCell.appointID)")
        Alamofire.request(.POST, "\(urlGlobalBase)jsonGetAppointmentInfByID.php", parameters: param)
            .validate()
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var dic = response.result.value as! [String: AnyObject]
                    var res = dic["success"] as! Int
                    if(res == 1) { // network request success
                        self.appointmentInfCell = appointmentInf(
                            appointID:          pv(dic["appointID"] as? String),
                            proposer:           pv(dic["proposer"] as? String),
                            responsor:          pv(dic["responsor"] as? String),
                            topic:              pv(dic["topic"] as? String),
                            descriptions:       pv(dic["description"] as? String),
                            plannedStartTime:   pv(dic["plannedStartTime"] as? String),
                            plannedEndTime:     pv(dic["plannedEndTime"] as? String),
                            actualStartTime:    pv(dic["actualStartTime"] as? String),
                            actualEndTime:      pv(dic["actualEndTime"] as? String),
                            status:             pv(dic["status"] as? String),
                            sessionID:          pv(dic["sessionID"] as? String))
                        self.updateSession()
                        //self.refreshControl?.endRefreshing()
                    }
                    else {
                        self.navigationController?.dismissViewControllerAnimated(true, completion: nil)
                    }
                }
                else { // error on network connection
                    self.refreshControl?.endRefreshing()
                    var alert:UIAlertView = UIAlertView()
                    alert.title = "Network Connection Fail"
                    alert.message = "Cannot connect to the server, please try again"
                    //alert.delegate = self
                    alert.addButtonWithTitle("OK")
                    alert.show()
                }
        }
        
    }
    
    func updateSession() {
        sections[0].tableCellArray[0].cellTitle = appointmentInfCell.topic
        
        let s_time:String = DateTimeOperation.date2String(DateTimeOperation.string2Date(appointmentInfCell.plannedStartTime, dateFormat: "yyyy-MM-dd HH:mm:ss"), dateFormat: "yy-MM-dd EE hh:mm:ss a")
        let e_time:String = DateTimeOperation.date2String(DateTimeOperation.string2Date(appointmentInfCell.plannedEndTime, dateFormat: "yyyy-MM-dd HH:mm:ss"), dateFormat: "yy-MM-dd EE hh:mm:ss a")
        sections[1].tableCellArray[0].cellTitle = "Start Time: \(s_time)"
        sections[1].tableCellArray[1].cellTitle = "Start Time: \(e_time)"
        sections[1].tableCellArray[2].cellTitle = "\(statusDictionary[appointmentInfCell.status]!)     (" + (DateTimeOperation.string2Date(appointmentInfCell.plannedStartTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).inBestDifferenceString + ")"
        // student is a proposer role
        updateReservationInf(role == "student" ? appointmentInfCell.responsor : appointmentInfCell.proposer)
        
        sections[3].tableCellArray[0].cellTitle = appointmentInfCell.descriptions
    }
    
    func updateReservationInf (userID: String) {
        if(role == "student" && appointmentInfCell.responsor != "" || role == "teacher" && appointmentInfCell.proposer != "") {
            Alamofire.request(.POST, "\(urlGlobalBase)jsonGetUserInf.php", parameters: ["userID":userID] as [String: AnyObject])
                .validate()
                .responseJSON {
                    response in
                    if(response.result.isSuccess) {
                        var dic = response.result.value as! [String: AnyObject]
                        var res = dic["success"] as! Int
                        if(res == 1) {
                            var user = userInf(ID: pv(dic["ID"] as? String), username: pv(dic["username"] as? String), password: "", email: pv(dic["email"] as? String), piclink: pv(dic["piclink"] as? String), firstName: pv(dic["firstName"] as? String), lastName: pv(dic["lastName"] as? String), role: pv(dic["role"] as? String), intro: pv(dic["intro"] as? String))
                            var myImage = UIImage(named: "unknowFace")!
                            if user.ID != "" && user.piclink != "" {
                                let url = NSURL(string: "\(urlPicsBase)\(user.piclink)")
                                if let data = NSData(contentsOfURL: url!){
                                    myImage = UIImage(data: data)!
                                }
                            }
                            let buttonDictionary = self.role == "student" ? self.studentButtonDictionary : self.teacherButtonDictionary
                            var buttonTitle = buttonDictionary[self.appointmentInfCell.status]!
                            var buttonEnabled = buttonDictionary[self.appointmentInfCell.status]! != ""
                            var minuteLeft = (DateTimeOperation.string2Date(self.appointmentInfCell.plannedEndTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).minute
                            var classLen = (DateTimeOperation.string2Date(self.appointmentInfCell.plannedEndTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - DateTimeOperation.string2Date(self.appointmentInfCell.plannedStartTime, dateFormat: "yyyy-MM-dd HH:mm:ss")).minute
                            if(minuteLeft > 0 && minuteLeft < 10+classLen && self.appointmentInfCell.status == "confirmed"){
                                buttonTitle = "Start"
                                buttonEnabled = true
                            }
                            (self.sections[2].tableCellArray[0] as! imageLabelButtonTableViewCellType).myUserInf = user
                            (self.sections[2].tableCellArray[0] as! imageLabelButtonTableViewCellType).myImage = myImage
                            (self.sections[2].tableCellArray[0] as! imageLabelButtonTableViewCellType).buttonTitle = buttonTitle
                            (self.sections[2].tableCellArray[0] as! imageLabelButtonTableViewCellType).buttonEnabled = buttonEnabled
                            //self.sections[2].tableCellArray[0] = imageLabelButtonTableViewCellType(myUserInf: user, myImage: myImage, cellTitle: "\(user.firstName) \(user.lastName)", cellTableViewCellName: "imageLabelButtonTableViewCell", cellHeight: 160, buttonTitle: buttonTitle, buttonEnabled: buttonEnabled)
                            self.refreshControl?.endRefreshing()
                            self.tableView.reloadData()
                        }
                        else {
                            self.refreshControl?.endRefreshing()
                            self.tableView.reloadData()
                            print(dic["error_message"] as! String)
                        }
                    }
                    else {
                        self.refreshControl?.endRefreshing()
                        self.tableView.reloadData()
                        var alert:UIAlertView = UIAlertView()
                        alert.title = "Network Connection Fail"
                        alert.message = "Cannot retrive reservation information"
                        //alert.delegate = self
                        alert.addButtonWithTitle("OK")
                        alert.show()
                    }
            }
        }
        else {
            self.refreshControl?.endRefreshing()
            self.tableView.reloadData()
        }
    }
    
    
    func refreshControlSetup(){
        let refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: "getNewAppointment", forControlEvents:.ValueChanged)
        refreshControl.backgroundColor = UIColor.lightGrayColor();
        let currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
        refreshControl.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
        self.refreshControl = refreshControl;
    }
    
    func initializeSession(){
        // for section 0 -- Appointment topic
        let topic = appointmentInfCell.topic
        sections.append(tableViewSection(sectionTitle: "Appointment Topic", tableCellArray: [textFieldTableViewCellType(cellTitle: topic, cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44)]))
        
        // for section 1 -- Appointment information
        var status = "\(statusDictionary[appointmentInfCell.status]!)     ("
        status += (DateTimeOperation.string2Date(appointmentInfCell.plannedStartTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).inBestDifferenceString
        status += ")"
        let s_time:String = DateTimeOperation.date2String(DateTimeOperation.string2Date(appointmentInfCell.plannedStartTime, dateFormat: "yyyy-MM-dd HH:mm:ss"), dateFormat: "yy-MM-dd EE hh:mm:ss a")
        let e_time:String = DateTimeOperation.date2String(DateTimeOperation.string2Date(appointmentInfCell.plannedEndTime, dateFormat: "yyyy-MM-dd HH:mm:ss"), dateFormat: "yy-MM-dd EE hh:mm:ss a")
        sections.append(tableViewSection(sectionTitle: "Appointment status", tableCellArray: [
            textFieldTableViewCellType(cellTitle: "Start Time: \(s_time)", cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44),
            textFieldTableViewCellType(cellTitle: "End Time: \(e_time)", cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44),
            textFieldTableViewCellType(cellTitle: status, cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44),
            ]))
        
        // for Section 2 -- reservation information
        sections.append(tableViewSection(sectionTitle: "Reservation Information", tableCellArray: [imageLabelButtonTableViewCellType(myUserInf: userInf(), myImage: UIImage(named: "unknowFace")! ,cellTitle: "testTitle", cellTableViewCellName: "imageLabelButtonTableViewCell", cellHeight: 160, buttonTitle: "", buttonEnabled: false)]))
        //updateReservationInf(role == "teacher" ? classInfCell.studentID : classInfCell.teacherID)
        
        // for Section 3
        let description = appointmentInfCell.descriptions
        sections.append(tableViewSection(sectionTitle: "Description", tableCellArray: [textViewTableViewCellType(cellTitle: description, cellTableViewCellName: "textViewTableViewCell", cellHeight: 160)]))
        
    }
    
    func setTableViewCellStyle(cell: UITableViewCell){
        if cell.respondsToSelector("setSeparatorInset:") {
            cell.separatorInset.left = CGFloat(0.0)
        }
        if cell.respondsToSelector("setLayoutMargins:") {
            cell.layoutMargins.left = CGFloat(0.0)
        }
        cell.selectionStyle = UITableViewCellSelectionStyle.None
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return sections.count
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String {
        // do not display empty `Section`s
        if self.sections[section].getNumberOfCells() != 0 {
            return self.sections[section].getSectionTitle()
        }
        return ""
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return 40
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return self.sections[section].getNumberOfCells()
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if self.sections[indexPath.section].getNumberOfCells() != 0 {
            return self.sections[indexPath.section].tableCellArray[indexPath.row].cellHeight
        }else{
            return 44
        }
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: UITableViewCell
        if(self.sections[indexPath.section].getNumberOfCells() == 0){
            return tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
        }
        
        switch self.sections[indexPath.section].getTableCellTypeAtIndex(indexPath.row){
        case "textFieldTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("textFieldTableViewCell") as! textFieldTableViewCell
            var currentCell : textFieldTableViewCellType = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! textFieldTableViewCellType
            (cell as! textFieldTableViewCell).inputTextField.enabled = currentCell.textFieldEnabled
            (cell as! textFieldTableViewCell).inputTextField.text = currentCell.cellTitle
            break
        case "imageLabelButtonTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("imageLabelButtonTableViewCell") as! imageLabelButtonTableViewCell
            var currentCell : imageLabelButtonTableViewCellType = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! imageLabelButtonTableViewCellType
            print("getnamestring:\(currentCell.getNameString()) , \(currentCell.getEmailString())")
            (cell as! imageLabelButtonTableViewCell).faceImageView.image = currentCell.myImage
            (cell as! imageLabelButtonTableViewCell).nameLabel.text = currentCell.myUserInf.username//currentCell.getNameString()
            (cell as! imageLabelButtonTableViewCell).moreInfLabel.text = "\(currentCell.getEmailString())\n\n\n"
            (cell as! imageLabelButtonTableViewCell).actionButton.setTitle(currentCell.buttonTitle, forState: UIControlState.Normal)
            (cell as! imageLabelButtonTableViewCell).actionButton.enabled = currentCell.buttonEnabled
            (cell as! imageLabelButtonTableViewCell).actionButton.addTarget(self, action: "appointmentButtonTapped:", forControlEvents: UIControlEvents.TouchUpInside)
            break
        case "textViewTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("textViewTableViewCell") as! textViewTableViewCell
            var currentCell : textViewTableViewCellType = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! textViewTableViewCellType
            (cell as! textViewTableViewCell).inputTextView.editable = currentCell.textViewEditable
            (cell as! textViewTableViewCell).inputTextView.text = currentCell.cellTitle
            (cell as! textViewTableViewCell).inputTextView.textColor = UIColor.blackColor()
            break
        default:
            return tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
        }
        setTableViewCellStyle(cell)
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected section #\(indexPath.section) and cell #\(indexPath.row)")
        hideSideMenuView ()
        switch (indexPath.section) {
        case 0: // getcurrent class
            break
        case 1: // for all classes
            break
        default:
            break
        }
    }
    
    func appointmentButtonTapped(sender: UIButton!){
        print("tapped button")
        let buttonTitle = sender.titleLabel?.text
        if(role == "student"){
            switch buttonTitle! {
            case "Confirm":
                //sender.setTitle("Cancel", forState: UIControlState.Normal)
                //sql = "update classInf set status = 'confirmed' where classID = '\(classInfCell.classID)'"
                print(appointmentInfCell.appointID)
                Alamofire.request(.POST, "\(urlGlobalBase)jsonStudentUpdateAppointmentStatus.php", parameters: ["appointID":appointmentInfCell.appointID, "status":"confirmed"])
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var dic = response.result.value as! [String: AnyObject]
                            var res = dic["success"] as! Int
                            if(res == 1) {
                                self.getAppointmentInf()
                                var alert:UIAlertView = UIAlertView()
                                alert.title = "Appointment Status Updated"
                                alert.message = "Update Success!"
                                alert.addButtonWithTitle("OK")
                                alert.show()
                            }
                            else {
                                var alert:UIAlertView = UIAlertView()
                                alert.title = "Appointment Status Update Failed"
                                alert.message = "Server denied this request"
                                alert.addButtonWithTitle("OK")
                                alert.show()
                            }
                        }
                        else {
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
                break
            case "Cancel":
                //sender.setTitle("Confirm", forState: UIControlState.Normal)
                //sql = "update classInf set status = 'selected' where classID = '\(classInfCell.classID)'"
                Alamofire.request(.POST, "\(urlGlobalBase)jsonStudentUpdateAppointmentStatus.php", parameters: ["appointID":appointmentInfCell.appointID, "status":"initiated"])
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var dic = response.result.value as! [String: AnyObject]
                            var res = dic["success"] as! Int
                            if(res == 1) {
                                self.getAppointmentInf()
                                var alert:UIAlertView = UIAlertView()
                                alert.title = "Appointment Status Updated"
                                alert.message = "Update Success!"
                                alert.addButtonWithTitle("OK")
                                alert.show()
                            }
                            else {
                                var alert:UIAlertView = UIAlertView()
                                alert.title = "Appointment Status Update Failed"
                                alert.message = "Server denied this request"
                                alert.addButtonWithTitle("OK")
                                alert.show()
                            }
                        }
                        else {
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
                break
            case "Start":
                startAppointment()
                break
            default:
                break
            }
        }else{
            switch buttonTitle! {
            case "Reserve":
                //sender.setTitle("Cancel", forState: UIControlState.Normal)
                //sql = "update classInf set studentID = '\(userID)', status = 'selected' where classID = '\(classInfCell.classID)'"
                Alamofire.request(.POST, "\(urlGlobalBase)jsonTeacherUpdateAppointmentStatus.php", parameters: ["appointID": appointmentInfCell.appointID, "responsor":userID, "status": "selected"])
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var dic = response.result.value as! [String: AnyObject]
                            var res = dic["success"]as! Int
                            if(res == 1) {
                                self.getAppointmentInf()
                                var alert:UIAlertView = UIAlertView()
                                alert.title = "Appointment Status Updated"
                                alert.message = "Update Success!"
                                alert.addButtonWithTitle("OK")
                                alert.show()
                            }
                            else {
                                var alert:UIAlertView = UIAlertView()
                                alert.title = "Appointment Status Update Failed"
                                alert.message = "Server denied this request"
                                alert.addButtonWithTitle("OK")
                                alert.show()
                            }
                        }
                        else {
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
                break
                
            case "Cancel":
                //sender.setTitle("Reserve", forState: UIControlState.Normal)
                //sql = "update classInf set studentID = NULL, status = 'initiated' where classID = '\(classInfCell.classID)'"
                Alamofire.request(.POST, "\(urlGlobalBase)jsonTeacherUpdateAppointmentStatus.php", parameters: ["appointID": appointmentInfCell.appointID, "responsor":userID, "status":"initiated"])
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var dic = response.result.value as! [String: AnyObject]
                            var res = dic["success"] as! Int
                            if(res == 1) {
                                self.getAppointmentInf()
                                var alert:UIAlertView = UIAlertView()
                                alert.title = "Appointment Status Updated"
                                alert.message = "Update Success!"
                                alert.addButtonWithTitle("OK")
                                alert.show()
                            }
                            else {
                                var alert:UIAlertView = UIAlertView()
                                alert.title = "Appointment Status Update Failed"
                                alert.message = "Server denied this request"
                                alert.addButtonWithTitle("OK")
                                alert.show()
                            }
                        }
                        else {
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
                break
            case "Start":
                startAppointment()
                break
            default:
                break
            }
        }
        //        if(sql != ""){
        //            generalUpdateSql(sql)
        //        }
    }
    
    func startAppointment() {
        var secondTableViewController = videoChatViewController()
        secondTableViewController.userID = self.userID
        secondTableViewController.role = role
        secondTableViewController.appointID = appointmentInfCell.appointID
        //testing back button fail
        //navigationController?.pushViewController(secondTableViewController, animated: true)
        //secondTableViewController.mySessionID = classInfCell.sessionID
        print("startAppointment,userID:\(self.userID)")
        let param = [
            "userID" : self.userID,
            "appointID" : appointmentInfCell.appointID
            ] as [String:AnyObject]
        print("\(appointmentInfCell.appointID)and \(self.userID)")
        
        Alamofire.request(.POST, "\(urlGlobalBase)jsonQueryToken.php", parameters: param)
            .validate()
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var dic = response.result.value as! [String: AnyObject]
                    var res = dic["success"] as! Int
                    if(res == 1) {
                        secondTableViewController.myToken = dic["Token"] as! String
                        secondTableViewController.myAPIKey = dic["api_key"] as! String
                        secondTableViewController.mySessionID = self.appointmentInfCell.sessionID
                        self.navigationController?.pushViewController(secondTableViewController, animated: true)
                    }
                    else {
                        var alertView:UIAlertView = UIAlertView()
                        alertView.title = "Open Video Chat failed!"
                        alertView.message = "No valid session/token available"
                        alertView.delegate = self
                        alertView.addButtonWithTitle("OK")
                        alertView.show()
                    }
                }
                else {
                    var alertView:UIAlertView = UIAlertView()
                    alertView.title = "Open Video Chat failed!"
                    alertView.message = "Cannot connect to Server, bad network connection"
                    alertView.delegate = self
                    alertView.addButtonWithTitle("OK")
                    alertView.show()
                }
        }
    }
    
    
}
