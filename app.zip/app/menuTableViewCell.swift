//
//  menuTableViewCell.swift
//  App
//
//  Created by Shuang Wang on 12/28/15.
//  Copyright © 2015 Shuang Wang. All rights reserved.
//

import UIKit

class menuTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
