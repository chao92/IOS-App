//
//  videoChatViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
import UIKit
import OpenTok


class videoChatViewController: UIViewController, OTSessionDelegate, OTSubscriberKitDelegate, OTPublisherDelegate {
    
    var userID: String = ""
    var role: String = ""
    var appointID: String = ""
    var mySessionID: String = ""
    var myToken:String = ""
    var myAPIKey = ""

    
    var session : OTSession?
    var publisher : OTPublisher?
    var subscriber : OTSubscriber?
    var viewMode:Bool = true
    var btn1:UIButton = UIButton()
    var btn2:UIButton = UIButton()
    var btn3:UIButton = UIButton()
    var btn4:UIButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //navigationController?.navigationBar.topItem?.title = "Video Chat"
        navigationController?.navigationBar.hidden = true
        //navigationController?.navigationItem.leftBarButtonItem?.title = "back"
        let btnW1:CGFloat = 100.0
        let btnH1:CGFloat = 20.0
        btn1 = UIButton(frame:CGRectMake(10 , 10, btnW1, btnH1))
        btn1.backgroundColor = UIColor.blackColor()
        btn1.setTitle("Switch View", forState:.Normal)
        btn1.addTarget(self, action: "SwitchView:", forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(btn1)
        self.view.bringSubviewToFront(btn1)
        
        let btnW2:CGFloat = 60.0
        let btnH2:CGFloat = 60.0
//        var btn2 = UIButton(frame:CGRectMake(self.view.bounds.width-btnW2-10, 10, btnW2, btnH2))
//        btn2.backgroundColor = UIColor.blackColor()
//        btn2.setTitle("Mute", forState:.Normal)
//        btn2.addTarget(self, action: "MuteVoice", forControlEvents: UIControlEvents.TouchUpInside)
//        self.view.addSubview(btn2)
//        self.view.bringSubviewToFront(btn2)
        btn2 = ShutupButton(frame: CGRectMake(self.view.bounds.width-btnW2-10, 30, btnW2, btnH2))
        btn2.addTarget(self, action: "MuteVoice:", forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(btn2)
        self.view.bringSubviewToFront(btn2)
        
        let btnW3:CGFloat = 60.0
        let btnH3:CGFloat = 20.0
        btn3 = UIButton(frame:CGRectMake(self.view.bounds.width/2, 10, btnW3, btnH3))
        btn3.backgroundColor = UIColor.blackColor()
        btn3.setTitle("Pause", forState:.Normal)
        btn3.addTarget(self, action: "PauseVideo:", forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(btn3)
        self.view.bringSubviewToFront(btn3)
        
        let btnW4:CGFloat = 50.0
        let btnH4:CGFloat = 20.0
        btn4 = UIButton(frame:CGRectMake(self.view.bounds.width-btnW4-10, self.view.bounds.height-btnH4-10, btnW4, btnH4))
        btn4.backgroundColor = UIColor.blackColor()
        btn4.setTitle("BACK", forState:.Normal)
        btn4.addTarget(self, action: "BACK", forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(btn4)
        self.view.bringSubviewToFront(btn4)
        
        session = OTSession(apiKey: myAPIKey, sessionId: mySessionID, delegate: self)
        doConnect()

    }
    
    
    override func viewWillAppear(animated: Bool) {
        
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
    
    // MARK: - OpenTok Methods
    
    /**
    * Asynchronously begins the session connect process. Some time later, we will
    * expect a delegate method to call us back with the results of this action.
    */
    func doConnect() {
        if let session = self.session {
            var maybeError : OTError?
            session.connectWithToken(myToken, error: &maybeError)
            if let error = maybeError {
                showAlert(error.localizedDescription)
            }
        }
    }
    
    /**
    * Sets up an instance of OTPublisher to use with this session. OTPubilsher
    * binds to the device camera and microphone, and will provide A/V streams
    * to the OpenTok session.
    */
    func doPublish() {
        publisher = OTPublisher(delegate: self)
        
        var maybeError : OTError?
        session?.publish(publisher, error: &maybeError)
        
        if let error = maybeError {
            showAlert(error.localizedDescription)
        }
        
        if publisher != nil {
            let h = self.view.bounds.height*0.2
            let w = self.view.bounds.width*0.2
            publisher!.view.frame = CGRect(x:0, y: (self.view.bounds.height - h), width:w, height:h)
            self.view.addSubview(publisher!.view)
            self.view.bringSubviewToFront(publisher!.view)
        }
        
        
        
    }
    
    /**
    * Instantiates a subscriber for the given stream and asynchronously begins the
    * process to begin receiving A/V content for this stream. Unlike doPublish,
    * this method does not add the subscriber to the view hierarchy. Instead, we
    * add the subscriber only after it has connected and begins receiving data.
    */
    func doSubscribe(stream : OTStream) {
        if let session = self.session {
            subscriber = OTSubscriber(stream: stream, delegate: self)
            
            var maybeError : OTError?
            session.subscribe(subscriber, error: &maybeError)
            if let error = maybeError {
                showAlert(error.localizedDescription)
            }
        }
    }
    
    /**
    * Cleans the subscriber from the view hierarchy, if any.
    */
    func doUnsubscribe() {
        if let subscriber = self.subscriber {
            var maybeError : OTError?
            session?.unsubscribe(subscriber, error: &maybeError)
            if let error = maybeError {
                showAlert(error.localizedDescription)
            }
            
            subscriber.view.removeFromSuperview()
            self.subscriber = nil
        }
    }
    
    func SwitchView(sender:UIButton!)
    {
        if publisher != nil && subscriber != nil {
            if viewMode {
                publisher!.view.removeFromSuperview()
                subscriber!.view.removeFromSuperview()
                
                publisher!.view.frame = self.view.bounds
                self.view.addSubview(publisher!.view)
                self.view.sendSubviewToBack(publisher!.view)
                
                let h = self.view.bounds.height*0.2
                let w = self.view.bounds.width*0.2
                subscriber!.view.frame = CGRect(x:0, y: (self.view.bounds.height - h), width:w, height:h)
                self.view.addSubview(subscriber!.view)
                self.view.bringSubviewToFront(subscriber!.view)
                
                viewMode = false
            }
            else {
                publisher!.view.removeFromSuperview()
                subscriber!.view.removeFromSuperview()
                
                let h = self.view.bounds.height*0.2
                let w = self.view.bounds.width*0.2
                publisher!.view.frame = CGRect(x:0, y: (self.view.bounds.height - h), width:w, height:h)
                self.view.addSubview(publisher!.view)
                self.view.bringSubviewToFront(publisher!.view)
                
                subscriber!.view.frame = self.view.bounds
                self.view.addSubview(subscriber!.view)
                self.view.sendSubviewToBack(subscriber!.view)
                
                viewMode = true
            }
        }
    }
    
    func MuteVoice(sender:UIButton!)
    {
        if subscriber != nil {
            subscriber!.subscribeToAudio = !(subscriber!.subscribeToAudio)
        }
        (btn2 as! ShutupButton).mute = !(btn2 as! ShutupButton).mute
    }
    
    func PauseVideo(sender:UIButton!) {
        if publisher != nil {
            publisher!.publishVideo = !(publisher!.publishVideo)
            publisher!.publishAudio = !(publisher!.publishAudio)
        }
    }
    
    func BACK() {
        //isNavigationHidden = !isNavigationHidden
        //self.performSegueWithIdentifier("goto_classdetail", sender: self)
        //navigationController?.navigationBar.hidden = isNavigationHidden
        setSelectedMenu(0)
        self.dismissViewControllerAnimated(false, completion: nil)
    }
    
    // MARK: - OTSession delegate callbacks
    
    func sessionDidConnect(session: OTSession) {
        NSLog("sessionDidConnect (\(session.sessionId))")
        doPublish()
    }
    
    func sessionDidDisconnect(session : OTSession) {
        NSLog("Session disconnected (\( session.sessionId))")
    }
    
    func session(session: OTSession, streamCreated stream: OTStream) {
        NSLog("session streamCreated (\(stream.streamId))")
        doSubscribe(stream)
    }
    
    func session(session: OTSession, streamDestroyed stream: OTStream) {
        NSLog("session streamDestroyed (\(stream.streamId))")
        
        if subscriber?.stream.streamId == stream.streamId {
            doUnsubscribe()
        }
    }
    
    func session(session: OTSession, connectionCreated connection : OTConnection) {
        NSLog("session connectionCreated (\(connection.connectionId))")
    }
    
    func session(session: OTSession, connectionDestroyed connection : OTConnection) {
        NSLog("session connectionDestroyed (\(connection.connectionId))")
    }
    
    func session(session: OTSession, didFailWithError error: OTError) {
        NSLog("session didFailWithError (%@)", error)
    }
    
    // MARK: - OTSubscriber delegate callbacks
    
    func subscriberDidConnectToStream(subscriberKit: OTSubscriberKit) {
        NSLog("subscriberDidConnectToStream (\(subscriberKit))")
        if subscriber != nil {
            subscriber!.view.frame = self.view.bounds
            self.view.addSubview(subscriber!.view)
            self.view.sendSubviewToBack(subscriber!.view)
        }
    }
    
    func subscriber(subscriber: OTSubscriberKit, didFailWithError error : OTError) {
        NSLog("subscriber %@ didFailWithError %@", subscriber.stream.streamId, error)
    }
    
    // MARK: - OTPublisher delegate callbacks
    
    func publisher(publisher: OTPublisherKit, streamCreated stream: OTStream) {
        NSLog("publisher streamCreated %@", stream)
        
        //doSubscribe(stream)
    }
    
    func publisher(publisher: OTPublisherKit, streamDestroyed stream: OTStream) {
        NSLog("publisher streamDestroyed %@", stream)
        
        if subscriber?.stream.streamId == stream.streamId {
            doUnsubscribe()
        }
    }
    
    func publisher(publisher: OTPublisherKit, didFailWithError error: OTError) {
        NSLog("publisher didFailWithError %@", error)
    }
    
    // MARK: - Helpers
    
    func showAlert(message: String) {
        // show alertview on main UI
        dispatch_async(dispatch_get_main_queue()) {
            let al = UIAlertView(title: "OTError", message: message, delegate: nil, cancelButtonTitle: "OK")
        }
    }
    
}

