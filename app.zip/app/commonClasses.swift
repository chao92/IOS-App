//
//  classInf.swift
//  App
//
//  Created by Shuang Wang on 12/22/14.
//  Copyright (c) 2014 Shuang Wang. All rights reserved.
//


// The class for classInf
import UIKit

let urlGlobalBase = "https://app1.ucsd-dbmi.org/app/"
let urlPicsBase = "http://app1.ucsd-dbmi.org/app/uploads/"
let saltKey:String = "EChatApp@UCSD"

class userInf : NSObject{
    var ID       : String = ""
    var username : String = ""
    var password : String = ""
    var email    : String = ""
    var piclink  : String = ""
    var firstName: String = ""
    var lastName : String = ""
    var role     : String = ""
    var intro    : String = ""
    
    init(ID: String, username : String, password: String, email : String, piclink : String, firstName : String, lastName : String, role : String, intro : String){
        self.ID = ID
        self.username = username
        self.email = email
        self.password = password
        self.piclink = piclink
        self.firstName = firstName
        self.lastName = lastName
        self.role = role
        self.intro = intro
    }
    init(ID: String, username : String, password: String, email : String, piclink : String, firstName : String, lastName : String, role : String){
        self.ID = ID
        self.username = username
        self.email = email
        self.password = password
        self.piclink = piclink
        self.firstName = firstName
        self.lastName = lastName
        self.role = role
        self.intro = ""
    }
    override init(){
        
    }
}

//MARK: Report
class reportInf : NSObject {
    var reportID      : String = ""
    var reportor      : String = ""
    var topic         : String = ""
    var descriptions  : String = ""
    var piclink       : String = ""
    var reportTime    : String = ""
    var status        : String = ""
    
    init(reportID: String, reportor: String, topic: String, descriptions: String, piclink: String, reportTime: String, status: String) {
        self.reportID = reportID
        self.reportor = reportor
        self.topic = topic
        self.descriptions = descriptions
        self.piclink    = piclink
        self.reportTime = reportTime
        self.status = status
        
    }
    
    init(userID: String, topic: String){
        self.reportor = userID
        self.topic = topic
    }
    
    override init(){
        
    }
}

class additionalReportInf : NSObject {
    var imageName : String = ""
    var imageTintColor : UIColor = UIColor.blueColor()
    init(imageName : String, imageTintColor: UIColor){
        self.imageName = imageName
        self.imageTintColor = imageTintColor
    }
}

func getAdditionalReportInf(reportInfArray : [reportInf]) -> [additionalReportInf] {
    var additionalReportInfArray : [additionalReportInf] = [];
    if(reportInfArray.count > 0){
        for index in 0...reportInfArray.count-1{
            switch (reportInfArray[index].status){
            case "initiated":
                additionalReportInfArray.append(additionalReportInf(imageName: reportStatusType.initiated.imageName, imageTintColor: reportStatusType.initiated.color))
            case "replied":
                additionalReportInfArray.append(additionalReportInf(imageName: reportStatusType.replied.imageName, imageTintColor: reportStatusType.replied.color))
            case "finished":
                additionalReportInfArray.append(additionalReportInf(imageName: reportStatusType.finished.imageName, imageTintColor: reportStatusType.finished.color))
            case "allReports":
                additionalReportInfArray.append(additionalReportInf(imageName: reportStatusType.allReports.imageName, imageTintColor: reportStatusType.allReports.color))
            default:
                break;
            }
        }
    }
    return additionalReportInfArray
}

class reportListTableViewSection {
    
    var sectionTitle: String
    var reportInfArray: [reportInf] = []
    var additionalReportInfArray: [additionalReportInf] = []
    
    init(sectionTitle: String) {
        self.sectionTitle = sectionTitle
    }
    
    func addReportInf(cell: reportInf){
        reportInfArray.append(cell)
    }
    
    func addAdditionalReportInf(cell: additionalReportInf){
        additionalReportInfArray.append(cell)
    }
    
    func getSectionTitle() ->String{
        return sectionTitle;
    }
    
    func setSectionTitle(sectionTitle: String) {
        self.sectionTitle = sectionTitle
    }
    
    func getReportInfAtIndex(index: Int) ->reportInf {
        return reportInfArray[index]
    }
    func getNumberOfReportInf() -> Int{
        return reportInfArray.count
    }
    
    func getAdditionalReportInfAtIndex(index: Int) ->additionalReportInf {
        return additionalReportInfArray[index]
    }
    func getNumberOfAddtionalReportInf() -> Int{
        return additionalReportInfArray.count
    }
}

//MARK: Appointment
class appointmentInf : NSObject {
    var appointID           : String = ""
    var proposer            : String = ""
    var responsor           : String = ""
    var topic               : String = ""
    var descriptions        : String = ""
    var plannedStartTime    : String = ""
    var plannedEndTime      : String = ""
    var actualStartTime     : String = ""
    var actualEndTime       : String = ""
    var status              : String = ""
    var sessionID           : String = ""
    
    init(appointID: String, proposer: String, responsor: String, topic: String, descriptions: String, plannedStartTime: String, plannedEndTime: String, actualStartTime: String,actualEndTime: String, status: String, sessionID: String ) {
        self.appointID = appointID
        self.proposer = proposer
        self.responsor = responsor
        self.topic = topic
        self.descriptions = descriptions
        self.plannedStartTime = plannedStartTime
        self.plannedEndTime = plannedEndTime
        self.actualStartTime = actualStartTime
        self.actualEndTime = actualEndTime
        self.status = status
        self.sessionID = sessionID
        
    }
    
    init(userID: String, topic: String){
    self.proposer = userID
    self.topic = topic
    }
    
    override init(){
        
    }
}

class additionalAppointmentInf : NSObject {
    var imageName : String = ""
    var imageTintColor : UIColor = UIColor.blueColor()
    init(imageName : String, imageTintColor: UIColor){
        self.imageName = imageName
        self.imageTintColor = imageTintColor
    }
}

func getAdditionalAppointmentInf(appointmentInfArray : [appointmentInf]) -> [additionalAppointmentInf] {
    var additionalAppointmentInfArray : [additionalAppointmentInf] = [];
    if(appointmentInfArray.count > 0){
        for index in 0...appointmentInfArray.count-1{
            switch (appointmentInfArray[index].status){
            case "initiated":
                additionalAppointmentInfArray.append(additionalAppointmentInf(imageName: appointmentStatusType.initiated.imageName, imageTintColor: appointmentStatusType.initiated.color))
            case "selected":
                additionalAppointmentInfArray.append(additionalAppointmentInf(imageName: appointmentStatusType.selected.imageName, imageTintColor: appointmentStatusType.selected.color))
            case "confirmed":
                additionalAppointmentInfArray.append(additionalAppointmentInf(imageName: appointmentStatusType.confirmed.imageName, imageTintColor: appointmentStatusType.confirmed.color))
            case "archived":
                additionalAppointmentInfArray.append(additionalAppointmentInf(imageName: appointmentStatusType.finished.imageName, imageTintColor: appointmentStatusType.finished.color))
            case "allAppointments":
                additionalAppointmentInfArray.append(additionalAppointmentInf(imageName: appointmentStatusType.allAppointments.imageName, imageTintColor: appointmentStatusType.allAppointments.color))
            default:
                break;
            }
        }
    }
    return additionalAppointmentInfArray
}

class appointmentListTableViewSection {
    
    var sectionTitle: String
    var appointmentInfArray: [appointmentInf] = []
    var additionalAppointmentInfArray: [additionalAppointmentInf] = []
    
    init(sectionTitle: String) {
        self.sectionTitle = sectionTitle
    }
    
    func addAppointmentInf(cell: appointmentInf){
        appointmentInfArray.append(cell)
    }
    
    func addAdditionalAppointmentInf(cell: additionalAppointmentInf){
        additionalAppointmentInfArray.append(cell)
    }
    
    func getSectionTitle() ->String{
        return sectionTitle;
    }
    
    func setSectionTitle(sectionTitle: String) {
        self.sectionTitle = sectionTitle
    }
    
    func getAppointmentInfAtIndex(index: Int) ->appointmentInf {
        return appointmentInfArray[index]
    }
    func getNumberOfAppointmentInf() -> Int{
        return appointmentInfArray.count
    }
    
    func getAdditionalAppointmentInfAtIndex(index: Int) ->additionalAppointmentInf {
        return additionalAppointmentInfArray[index]
    }
    func getNumberOfAddtionalAppointmentInf() -> Int{
        return additionalAppointmentInfArray.count
    }
    
}


//MARK: Response
class responseInf : NSObject {
    var responseID           : String = ""
    var reportID             : String = ""
    var responsor            : String = ""
    var descriptions         : String = ""
    var responseTime         : String = ""
    var preResponseID        : String = ""
    
    init(responseID: String, reportID: String, responsor: String, descriptions: String, responseTime: String, preResponseID: String) {
        self.responseID = responseID
        self.reportID = reportID
        self.responsor = responsor
        self.descriptions = descriptions
        self.responseTime = responseTime
        self.preResponseID = preResponseID
    }
    
    init(responseID: String, descriptions: String){
        self.responseID = responseID
        self.descriptions = descriptions
    }
    
    override init(){
        
    }
}

class additionalResponseInf : NSObject {
    var imageName : String = ""
    var imageTintColor : UIColor = UIColor.blueColor()
    init(imageName : String, imageTintColor: UIColor){
        self.imageName = imageName
        self.imageTintColor = imageTintColor
    }
}
/*
func getAdditionalResponseInf(responseInfArray : [responseInf]) -> [additionalResponseInf] {
    var additionalResponseInfArray : [additionalResponseInf] = [];
    if(responseInfArray.count > 0){
        for index in 0...responseInfArray.count-1{
            switch (appointmentInfArray[index].status){
            case "initiated":
                additionalResponseInfArray.append(additionalResponseInf(imageName: appointmentStatusType.initiated.imageName, imageTintColor: appointmentStatusType.initiated.color))
            case "selected":
                additionalResponseInfArray.append(additionalResponseInf(imageName: appointmentStatusType.selected.imageName, imageTintColor: appointmentStatusType.selected.color))
            case "confirmed":
                additionalResponseInfArray.append(additionalResponseInf(imageName: appointmentStatusType.confirmed.imageName, imageTintColor: appointmentStatusType.confirmed.color))
            case "archived":
                additionalResponseInfArray.append(additionalResponseInf(imageName: appointmentStatusType.finished.imageName, imageTintColor: appointmentStatusType.finished.color))
            case "allAppointments":
                additionalResponseInfArray.append(additionalResponseInf(imageName: appointmentStatusType.allAppointments.imageName, imageTintColor: appointmentStatusType.allAppointments.color))
            default:
                break;
            }
        }
    }
    return additionalAppointmentInfArray
}
*/
class responseListTableViewSection {
    
    var sectionTitle: String
    var responseInfArray: [responseInf] = []
    //var additionalAppointmentInfArray: [additionalAppointmentInf] = []
    
    init(sectionTitle: String) {
        self.sectionTitle = sectionTitle
    }
    
    func addResponseInf(cell: responseInf){
        responseInfArray.append(cell)
    }
    
    func getSectionTitle() ->String{
        return sectionTitle;
    }
    
    func getResponseInfAtIndex(index: Int) ->responseInf {
        return responseInfArray[index]
    }
    
    func setSectionTitle(sectionTitle: String) {
        self.sectionTitle = sectionTitle
    }
    
    func getNumberOfResponsementInf() -> Int{
        return responseInfArray.count
    }
}


//MARK: Token
class tokenInf : NSObject{
    var token:String = ""
    var userID:String = ""
    var classID:String = ""
    init(token:String, userID:String, classID:String){
        self.token = token
        self.userID = userID
        self.classID = classID
    }
    
}

class tableCell {
    var cellTitle : String = ""
    var cellTableViewCellName : String = ""
    var cellHeight : CGFloat = 44
}

class imageLabelButtonTableViewCellType : tableCell {
    var myImage: UIImage = UIImage(named: "unknowFace")!
    var myUserInf: userInf = userInf()
    var buttonTitle : String = "Confirmed"
    var buttonEnabled : Bool = false
    init(myUserInf: userInf, myImage: UIImage, cellTitle : String, cellTableViewCellName : String, cellHeight : CGFloat, buttonTitle: String, buttonEnabled: Bool){
        super.init()
        self.myUserInf = myUserInf
        self.cellHeight = cellHeight
        self.cellTableViewCellName = cellTableViewCellName
        self.cellTitle = cellTitle
        self.myImage = myImage
        self.buttonEnabled = buttonEnabled
        self.buttonTitle = buttonTitle
    }
    override init(){
        
    }
    
    func getNameString() -> String{
        
        if(myUserInf.ID == ""){
            return "Not Available"
        }else{
            let res:String = "\(myUserInf.firstName) \(myUserInf.lastName)"
            return res
        }
        
    }
    
    func getEmailString() -> String{
        return myUserInf.ID == "" ? "" : myUserInf.email
    }
}
class imageCollectionViewCellType : tableCell {
    
    init(cellTitle : String, cellTableViewCellName : String, cellHeight : CGFloat){
        super.init()
        self.cellHeight = cellHeight
        self.cellTableViewCellName = cellTableViewCellName
        self.cellTitle = cellTitle
    }
    override init(){
        
    }
}


class textViewTableViewCellType : tableCell {
    
    var textViewEditable = false
    init(cellTitle : String, cellTableViewCellName : String, cellHeight : CGFloat){
        super.init()
        self.cellHeight = cellHeight
        self.cellTableViewCellName = cellTableViewCellName
        self.cellTitle = cellTitle
    }
    override init(){
        
    }
}

class textFieldTableViewCellType : tableCell {
    var textFieldEnabled = false
    init(cellTitle : String, cellTableViewCellName : String, cellHeight : CGFloat){
        super.init()
        self.cellHeight = cellHeight
        self.cellTableViewCellName = cellTableViewCellName
        self.cellTitle = cellTitle
    }
    override init(){
        
    }
}

class tableViewSection{
    var sectionTitle: String = ""
    var tableCellArray : [tableCell] = [];
    
    init(sectionTitle: String, tableCellArray : [tableCell]){
        self.tableCellArray = tableCellArray
        self.sectionTitle = sectionTitle
    }
    func getSectionTitle()->String{
        return sectionTitle
    }
    func getNumberOfCells() -> Int{
        return tableCellArray.count
    }
    
    func getTableCellAtIndex(index : Int) -> tableCell{
        return tableCellArray[index]
    }
    
    func getTableCellTypeAtIndex(index : Int) -> String {
        return tableCellArray[index].cellTableViewCellName
    }
    
    func appendTableCellArray(currentCell: tableCell){
        tableCellArray.append(currentCell)
    }
}

extension UIColor {
    convenience init(rgba: String) {
        var red:   CGFloat = 0.0
        var green: CGFloat = 0.0
        var blue:  CGFloat = 0.0
        var alpha: CGFloat = 1.0
        
        if rgba.hasPrefix("#") {
            let index   = rgba.startIndex.advancedBy(1)
            let hex     = rgba.substringFromIndex(index)
            let scanner = NSScanner(string: hex)
            var hexValue: CUnsignedLongLong = 0
            if scanner.scanHexLongLong(&hexValue) {
                switch (hex.characters.count) {
                case 3:
                    red   = CGFloat((hexValue & 0xF00) >> 8)       / 15.0
                    green = CGFloat((hexValue & 0x0F0) >> 4)       / 15.0
                    blue  = CGFloat(hexValue & 0x00F)              / 15.0
                    break
                case 4:
                    red   = CGFloat((hexValue & 0xF000) >> 12)     / 15.0
                    green = CGFloat((hexValue & 0x0F00) >> 8)      / 15.0
                    blue  = CGFloat((hexValue & 0x00F0) >> 4)      / 15.0
                    alpha = CGFloat(hexValue & 0x000F)             / 15.0
                    break
                case 6:
                    red   = CGFloat((hexValue & 0xFF0000) >> 16)   / 255.0
                    green = CGFloat((hexValue & 0x00FF00) >> 8)    / 255.0
                    blue  = CGFloat(hexValue & 0x0000FF)           / 255.0
                    break
                case 8:
                    red   = CGFloat((hexValue & 0xFF000000) >> 24) / 255.0
                    green = CGFloat((hexValue & 0x00FF0000) >> 16) / 255.0
                    blue  = CGFloat((hexValue & 0x0000FF00) >> 8)  / 255.0
                    alpha = CGFloat(hexValue & 0x000000FF)         / 255.0
                    break
                default:
                    print("Invalid RGB string, number of characters after '#' should be either 3, 4, 6 or 8", terminator: "")
                    break
                }
            } else {
                print("Scan hex error")
            }
        } else {
            print("Invalid RGB string, missing '#' as prefix", terminator: "")
        }
        self.init(red:red, green:green, blue:blue, alpha:alpha)
    }
}

func pv(input : AnyObject?) -> String{
    let output = input as? String
    return output == nil ? "" : output!
}

extension String {
    func md5() -> String! {
        let str = self.cStringUsingEncoding(NSUTF8StringEncoding)
        let strLen = CUnsignedInt(self.lengthOfBytesUsingEncoding(NSUTF8StringEncoding))
        let digestLen = Int(CC_MD5_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<CUnsignedChar>.alloc(digestLen)
        
        CC_MD5(str!, strLen, result)
        
        var hash = NSMutableString()
        for i in 0..<digestLen {
            hash.appendFormat("%02x", result[i])
        }
        
        result.destroy()
        
        return String(format: hash as String)
    }
    
    func sha1() -> String! {
        let str = self.cStringUsingEncoding(NSUTF8StringEncoding)
        let strLen = CUnsignedInt(self.lengthOfBytesUsingEncoding(NSUTF8StringEncoding))
        let digestLen = Int(CC_SHA1_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<CUnsignedChar>.alloc(digestLen)
        
        CC_SHA1(str!, strLen, result)
        
        var hash = NSMutableString()
        for i in 0..<digestLen {
            hash.appendFormat("%02x", result[i])
        }
        
        result.destroy()
        
        return String(format: hash as String)
    }
    
    
    func sha256() -> String! {
        let str = self.cStringUsingEncoding(NSUTF8StringEncoding)
        let strLen = CUnsignedInt(self.lengthOfBytesUsingEncoding(NSUTF8StringEncoding))
        let digestLen = Int(CC_SHA256_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<CUnsignedChar>.alloc(digestLen)
        
        CC_SHA256(str!, strLen, result)
        
        var hash = NSMutableString()
        for i in 0..<digestLen {
            hash.appendFormat("%02x", result[i])
        }
        
        result.destroy()
        
        return String(format: hash as String)
    }
}