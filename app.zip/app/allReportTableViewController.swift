//
//  allReportTableViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/30/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

class allReportTableViewController: UITableViewController {
    
    var reportInfArray: [reportInf] = []
    var additionalReportInfArray: [additionalReportInf] = []
    //var sqlCondition:String = ""
    var role: String = ""
    var viewMode: Int = -1  // 0 for unprocessed reprot; 1 for finished report; 2 for all report
    var userID:String = ""
    var reportStatus:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let textFieldTableViewCellNib = UINib(nibName: "imageLabelTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "imageLabelTableViewCell")
        
        // Do any additional setup after loading the view.
        
        // set style for tableView
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
        refreshControlSetup()
    }
    
    func refreshControlSetup(){
        let refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: "getNewClass", forControlEvents:.ValueChanged)
        refreshControl.backgroundColor = UIColor.lightGrayColor();
        self.refreshControl = refreshControl;
    }
    
    override func viewDidAppear(animated: Bool) {
        getReportInf()
    }
    
    func getReportInf(){ // for refreshing
        
        self.refreshControl?.beginRefreshing()
        
        let currentTime = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd HH:mm:ss")
        let param = [
            "role" : self.role,
            "userID" : self.userID,
            "status" : self.reportStatus,
            "time" : currentTime
            ] as [String:AnyObject]
        
        if(role == "teacher" || role == "student") {
            if(viewMode == 1) {//whatever the user is teacher or student, return all finished reports.
                Alamofire.request(.POST, "\(urlGlobalBase)jsonGetFinishedReports.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var reports = response.result.value as! [[String:AnyObject]]
                            self.reportInfArray.removeAll(keepCapacity: false)
                            for elem:[String:AnyObject] in reports {
                                self.reportInfArray.append(reportInf(reportID: pv(elem["reportID"] as? String), reportor: pv(elem["reportor"] as? String), topic: pv(elem["topic"] as? String), descriptions: pv(elem["description"] as? String), piclink: pv(elem["piclink"] as? String), reportTime: pv(elem["reportTime"] as? String), status: pv(elem["status"] as? String)))
                            }
                            self.additionalReportInfArray = getAdditionalReportInf(self.reportInfArray)
                            // self.sections[0].additionalClassInfArray = getAdditionalClassInf(self.sections[0].classInfArray)
                            var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss")
                            self.refreshControl?.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                            self.refreshControl?.endRefreshing()
                            self.tableView.reloadData()

                        }
                        else {
                            self.refreshControl?.endRefreshing()
                            var alertView:UIAlertView = UIAlertView()
                            alertView.title = "Request upcoming classes failed!"
                            alertView.message = "Cannot get access to server"
                            alertView.delegate = self
                            alertView.addButtonWithTitle("OK")
                            alertView.show()
                        }
                }
            }
            else if(viewMode == 0) {
                Alamofire.request(.POST, "\(urlGlobalBase)jsonGetUnprocessedReports.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var reports = response.result.value as! [[String:AnyObject]]
                            self.reportInfArray.removeAll(keepCapacity: false)
                            for elem:[String:AnyObject] in reports {
                                self.reportInfArray.append(reportInf(reportID: pv(elem["reportID"] as? String), reportor: pv(elem["reportor"] as? String), topic: pv(elem["topic"] as? String), descriptions: pv(elem["description"] as? String), piclink: pv(elem["piclink"] as? String), reportTime: pv(elem["reportTime"] as? String), status: pv(elem["status"] as? String)))
                            }
                            self.additionalReportInfArray = getAdditionalReportInf(self.reportInfArray)
                            // self.sections[0].additionalClassInfArray = getAdditionalClassInf(self.sections[0].classInfArray)
                            var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss")
                            self.refreshControl?.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                            self.refreshControl?.endRefreshing()
                            self.tableView.reloadData()
                            
                        }
                        else {
                            self.refreshControl?.endRefreshing()
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            //alert.delegate = self
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
                
            }
            else if(viewMode == 2) {
                Alamofire.request(.POST, "\(urlGlobalBase)jsonGetReplied.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var reports = response.result.value as! [[String:AnyObject]]
                            self.reportInfArray.removeAll(keepCapacity: false)
                            for elem:[String:AnyObject] in reports {
                                self.reportInfArray.append(reportInf(reportID: pv(elem["reportID"] as? String), reportor: pv(elem["reportor"] as? String), topic: pv(elem["topic"] as? String), descriptions: pv(elem["description"] as? String), piclink: pv(elem["piclink"] as? String), reportTime: pv(elem["reportTime"] as? String), status: pv(elem["status"] as? String)))
                            }
                            self.additionalReportInfArray = getAdditionalReportInf(self.reportInfArray)
                            // self.sections[0].additionalClassInfArray = getAdditionalClassInf(self.sections[0].classInfArray)
                            var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss")
                            self.refreshControl?.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                            self.refreshControl?.endRefreshing()
                            self.tableView.reloadData()
                            
                        }
                        else {
                            self.refreshControl?.endRefreshing()
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            //alert.delegate = self
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
                
            }

                
            else if(viewMode == 3) {
                Alamofire.request(.POST, "\(urlGlobalBase)jsonGetAllReports.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var reports = response.result.value as! [[String:AnyObject]]
                            self.reportInfArray.removeAll(keepCapacity: false)
                            for elem:[String:AnyObject] in reports {
                                self.reportInfArray.append(reportInf(reportID: pv(elem["reportID"] as? String), reportor: pv(elem["reportor"] as? String), topic: pv(elem["topic"] as? String), descriptions: pv(elem["description"] as? String), piclink: pv(elem["piclink"] as? String), reportTime: pv(elem["reportTime"] as? String), status: pv(elem["status"] as? String)))
                            }
                            self.additionalReportInfArray = getAdditionalReportInf(self.reportInfArray)
                            // self.sections[0].additionalClassInfArray = getAdditionalClassInf(self.sections[0].classInfArray)
                            var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss")
                            self.refreshControl?.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                            self.refreshControl?.endRefreshing()
                            self.tableView.reloadData()

                        }
                        else {
                            self.refreshControl?.endRefreshing()
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            //alert.delegate = self
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
                
            }
            else {
                self.refreshControl?.endRefreshing()
                NSLog("viewMode Error")
            }
        }
        else {
            NSLog("role Error")
        }
        
        //classInfArray = jsonGetClassesByConditions("\(sqlCondition)")
        //additionalClassInfArray = getAdditionalClassInf(classInfArray)
        //self.tableView.reloadData()
        //self.refreshControl?.endRefreshing()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return self.reportInfArray.count
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 44
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var currentReportInf = self.reportInfArray[indexPath.row]
        var currentAdditionalReportInf = additionalReportInfArray[indexPath.row]
        
        var cell:imageLabelTableViewCell = tableView.dequeueReusableCellWithIdentifier("imageLabelTableViewCell") as! imageLabelTableViewCell
        cell.statusImageView.image = UIImage(named: currentAdditionalReportInf.imageName)?.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate);
        cell.statusImageView.tintColor = currentAdditionalReportInf.imageTintColor
        cell.titleLabel.text = currentReportInf.topic
        cell.timeLabel.text = (DateTimeOperation.string2Date(currentReportInf.reportTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).inBestDifferenceString
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected section #\(indexPath.section) and cell #\(indexPath.row)")
        hideSideMenuView ()
        switch (indexPath.section) {
        case 0: // getcurrent class
            let secondTableViewController = userReportDetialTableViewController()
            navigationController?.pushViewController(secondTableViewController, animated: true )
            secondTableViewController.reportInfCell = reportInfArray[indexPath.row]
            secondTableViewController.title = reportInfArray[indexPath.row].topic
        default:
            break
        }
    }
    
}
