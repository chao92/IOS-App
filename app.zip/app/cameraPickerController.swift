//
//  cameraPickerController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.

import UIKit
import MobileCoreServices

/**
 *
 */
class CameraPickerController: UIViewController,
UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    /* We will use this variable to determine if the viewDidAppear:
    method of our view controller is already called or not. If not, we will
    display the camera view */
    var beenHereBefore = false
    var controller: UIImagePickerController?
    
    var onDataAvailable : ((data: String) -> ())?
    
    func sendData(data: String) {
        // Whenever you want to send data back to viewController1, check
        // if the closure is implemented and then call it if it is
        self.onDataAvailable?(data: data)
    }
    
//    func imageWasSavedSuccessfully(image: UIImage,
//        didFinishSavingWithError error: NSError!,
//        context: UnsafeMutablePointer<()>){
//            
//            if let theError = error{
//                println("An error happened while saving the image = \(theError)")
//            } else {
//                println("Image was saved successfully")
//            }
//    }
    
    func randomStringWithLength (len : Int) -> NSString {
    
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        
        let randomString : NSMutableString = NSMutableString(capacity: len)
        
        for (var i=0; i < len; i++){
        let length = UInt32 (letters.length)
        let rand = arc4random_uniform(length)
        randomString.appendFormat("%C", letters.characterAtIndex(Int(rand)))
        }
        
        return randomString
    }
    
    func imagePickerController(picker: UIImagePickerController!,
        didFinishPickingMediaWithInfo info: [String : AnyObject]!){
            
            var rName: String
            
            print("Picker returned successfully")
            
            let mediaType:AnyObject? = info[UIImagePickerControllerMediaType]
            
            if let type:AnyObject = mediaType{
                
                if type is String{
                    let stringType = type as! String
                    
                    if stringType == kUTTypeImage as NSString{
                        
                        var theImage: UIImage!
                        
                        if picker.allowsEditing{
                            theImage = info[UIImagePickerControllerEditedImage] as! UIImage
                        } else {
                            theImage = info[UIImagePickerControllerOriginalImage] as! UIImage
                        }
                        
                        theImage = RBResizeImage(theImage, targetSize: CGSize(width: 400,height: 400))
                       // var img = UIImage(CGImage: theImage.CGImage, scale: 1.0, orientation: .UpMirrored)
////                      solution 1

                        var url = NSURL(string: "http://app1.ucsd-dbmi.org/app/uploadImage.php")
                        var request = NSMutableURLRequest(URL: url!)
                        request.HTTPMethod = "POST"
                        request.HTTPShouldHandleCookies = false
                        request.timeoutInterval = 30
                        
                        let boundary = "----------SwIfTeRhTtPrEqUeStBoUnDaRy"
                        let contentType = "multipart/form-data; boundary=\(boundary)"
                        request.setValue(contentType, forHTTPHeaderField:"Content-Type")
                        var body = NSMutableData();
                        let tempData = NSMutableData()

                        let rString = randomStringWithLength(8) as String
                        rName = rString + ".jpg"
                        
                        print(rName)
                        
                        let fileName = rName
                        let parameterName = "input"
                        
                       
                        let mimeType = "image/jpeg"
                       
                        tempData.appendData("--\(boundary)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                        let fileNameContentDisposition = (!fileName.isEmpty) ? "filename=\"\(fileName)\"" : ""
                        let contentDisposition = "Content-Disposition: form-data; name=\"\(parameterName)\"; \(fileNameContentDisposition)\r\n"
                        tempData.appendData(contentDisposition.dataUsingEncoding(NSUTF8StringEncoding)!)
                        tempData.appendData("Content-Type: \(mimeType)\r\n\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                        
                        tempData.appendData(NSData(data: UIImageJPEGRepresentation(theImage,0.5)!))
                        tempData.appendData("\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                        body.appendData(tempData)
                        
                        body.appendData("\r\n--\(boundary)--\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                        
                        request.setValue("\(body.length)", forHTTPHeaderField: "Content-Length")
                        request.HTTPBody = body
                        
                        
                        var response: AutoreleasingUnsafeMutablePointer<NSURLResponse?>=nil
                        var error: AutoreleasingUnsafeMutablePointer<NSErrorPointer?> = nil
                        
                        do{
                            var dataVal: NSData = try NSURLConnection.sendSynchronousRequest(request, returningResponse: response)
                            let result = NSString(data:dataVal, encoding:NSUTF8StringEncoding)
                            print("Synchronous result? \(result)")
                        } catch (let e)
                        {
                            print(e)
                        }
                        
                        //                        var jsonResult: NSDictionary = NSJSONSerialization.JSONObjectWithData(dataVal, options: NSJSONReadingOptions.MutableContainers, error: nil) as NSDictionary
                        //                        if (error != nil) {
                        //                            println("Request didn't go through")
                        //                        }
                        //                        println("Synchronous result? \(jsonResult)")
                                                
//                        self.sendData("http://app.ucsd-dbmi.org/app/uploads/"+fileName)
                      
                        
                        self.sendData(rName)
                        
                    }
                }
            }
         
            picker.presentingViewController?.presentingViewController?.dismissViewControllerAnimated(true, completion: {})
    }
    
    
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController){
        print("Picker was cancelled")
        picker.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    func isCameraAvailable() -> Bool{
        return UIImagePickerController.isSourceTypeAvailable(.Camera)
    }
    
    func cameraSupportsMedia(mediaType: String,
        sourceType: UIImagePickerControllerSourceType) -> Bool{
            
            let availableMediaTypes =
            UIImagePickerController.availableMediaTypesForSourceType(sourceType) as
                [String]?
            
            if let types = availableMediaTypes{
                for type in types{
                    if type == mediaType{
                        return true
                    }
                }
            }
            
            return false
    }
    
    func doesCameraSupportTakingPhotos() -> Bool{
        return cameraSupportsMedia(kUTTypeImage as NSString as String, sourceType: .Camera)
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        if beenHereBefore{
            /* Only display the picker once as the viewDidAppear: method gets
            called whenever the view of our view controller gets displayed */
            return
        } else {
            beenHereBefore = true
        }
        
        if isCameraAvailable() && doesCameraSupportTakingPhotos(){
            
            controller = UIImagePickerController()
            
            if let theController = controller{
                theController.sourceType = .Camera
                theController.cameraDevice = .Front
                theController.cameraViewTransform = CGAffineTransformScale(theController.cameraViewTransform, -1, 1)
                
                theController.mediaTypes = [kUTTypeImage as NSString as String]
                
                theController.allowsEditing = true
                theController.delegate = self
                
                presentViewController(theController, animated: true, completion: nil)
            }
            
        } else {
            print("Camera is not available")
        }
        
    }
    
}

