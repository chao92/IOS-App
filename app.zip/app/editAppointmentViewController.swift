//
//  editAppointmentViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/31/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

enum studentEditAppointmentControlerTypes {
    case tableViewCellCombo(type:String, name:String, height:Int, selectedHeight:Int)
    static let allValues = [("spaceSeparator", "", 15, 15),
        ("textFieldTableViewCell", "Topic", 44, 44),
        ("spaceSeparator", "", 25, 25),
        ("dateTimePickTableViewCell", "Starts", 44, 250),
        ("spaceSeparator", "", 10, 10),
        ("dateTimePickTableViewCell", "Ends", 44, 250),
        ("spaceSeparator", "", 25, 25),
        ("textViewTableViewCell", "Description", 160, 160),
        ("spaceSeparator", "", 25, 25),
        ("deleteButtonViewCell", "", 50, 50),
        ("spaceSeparator", "", 25, 25)]
}

class editAppointmentViewController: UIViewController,UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UITextViewDelegate {
    
    var selectedCellIndexPath: NSIndexPath?
    var appointmentInfCell = appointmentInf()
    var isEmptyDescriptionTextview = true
    
    @IBOutlet var tableView: UITableView!
    
    
    let tableSeparatorLightColor:UIColor = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1.0)
    var isScollTableNeeded: Bool? = false
    
    func findIndexPathByName(name: String) ->Int{
        for index in 0...studentEditAppointmentControlerTypes.allValues.count-1{
            if(studentEditAppointmentControlerTypes.allValues[index].1 == name){
                return index
            }
        }
        return -1 //NSIndexPath(forRow: -1, inSection: 0)
    }
    
    func findtableViewCellByName(name: String) ->UITableViewCell{
        let index = findIndexPathByName(name);
        return tableView.cellForRowAtIndexPath(NSIndexPath(forRow: index, inSection: 0))!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addRightNavItemOnView()
        // Do any additional setup after loading the view.
        
        // register customized Nib for tableViewCell
        let textFieldTableViewCellNib = UINib(nibName: "textFieldTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "textFieldTableViewCell")
        
        let dateTimePickTableViewCellNib = UINib(nibName: "dateTimePickTableViewCell", bundle: nil)
        tableView.registerNib(dateTimePickTableViewCellNib, forCellReuseIdentifier: "dateTimePickTableViewCell")
        
        let textViewTableViewCellNib = UINib(nibName: "textViewTableViewCell", bundle: nil)
        tableView.registerNib(textViewTableViewCellNib, forCellReuseIdentifier: "textViewTableViewCell")
        
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "emptyTableViewCell")
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "deleteButtonViewCell")
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        tableView.backgroundColor = tableSeparatorLightColor;
        // Do any additional setup after loading the view.
        
        // set style for tableView
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero

    }
    
    override func viewWillAppear(animated: Bool) {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillShow:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillHide:", name: UIKeyboardWillHideNotification, object: nil)
    }
    
    override func viewWillDisappear(animated: Bool) {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    func addRightNavItemOnView()
    {
        let buttonEdit: UIButton = UIButton(type: UIButtonType.System) as UIButton
        buttonEdit.frame = CGRectMake(0, 0, 60, 40)
        buttonEdit.setTitle("Done", forState: UIControlState.Normal)
        buttonEdit.titleLabel!.font =  UIFont(name: "System", size: 17)
        buttonEdit.addTarget(self, action: "rightNavItemDoneClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        self.navigationItem.setRightBarButtonItem(rightBarButtonItemEdit, animated: false)
    }
    
    func rightNavItemDoneClick(sender:UIButton!)
    {
        print("rightNavItemDoneClick")
        let confirmView = UIAlertView()
        confirmView.title = "NOTICE!"
        confirmView.message = "Edit appointment information will cancel the reservation which has been made, do you still want to continue?"
        confirmView.addButtonWithTitle("YES")
        confirmView.addButtonWithTitle("NO")
        confirmView.tag = 1
        confirmView.cancelButtonIndex = 1
        confirmView.delegate = self
        confirmView.show()
        
    }
    
    func alertView(alertView:UIAlertView, clickedButtonAtIndex buttonIndex: Int){
        if(buttonIndex==alertView.cancelButtonIndex) {
            print("Press NO")
        }
        else
        {
            print("Press YES")
            if(alertView.tag == 1) {
                var topic:NSString = (findtableViewCellByName("Topic") as! textFieldTableViewCell).inputTextField.text! as NSString
                var plannedStartDatetime:NSString = (findtableViewCellByName("Starts") as! dateTimePickTableViewCell).dateTimeLabel.text! as NSString
                var plannedEndDatetime:NSString = (findtableViewCellByName("Ends") as! dateTimePickTableViewCell).dateTimeLabel.text! as NSString
                var description:NSString = (findtableViewCellByName("Description") as! textViewTableViewCell).inputTextView.text as NSString
                
                if (topic == "" || description == "") {
                    print("topic is empty")
                    var alertView:UIAlertView = UIAlertView()
                    alertView.title = "Update appointment failed!"
                    alertView.message = "Please provide both topic and description"
                    //alertView.delegate = self
                    alertView.addButtonWithTitle("OK")
                    alertView.show()
                }
                else {
                    var plannedStartDatetimeNSDate = DateTimeOperation.string2Date(plannedStartDatetime as String, dateStyle: .MediumStyle, timeStyle: .ShortStyle)
                    var plannedEndDatetimeNSDate = DateTimeOperation.string2Date(plannedEndDatetime as String, dateStyle: .MediumStyle, timeStyle: .ShortStyle)
                    var formatedPlannedStartDatetime = DateTimeOperation.date2String(plannedStartDatetimeNSDate, dateFormat: "yyyy-MM-dd HH:mm:ss")
                    var formatedPlannedEndDatetime = DateTimeOperation.date2String(plannedEndDatetimeNSDate, dateFormat: "yyyy-MM-dd HH:mm:ss")
                    var currentDatetimeNSDate = NSDate()
                    //var currentDatetime = DateTimeOperation.date2String(currentDatetimeNSDate, dateFormat: "yyyy-MM-dd hh:mm:ss")
                    
                    if(plannedStartDatetimeNSDate.compare(plannedEndDatetimeNSDate) == NSComparisonResult.OrderedDescending || plannedStartDatetimeNSDate.compare(currentDatetimeNSDate) == NSComparisonResult.OrderedAscending) {
                        print("plannedStartTimeNSDate after plannedEndTimeNSDate OR plannedStartTimeNSDate after currentTimeNSDate")
                        var alertView:UIAlertView = UIAlertView()
                        alertView.title = "Update appointment failed!"
                        alertView.message = "Please make sure the start/end time is valid"
                        //alertView.delegate = self
                        alertView.addButtonWithTitle("OK")
                        alertView.show()
                    }
                    else {
                        let param = [
                            "appointID" : appointmentInfCell.appointID,
                            "topic" : topic,
                            "plannedStartDatetime" : formatedPlannedStartDatetime,
                            "plannedEndDatetime" : formatedPlannedEndDatetime,
                            "description" : description,
                            "proposer" : String(NSUserDefaults.standardUserDefaults().integerForKey("USERID")),
                            ] as [String: AnyObject]
                        
                        self.navigationItem.rightBarButtonItem?.enabled = false
                        Alamofire.request(.POST, "\(urlGlobalBase)jsonEditAppointment.php", parameters: param)
                            .validate()
                            .responseJSON {
                                response in
                                if(response.result.isSuccess) {
                                    var res = response.result.value as! [String:AnyObject]
                                    var suc = res["success"] as! Int
                                    if(suc==1) {
                                        self.navigationController?.popViewControllerAnimated(true)
                                        var alertView:UIAlertView = UIAlertView()
                                        alertView.title = "Edit Appointment Inf success!"
                                        alertView.message = "Appointment information updated!"
                                        //alertView.delegate = self
                                        alertView.addButtonWithTitle("OK")
                                        alertView.show()
                                    }
                                    else {
                                        self.navigationItem.rightBarButtonItem?.enabled = true
                                        var alertView:UIAlertView = UIAlertView()
                                        alertView.title = "Update Appointment failed!"
                                        alertView.message = "Parameters Error, please try again"
                                        //alertView.delegate = self
                                        alertView.addButtonWithTitle("OK")
                                        alertView.show()
                                    }
                                }
                                else {
                                    self.navigationItem.rightBarButtonItem?.enabled = true
                                    var alertView:UIAlertView = UIAlertView()
                                    alertView.title = "Update Appointment failed!"
                                    alertView.message = "Server side error, please try again"
                                    //alertView.delegate = self
                                    alertView.addButtonWithTitle("OK")
                                    alertView.show()
                                }
                        }
                        
                        
                    }
                }
            }
            if(alertView.tag == 2) {
                let param = [
                    "appointID" : appointmentInfCell.appointID,
                    "proposer" : String(NSUserDefaults.standardUserDefaults().integerForKey("USERID")),
                    ] as [String: AnyObject]
                
                Alamofire.request(.POST, "\(urlGlobalBase)jsonDeleteAppointment.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var res = response.result.value as! [String:AnyObject]
                            var suc = res["success"] as! Int
                            if(suc==1) {
                                self.navigationController?.popViewControllerAnimated(true)
                                var alertView:UIAlertView = UIAlertView()
                                alertView.title = "Delete Appointment Success!"
                                alertView.message = "Appointment Deleted!"
                                alertView.addButtonWithTitle("OK")
                                alertView.show()
                            }
                            else {
                                var alertView:UIAlertView = UIAlertView()
                                alertView.title = "Update Appointment failed!"
                                alertView.message = "Parameters Error, please try again"
                                //alertView.delegate = self
                                alertView.addButtonWithTitle("OK")
                                alertView.show()
                            }
                        }
                        else {
                            var alertView:UIAlertView = UIAlertView()
                            alertView.title = "Update Appointment failed!"
                            alertView.message = "Server side error, please try again"
                            //alertView.delegate = self
                            alertView.addButtonWithTitle("OK")
                            alertView.show()
                        }
                }
                
            }
            
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return studentEditAppointmentControlerTypes.allValues.count
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let (cellType, cellName, height, selectedHeight): (String, String, Int, Int) = studentEditAppointmentControlerTypes.allValues[indexPath.row]
        var cell:UITableViewCell
        switch (cellType){
        case "textFieldTableViewCell" :
            cell = tableView.dequeueReusableCellWithIdentifier("textFieldTableViewCell") as! textFieldTableViewCell
            (cell as! textFieldTableViewCell).inputTextField.placeholder = cellName
            (cell as! textFieldTableViewCell).inputTextField.delegate = self;
            (cell as! textFieldTableViewCell).layoutMargins = UIEdgeInsetsZero;
            (cell as! textFieldTableViewCell).inputTextField.text = appointmentInfCell.topic
            
        case "dateTimePickTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("dateTimePickTableViewCell") as! dateTimePickTableViewCell
            (cell as! dateTimePickTableViewCell).nameLabel.text = cellName
            var datetimeString: String
            if(cellName == "Ends"){
                datetimeString = DateTimeOperation.date2String(DateTimeOperation.addHours(NSDate(), additionalHours: 1), dateFormat: "MMM dd, YYYY hh:mm a")
                (cell as! dateTimePickTableViewCell).dateTimePicker.minimumDate = NSDate()
                (cell as! dateTimePickTableViewCell).dateTimeLabel.text = DateTimeOperation.date2String(DateTimeOperation.string2Date(appointmentInfCell.plannedEndTime, dateFormat: "yyyy-MM-dd HH:mm:ss"), dateFormat: "MMM dd, YYYY hh:mm a")
            }
            else {
                datetimeString = DateTimeOperation.date2String(NSDate(), dateFormat: "MMM dd, YYYY hh:mm a")
                (cell as! dateTimePickTableViewCell).dateTimePicker.minimumDate = NSDate()
                (cell as! dateTimePickTableViewCell).dateTimeLabel.text = DateTimeOperation.date2String(DateTimeOperation.string2Date(appointmentInfCell.plannedStartTime, dateFormat: "yyyy-MM-dd HH:mm:ss"), dateFormat: "MMM dd, YYYY hh:mm a")
            }
            //(cell as dateTimePickTableViewCell).dateTimeLabel.text = datetimeString
            
            (cell as! dateTimePickTableViewCell).dateTimePicker.hidden = true;
        case "textViewTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("textViewTableViewCell") as! textViewTableViewCell
            (cell as! textViewTableViewCell).inputTextView.delegate = self;
            (cell as! textViewTableViewCell).inputTextView.text = appointmentInfCell.descriptions
            (cell as! textViewTableViewCell).inputTextView.textColor = UIColor.blackColor()
        case "spaceSeparator":
            cell = tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
            cell.contentView.backgroundColor = tableSeparatorLightColor
        case "deleteButtonViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("deleteButtonViewCell")! as UITableViewCell
            cell.editing = false
            cell.contentView.backgroundColor = UIColor.redColor()
            cell.textLabel?.text = "DELETE"
            cell.textLabel?.textColor = UIColor.whiteColor()
            cell.textLabel?.backgroundColor = UIColor.redColor()
            cell.indentationLevel = 1
            cell.indentationWidth = (self.tableView.bounds.width/2) - 45
        default:
            cell = tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
        }
        
        if(cellType == "spaceSeparator") {
            setTableViewCellStyle4SeparatorLine(cell)
        }
        //        if (indexPath.row == teacherEditClassControlerTypes.allValues.count - 1){
        //            setTableViewCellStyle4SeparatorLine(cell)
        //        }
        //        else{
        //            if(indexPath.row < teacherEditClassControlerTypes.allValues.count - 1 && (cellType == "spaceSeparator" || teacherEditClassControlerTypes.allValues[indexPath.row+1].0 == "spaceSeparator")) {
        //                setTableViewCellStyle4SeparatorLine(cell)
        //            }
        //        }
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        return cell
    }
    
    func setTableViewCellStyle4SeparatorLine(cell: UITableViewCell){
        if cell.respondsToSelector("setSeparatorInset:") {
            cell.separatorInset.left = CGFloat(0.0)
        }
        if cell.respondsToSelector("setLayoutMargins:") {
            cell.layoutMargins.left = CGFloat(0.0)
        }
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if let selectedCellIndexPath = self.selectedCellIndexPath {
            if selectedCellIndexPath == indexPath {
                return CGFloat(studentEditAppointmentControlerTypes.allValues[indexPath.row].3)
            }
        }
        return CGFloat(studentEditAppointmentControlerTypes.allValues[indexPath.row].2)
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected cell #\(indexPath.row)")
        
        let (cellType, cellName, height, selectedHeight): (String, String, Int, Int) = studentEditAppointmentControlerTypes.allValues[indexPath.row]
        switch (cellType){
        case "dateTimePickTableViewCell":
            if let selectedCellIndexPath = selectedCellIndexPath {
                if selectedCellIndexPath == indexPath {
                    self.selectedCellIndexPath = nil
                } else {
                    let tmpCell:dateTimePickTableViewCell = tableView.cellForRowAtIndexPath(self.selectedCellIndexPath!) as! dateTimePickTableViewCell;
                    hideDateTimePicker(tmpCell)
                    print("tmpCell.dateTimePicker.hidden = \(tmpCell.dateTimePicker.hidden) at index \(self.selectedCellIndexPath!.row)")
                    self.selectedCellIndexPath = indexPath
                }
            } else {
                selectedCellIndexPath = indexPath
            }
            let currentCell:dateTimePickTableViewCell = tableView.cellForRowAtIndexPath(indexPath) as! dateTimePickTableViewCell;
            if(selectedCellIndexPath == nil){
                hideDateTimePicker(currentCell)
            }else{
                showDateTimePicker(currentCell)
            }
            print("currentCell.dateTimePicker.hidden = #\(currentCell.dateTimePicker.hidden)")
            tableView.beginUpdates()
            tableView.endUpdates()
        case "deleteButtonViewCell":
            let confirmView = UIAlertView()
            confirmView.title = "CHECK"
            confirmView.message = "You really want to delete this class?"
            confirmView.addButtonWithTitle("YES")
            confirmView.addButtonWithTitle("NO")
            confirmView.cancelButtonIndex = 1
            confirmView.delegate = self
            confirmView.tag = 2
            confirmView.show()
        default:
            forceHideDateTimePicker()
        }
        self.view.endEditing(true)
    }
    
    
    
    func forceHideDateTimePicker(){
        if let selectedCellIndexPath = selectedCellIndexPath {
            var tmpCell:dateTimePickTableViewCell = tableView.cellForRowAtIndexPath(self.selectedCellIndexPath!) as! dateTimePickTableViewCell;
            hideDateTimePicker(tmpCell)
            print("tmpCell.dateTimePicker.hidden = \(tmpCell.dateTimePicker.hidden) at index \(self.selectedCellIndexPath!.row)")
            self.selectedCellIndexPath = nil
            tableView.beginUpdates()
            tableView.endUpdates()
        }
    }
    
    func hideDateTimePicker(tmpCell: dateTimePickTableViewCell){
        tmpCell.dateTimePicker.hidden = true;
        tmpCell.dateTimeLabel.textColor = UIColor.blackColor()
    }
    
    func showDateTimePicker(tmpCell: dateTimePickTableViewCell){
        tmpCell.dateTimePicker.hidden = false;
        tmpCell.dateTimeLabel.textColor = UIColor.redColor()
    }
    
    // delegate textView in ViewControler
    
    func textViewDidEndEditing(textView: UITextView) {
        if (textView.text == "") {
            textView.text = "Description"
            textView.textColor = UIColor.lightGrayColor()
            isEmptyDescriptionTextview = true
        }
        textView.resignFirstResponder()
    }
    
    func textViewDidBeginEditing(textView: UITextView){
        //hideSideMenuView()
        forceHideDateTimePicker()
        if (textView.text == "Description"){
            textView.text = ""
            textView.textColor = UIColor.blackColor()
            isEmptyDescriptionTextview = false
        }
        let pointInTable = textView.convertPoint(textView.bounds.origin, toView: self.tableView)
        let currentCellIndexPathinTextEdit = self.tableView.indexPathForRowAtPoint(pointInTable)
        print("textView selected cell #\(currentCellIndexPathinTextEdit!.row)")
        
        if(isScollTableNeeded!){
            isScollTableNeeded = false
            tableView.scrollToRowAtIndexPath(currentCellIndexPathinTextEdit!, atScrollPosition: .Top, animated: true)
        }
        textView.becomeFirstResponder()
    }
    
    // delegate textField in ViewController
    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        //hideSideMenuView()
        forceHideDateTimePicker()
        
        let pointInTable = textField.convertPoint(textField.bounds.origin, toView: self.tableView)
        let currentCellIndexPathinTextEdit = self.tableView.indexPathForRowAtPoint(pointInTable)
        print("textField selected cell #\(currentCellIndexPathinTextEdit!.row)")
        
        if(isScollTableNeeded!){
            isScollTableNeeded = false
            tableView.scrollToRowAtIndexPath(currentCellIndexPathinTextEdit!, atScrollPosition: .Top, animated: true)
        }
        textField.becomeFirstResponder()
    }
    
    
    func keyboardWillShow(notification: NSNotification) {
        isScollTableNeeded = true
        print("Keyboard is shown")
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
            let contentInsets = UIEdgeInsets(top: 35, left: 0, bottom: keyboardSize.height, right: 0)
            tableView.contentInset = contentInsets
            tableView.scrollIndicatorInsets = tableView.contentInset
            print("keyboard heigh \(keyboardSize.height)")
        }
        
        
    }
    
    func keyboardWillHide(notification: NSNotification) {
        isScollTableNeeded = false
        print("Keyboard is closed")
        let contentInsets = UIEdgeInsets(top: 35, left: 0, bottom: 0, right: 0)
        tableView.contentInset = contentInsets
        tableView.scrollIndicatorInsets = contentInsets
    }
    
}

