//
//  signup.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.

import UIKit
import Alamofire

class signupViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var txtUsername : UITextField!
    @IBOutlet var txtPassword : UITextField!
    @IBOutlet var txtConfirmPassword : UITextField!
    @IBOutlet var txtEmail : UITextField!
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    var userRole = "student"
    
    
    @IBOutlet weak var scroller: UIScrollView!
    @IBAction func indexChanged(sender:UISegmentedControl)
    {
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            self.userRole = "student"
        case 1:
            self.userRole = "teacher"
        case 2:
            self.userRole = "admin"
        default:
            break;
        }
        print(self.userRole)
    }
    
    
    //    @IBAction func takePicture(sender: AnyObject) {
    //        let vc =  CameraPickerController()
    //        presentViewController(vc, animated: true, completion: nil)
    //    }
    
    
    var profileImageURL : String!
    var profileImageName : String!
    
    func feedImageName(input: String) {
        // Do something with data
        self.profileImageName = input
        self.profileImageURL = urlPicsBase + input
        profileImage.image = UIImage(data: NSData(contentsOfURL: NSURL(string:self.profileImageURL)!)!)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        // When preparing for the segue, have viewController1 provide a closure for
        // onDataAvailable
        if let viewController = segue.destinationViewController as? CameraPickerController {
            viewController.onDataAvailable = {[weak self]
                (data) in
                if let weakSelf = self {
                    weakSelf.feedImageName(data)
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        //        profileImage.layer.cornerRadius = 50.0
        //        profileImage.layer.borderColor = UIColor.blueColor().CGColor
        //        profileImage.layer.borderWidth = 1.5;
        
        var frame = profileImage.frame
        let imageSize = 100 as CGFloat
        frame.size.height = imageSize
        frame.size.width  = imageSize
        profileImage.frame = frame
        profileImage.layer.cornerRadius = imageSize / 1.5
        profileImage.layer.borderColor = UIColor.blueColor().CGColor
        profileImage.layer.borderWidth = 1.5;
        profileImage.clipsToBounds = true
        scroller.scrollEnabled = true;
        scroller.contentSize = CGSizeMake(320, 624);
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField!) -> Bool {   //delegate method
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func gotoLogin(sender : UIButton) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func signupTapped(sender : UIButton) {
        var username:NSString = txtUsername.text! as NSString
        var password:NSString = txtPassword.text! as NSString
        var confirm_password:NSString = txtConfirmPassword.text! as NSString
        var email:NSString = txtEmail.text! as NSString
        var imageName:NSString = ""
        if(self.profileImageName != nil){
            imageName = self.profileImageName as String
        }
        
        
        
        if ( username.isEqualToString("") || password.isEqualToString("") ) {
            
            var alertView:UIAlertView = UIAlertView()
            alertView.title = "Sign Up Failed!"
            alertView.message = "Please enter Username and Password"
            //alertView.delegate = self
            alertView.addButtonWithTitle("OK")
            alertView.show()
        }
        else if ( !password.isEqual(confirm_password) ) {
            
            var alertView:UIAlertView = UIAlertView()
            alertView.title = "Sign Up Failed!"
            alertView.message = "Passwords doesn't Match"
            //alertView.delegate = self
            alertView.addButtonWithTitle("OK")
            alertView.show()
        }
        else {
            
            var saltedPW = (password as String) + saltKey
            let param = [
                "username"  : username,
                "hash1"     : saltedPW.md5(),
                "hash2"     : saltedPW.sha1(),
                "hash3"     : saltedPW.sha256(),
                "email"     : email,
                "picLink"   : imageName,
                "role"      : userRole
            ] as [String: AnyObject]
            
            let manager = Alamofire.Manager.sharedInstance
            
            manager.delegate.sessionDidReceiveChallenge = { session, challenge in
                var disposition: NSURLSessionAuthChallengeDisposition = .PerformDefaultHandling
                var credential: NSURLCredential?
                
                if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
                    disposition = NSURLSessionAuthChallengeDisposition.UseCredential
                    credential = NSURLCredential(forTrust: challenge.protectionSpace.serverTrust!)
                } else {
                    if challenge.previousFailureCount > 0 {
                        disposition = .CancelAuthenticationChallenge
                    } else {
                        credential = manager.session.configuration.URLCredentialStorage?.defaultCredentialForProtectionSpace(challenge.protectionSpace)
                        
                        if credential != nil {
                            disposition = .UseCredential
                        }
                    }
                }
                
                return (disposition, credential)
            }
            
            
            manager.request(.POST, "\(urlGlobalBase)jsonSignup.php", parameters: param)
                .validate()
                .responseJSON {
                    response in
                    if(response.result.isSuccess) {
                        var dic = response.result.value as! [String: AnyObject]
                        var suc = dic["success"] as! Int
                        if(suc == 1) {
                            NSLog("Sign Up SUCCESS")
                            var alertView:UIAlertView = UIAlertView()
                            alertView.title = "Sign Up SUCCESS!"
                            alertView.message = "Welcome to Integrity!"
                            //alertView.delegate = self
                            alertView.addButtonWithTitle("OK")
                            alertView.show()
                            self.dismissViewControllerAnimated(true, completion: nil)
                        }
                        else {
                            var alertView:UIAlertView = UIAlertView()
                            alertView.title = "Sign Up Failed!"
                            alertView.message = dic["error_message"] as? String
                            alertView.delegate = self
                            alertView.addButtonWithTitle("OK")
                            alertView.show()
                        }
                    }
                    else {
                        var alertView:UIAlertView = UIAlertView()
                        alertView.title = "Sign Up Failed!"
                        alertView.message = "Cannot connect to Server!"
                        alertView.delegate = self
                        alertView.addButtonWithTitle("OK")
                        alertView.show()
                    }
            }

        }
        
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
