//
//  responseListViewController.swift
//  Integrity_APP
//
//  Created by chao on 2/3/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

class responseListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var tableView: UITableView!
    
    var refreshControl = UIRefreshControl()
    var reportID: String = ""
    var reportTopic: String = ""
    var responseSection: [responseListTableViewSection] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let textFieldTableViewCellNib = UINib(nibName: "imageLabelTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "imageLabelTableViewCell")
        
        // Do any additional setup after loading the view.
        initializeSections()
        // set style for tableView
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
        refreshControlSetup()
    }
    
    func initializeSections(){
        responseSection.append(responseListTableViewSection(sectionTitle: "Responses"))
    }
    
    override func viewDidAppear(animated: Bool) {
        getNewAppointment()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func refreshControlSetup(){
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: "getNewResponse", forControlEvents:.ValueChanged)
        refreshControl.backgroundColor = UIColor.lightGrayColor();
        let currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
        refreshControl.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
        self.tableView.addSubview(refreshControl)
    }
    
    func getNewAppointment(){
        // let currentTime = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd HH-mm-ss")
        let param = [ "reportID": self.reportID] as [String:AnyObject]
        Alamofire.request(.POST, "\(urlGlobalBase)jsonGetAllResponsesByReportID.php", parameters: param)
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var reports = response.result.value as! [[String:AnyObject]]
                    self.responseSection[0].responseInfArray.removeAll(keepCapacity: false)
                    for elem:[String:AnyObject] in reports {
                        self.responseSection[0].responseInfArray.append(responseInf(responseID: pv(elem["responseID"] as? String), reportID: pv(elem["reportID"] as? String), responsor: pv(elem["responsor"] as? String), descriptions: pv(elem["description"] as? String), responseTime: pv(elem["responseTime"] as? String), preResponseID: pv(elem["preResponseID"] as? String)))
                    }
                    //self.responseSection[0].additionalAppointmentInfArray = getAdditionalAppointmentInf(self.sections[0].appointmentInfArray)
                    // self.sections[0].additionalClassInfArray = getAdditionalClassInf(self.sections[0].classInfArray)
                    var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss")
                    self.refreshControl.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                    self.refreshControl.endRefreshing()
                    self.tableView.reloadData()
                }
                else {
                    self.refreshControl.endRefreshing()
                    var alertView:UIAlertView = UIAlertView()
                    alertView.title = "Request upcoming appointments failed!"
                    alertView.message = "Cannot get access to server"
                    alertView.delegate = self
                    alertView.addButtonWithTitle("OK")
                    alertView.show()
                }
        }
        
        self.refreshControl.endRefreshing()
    }
    
    func addLeftNavItemOnView()
    {
        let buttonEdit: UIButton = UIButton(type: UIButtonType.System) as UIButton
        buttonEdit.frame = CGRectMake(0, 0, 60, 40)
        buttonEdit.setTitle("Cancel", forState: UIControlState.Normal)
        buttonEdit.titleLabel!.font =  UIFont(name: "System", size: 17)
        buttonEdit.addTarget(self, action: "leftNavItemCancelClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let leftBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        self.navigationItem.setLeftBarButtonItem(leftBarButtonItemEdit, animated: false)
    }
    func leftNavItemCancelClick(sender:UIButton!)
    {
        print("leftNavItemCancelClick")
        setSelectedMenu(0)
    }
    
    //MARK: TableView Delegate
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return responseSection.count
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String {
        // do not display empty `Section`s
        if self.responseSection[section].getNumberOfResponsementInf() != 0 {
            return self.responseSection[section].getSectionTitle()
        }
        return ""
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return max(self.responseSection[section].getNumberOfResponsementInf(), 1)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 44
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell:imageLabelTableViewCell = tableView.dequeueReusableCellWithIdentifier("imageLabelTableViewCell") as! imageLabelTableViewCell
        if(self.responseSection[indexPath.section].responseInfArray.count == 0){
            cell.statusImageView.image = nil;
            cell.titleLabel.text = "No response for now"
            cell.timeLabel.text = ""
            cell.accessoryType = UITableViewCellAccessoryType.None
            cell.selectionStyle = UITableViewCellSelectionStyle.None
            return cell
        }
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        var currentResponseInf = self.responseSection[indexPath.section].getResponseInfAtIndex(indexPath.row)
      //  var currentAdditionalAppointmentInf = self.responseSection[indexPath.section].getAdditionalAppointmentInfAtIndex(indexPath.row)
        /*
        cell.statusImageView.image = UIImage(named: currentAdditionalAppointmentInf.imageName)?.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate);
        cell.statusImageView.tintColor = currentAdditionalAppointmentInf.imageTintColor
        cell.titleLabel.text = currentAppointmentInf.topic
         */
        if(currentResponseInf.responseTime != ""){
            cell.timeLabel.text = (DateTimeOperation.string2Date(currentResponseInf.responseTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).inBestDifferenceString
        }
        else {
            cell.timeLabel.text = ""
        }
        cell.statusImageView.image = UIImage(named: "unknowFace")
        cell.titleLabel.text = currentResponseInf.descriptions
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected section #\(indexPath.section) and cell #\(indexPath.row)")
        hideSideMenuView ()
        let secondTableViewController = userResponseDetailTableViewController()
        secondTableViewController.responseInfCell = responseSection[indexPath.section].responseInfArray[indexPath.row]
        secondTableViewController.reportTopic = self.reportTopic
        secondTableViewController.reportID = responseSection[indexPath.section].responseInfArray[indexPath.row].reportID
        //navigationItem.backBarButtonItem?.title = "Back"
        navigationController?.pushViewController(secondTableViewController, animated: true )
    }
    
}
