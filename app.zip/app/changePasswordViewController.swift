//
//  ViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.

import UIKit
import Alamofire

class changePasswordViewController: UIViewController {

    @IBOutlet weak var OldPasswordTextField: UITextField!
    @IBOutlet weak var NewPasswordTextField1: UITextField!
    @IBOutlet weak var NewPasswordTextField2: UITextField!
    var userID:String = ""
    
    @IBAction func doneUIButton(sender: UIButton) {
        if(userID == "") {
            var alertView = UIAlertView()
            alertView.title = "Program BUG!"
            alertView.message = "No userID!"
            alertView.addButtonWithTitle("OK")
            alertView.show()
            return
        }
        var oldPassword:String = OldPasswordTextField.text! + saltKey
        var newPassword1:String = NewPasswordTextField1.text! + saltKey
        var newPassWord2:String = NewPasswordTextField2.text! + saltKey
        sender.enabled = false
        if(newPassword1 == newPassWord2) {
            let param = [
                "userID"  : userID,
                "opHash1" : oldPassword.md5(),
                "opHash2" : oldPassword.sha1(),
                "opHash3" : oldPassword.sha256(),
                "npHash1" : newPassword1.md5(),
                "npHash2" : newPassword1.sha1(),
                "npHash3" : newPassword1.sha256()
            ] as [String:String]
            
            Alamofire.request(.POST, "\(urlGlobalBase)jsonChangePassword.php", parameters: param)
                .validate()
                .responseJSON {
                    response in
                    if(response.result.isSuccess) {
                        var dic = response.result.value as! [String: AnyObject]
                        var res = dic["success"] as! Int
                        if(res == 1) {
                            self.navigationController?.popViewControllerAnimated(true)
                            var alertView = UIAlertView()
                            alertView.title = "Password Reset Success!"
                            alertView.message = "Congratulation!"
                            alertView.addButtonWithTitle("OK")
                            alertView.show()
                        }
                        else {
                            sender.enabled = true
                            var alertView = UIAlertView()
                            alertView.title = "New Password Set Failed!"
                            alertView.message = "Server denied this request, please check Old Password and try again"
                            alertView.addButtonWithTitle("OK")
                            alertView.show()
                        }
                    }
                    else {
                        sender.enabled = true
                        var alertView = UIAlertView()
                        alertView.title = "New Password Set Failed!"
                        alertView.message = "Server Side Error, please try again"
                        alertView.addButtonWithTitle("OK")
                        alertView.show()
                    }
            }
        }
        else {
            sender.enabled = true
            var alertView = UIAlertView()
            alertView.title = "New Password Set Failed!"
            alertView.message = "Newpasswords are different, please check and try again"
            alertView.addButtonWithTitle("OK")
            alertView.show()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
