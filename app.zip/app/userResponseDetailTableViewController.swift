//
//  userResponseDetailTableViewController.swift
//  Integrity_APP
//
//  Created by chao on 2/4/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

class userResponseDetailTableViewController: UITableViewController {
    
    
    var responseInfCell: responseInf = responseInf()
    var sections: [tableViewSection] = []
    
    var responseID: String = ""
    var reportID: String = ""
    var reportTopic: String = ""
    var userID: String = ""
    var role: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let prefs:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        self.userID = String(prefs.integerForKey("USERID") as Int)
        self.role = prefs.stringForKey("USERROLE")!
        self.title = "Response Details"
        self.responseID = responseInfCell.responseID
        
        self.navigationItem.backBarButtonItem?.title = "Cancel"
        initializeSession()
        
        let textFieldTableViewCellNib = UINib(nibName: "textFieldTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "textFieldTableViewCell")
        
        let textViewTableViewCellNib = UINib(nibName: "textViewTableViewCell", bundle: nil)
        tableView.registerNib(textViewTableViewCellNib, forCellReuseIdentifier: "textViewTableViewCell")
        
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "emptyTableViewCell")
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
        refreshControlSetup()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        getResponseInf()
    }
    
    func getResponseInf(){
        
        var param = ["responseID" : responseInfCell.responseID] as [String : AnyObject]
        Alamofire.request(.POST, "\(urlGlobalBase)jsonGetResponseInfByID.php", parameters: param)
            .validate()
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var dic = response.result.value as! [String: AnyObject]
                    var res = dic["success"] as! Int
                    if(res == 1) { // network request success
                        self.responseInfCell = responseInf(responseID: self.responseID, descriptions: pv(dic["description"] as? String))
                        self.updateSession()
                        self.refreshControl!.endRefreshing()
                        self.tableView.reloadData()
                        
                    }
                    else {
                        self.navigationController?.dismissViewControllerAnimated(true, completion: nil)
                    }
                }
                else { // error on network connection
                    self.refreshControl!.endRefreshing()
                    var alert:UIAlertView = UIAlertView()
                    alert.title = "Network Connection Fail"
                    alert.message = "Cannot connect to the server, please try again"
                    //alert.delegate = self
                    alert.addButtonWithTitle("OK")
                    alert.show()
                }
        }
        self.refreshControl!.endRefreshing()
    }
    
    func updateSession() {
        
        sections[1].tableCellArray[0].cellTitle = responseInfCell.descriptions
    }
    
    
    func refreshControlSetup(){
        let refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: "getReportInf", forControlEvents:.ValueChanged)
        refreshControl.backgroundColor = UIColor.lightGrayColor();
        let currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
        refreshControl.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
        self.refreshControl = refreshControl;
    }
    
    func initializeSession(){
        // for section 0 -- Report topic
        let topic = self.reportTopic
        sections.append(tableViewSection(sectionTitle: "Report Topic", tableCellArray: [textFieldTableViewCellType(cellTitle: topic, cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44)]))
        
        // for section 1 -- Response description
        let description = responseInfCell.descriptions
        sections.append(tableViewSection(sectionTitle: "Response Detail", tableCellArray: [textViewTableViewCellType(cellTitle: description, cellTableViewCellName: "textViewTableViewCell", cellHeight: 160)]))
        // for section 2 -- Reply response
        sections.append(tableViewSection(sectionTitle: "Reply response", tableCellArray: [
            textFieldTableViewCellType(cellTitle: "Submit response", cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44)
            ]))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setTableViewCellStyle(cell: UITableViewCell){
        if cell.respondsToSelector("setSeparatorInset:") {
            cell.separatorInset.left = CGFloat(0.0)
        }
        if cell.respondsToSelector("setLayoutMargins:") {
            cell.layoutMargins.left = CGFloat(0.0)
        }
        cell.selectionStyle = UITableViewCellSelectionStyle.None
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return sections.count
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String {
        // do not display empty `Section`s
        if self.sections[section].getNumberOfCells() != 0 {
            return self.sections[section].getSectionTitle()
        }
        return ""
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return 40
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.sections[section].getNumberOfCells()
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: UITableViewCell
        if(self.sections[indexPath.section].getNumberOfCells() == 0){
            return tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
        }
        
        switch self.sections[indexPath.section].getTableCellTypeAtIndex(indexPath.row){
        case "textFieldTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("textFieldTableViewCell") as! textFieldTableViewCell
            //print(indexPath.section)
            var currentCell : textFieldTableViewCellType = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! textFieldTableViewCellType
            (cell as! textFieldTableViewCell).inputTextField.enabled = currentCell.textFieldEnabled
            //currentCell.cellTitle="tste"
            (cell as! textFieldTableViewCell).inputTextField.text = currentCell.cellTitle
            
            if(indexPath.section == 2){
                (cell as! textFieldTableViewCell).inputTextField.textAlignment = NSTextAlignment.Center
            }
            break
        case "textViewTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("textViewTableViewCell") as! textViewTableViewCell
            var currentCell : textViewTableViewCellType = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! textViewTableViewCellType
            (cell as! textViewTableViewCell).inputTextView.editable = currentCell.textViewEditable
            (cell as! textViewTableViewCell).inputTextView.text = currentCell.cellTitle
            (cell as! textViewTableViewCell).inputTextView.textColor = UIColor.blackColor()
            break
            
        default:
            return tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
        }
        setTableViewCellStyle(cell)
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if (indexPath.section==2 && indexPath.row==0 ){
            let destViewController:UIViewController = UIStoryboard(name: "Main",bundle: nil).instantiateViewControllerWithIdentifier("responseSubmitViewController") as UIViewController
            
            (destViewController as! responseSubmitViewController).userID = self.userID
            (destViewController as! responseSubmitViewController).reportID = self.reportID
            
            if(self.role=="teacher"){
                (destViewController as! responseSubmitViewController).from = "T" //from teacher
            }else{
                (destViewController as! responseSubmitViewController).from = "S" //from student
                
            }
            (destViewController as! responseSubmitViewController).reportTopic = self.reportTopic
            (destViewController as! responseSubmitViewController).preResponseID = self.responseID
            
            print("preResponseID:\(self.responseID)")
            self.navigationController?.pushViewController(destViewController, animated: true)
        }
        
    }
    
}
