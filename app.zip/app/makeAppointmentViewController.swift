//
//  makeAppointMentViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

enum studentMakeAppointmentControlerTypes {
    case tableViewCellCombo(type:String, name:String, height:Int, selectedHeight:Int)
    static let allValues = [("spaceSeparator", "", 35, 35),
        ("textFieldTableViewCell", "Topic", 44, 44),
        ("spaceSeparator", "", 25, 25),
        ("dateTimePickTableViewCell", "Starts", 44, 250),
        ("spaceSeparator", "", 0, 0),
        ("dateTimePickTableViewCell", "Ends", 44, 250),
        ("spaceSeparator", "", 25, 25),
        ("textViewTableViewCell", "Description", 160, 160),
        ("spaceSeparator", "", 15, 15)]
}

enum appointmentStatusTypes : String{
    case initiated = "initiated", selected = "selected", confirmed = "confirmed", finished = "finished"
    static let allValues = [initiated, selected, confirmed, finished]
}

class makeAppointmentViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UITextViewDelegate{
    
    var selectedCellIndexPath: NSIndexPath?
    
    func findIndexPathByName(name: String) ->Int{
        for index in 0...studentMakeAppointmentControlerTypes.allValues.count-1{
            if(studentMakeAppointmentControlerTypes.allValues[index].1 == name){
                return index
            }
        }
        return -1 //NSIndexPath(forRow: -1, inSection: 0)
    }
    
    func findtableViewCellByName(name: String) ->UITableViewCell{
        let index = findIndexPathByName(name);
        return tableView.cellForRowAtIndexPath(NSIndexPath(forRow: index, inSection: 0))!
    }
    var isEmptyDescriptionTextview = true
    @IBOutlet weak var tableView: UITableView!
    let tableSeparatorLightColor:UIColor = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1.0)
    var selectedMenuItem : Int = 0
    var isScollTableNeeded: Bool? = false
    override func viewDidLoad() {
        super.viewDidLoad()
        addRightNavItemOnView()
        addLeftNavItemOnView()
        
        // register customized Nib for tableViewCell
        let textFieldTableViewCellNib = UINib(nibName: "textFieldTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "textFieldTableViewCell")
        
        let dateTimePickTableViewCellNib = UINib(nibName: "dateTimePickTableViewCell", bundle: nil)
        tableView.registerNib(dateTimePickTableViewCellNib, forCellReuseIdentifier: "dateTimePickTableViewCell")
        
        let textViewTableViewCellNib = UINib(nibName: "textViewTableViewCell", bundle: nil)
        tableView.registerNib(textViewTableViewCellNib, forCellReuseIdentifier: "textViewTableViewCell")
        
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "emptyTableViewCell")
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        tableView.backgroundColor = tableSeparatorLightColor;
        // Do any additional setup after loading the view.
        
        // set style for tableView
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
    }
    
    override func viewWillAppear(animated: Bool) {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillShow:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillHide:", name: UIKeyboardWillHideNotification, object: nil)
    }
    
    override func viewWillDisappear(animated: Bool) {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    func addRightNavItemOnView()
    {
        let buttonEdit: UIButton = UIButton(type: UIButtonType.System) as UIButton
        buttonEdit.frame = CGRectMake(0, 0, 40, 40)
        buttonEdit.setTitle("Add", forState: UIControlState.Normal)
        buttonEdit.titleLabel!.font =  UIFont(name: "System", size: 17)
        buttonEdit.addTarget(self, action: "rightNavItemAddClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        self.navigationItem.setRightBarButtonItem(rightBarButtonItemEdit, animated: false)
    }
    
    func rightNavItemAddClick(sender:UIButton!)
    {
        print("rightNavItemAddClick")
        
        var topic:NSString = (findtableViewCellByName("Topic") as! textFieldTableViewCell).inputTextField.text! as NSString
        var plannedStartDatetime:NSString = (findtableViewCellByName("Starts") as! dateTimePickTableViewCell).dateTimeLabel.text! as NSString
        var plannedEndDatetime:NSString = (findtableViewCellByName("Ends") as! dateTimePickTableViewCell).dateTimeLabel.text! as NSString
        var description:NSString = (findtableViewCellByName("Description") as! textViewTableViewCell).inputTextView.text as NSString
        
        if (topic == "" || description == "" || isEmptyDescriptionTextview) {
            print("topic is empty")
            var alertView:UIAlertView = UIAlertView()
            alertView.title = "Add appointment failed!"
            alertView.message = "Please provide both topic and description"
            alertView.delegate = self
            alertView.addButtonWithTitle("OK")
            alertView.show()
        }
        else {
            var plannedStartDatetimeNSDate = DateTimeOperation.string2Date(plannedStartDatetime as String, dateStyle: .MediumStyle, timeStyle: .ShortStyle)
            var plannedEndDatetimeNSDate = DateTimeOperation.string2Date(plannedEndDatetime as String, dateStyle: .MediumStyle, timeStyle: .ShortStyle)
            var formatedPlannedStartDatetime = DateTimeOperation.date2String(plannedStartDatetimeNSDate, dateFormat: "yyyy-MM-dd HH:mm:ss")
            var formatedPlannedEndDatetime = DateTimeOperation.date2String(plannedEndDatetimeNSDate, dateFormat: "yyyy-MM-dd HH:mm:ss")
            var currentDatetimeNSDate = NSDate()
            //var currentDatetime = DateTimeOperation.date2String(currentDatetimeNSDate, dateFormat: "yyyy-MM-dd hh:mm:ss")
            
            if(plannedStartDatetimeNSDate.compare(plannedEndDatetimeNSDate) == NSComparisonResult.OrderedDescending || plannedStartDatetimeNSDate.compare(currentDatetimeNSDate) == NSComparisonResult.OrderedAscending) {
                print("plannedStartTimeNSDate after plannedEndTimeNSDate")
                var alertView:UIAlertView = UIAlertView()
                alertView.title = "Add appointment failed!"
                alertView.message = "Please make sure the start/end time is valid"
                alertView.delegate = self
                alertView.addButtonWithTitle("OK")
                alertView.show()
            }
            else {
                var userID = NSUserDefaults.standardUserDefaults().integerForKey("USERID")
                //print("topic:\(topic) ; plannedStartTime:\(formatedPlannedStartDatetime) ; plannedEndTime:\(formatedPlannedEndDatetime) ; userID:\(userID) ")
                let param = [
                    "topic" : topic,
                    "plannedStartDatetime" : formatedPlannedStartDatetime,
                    "plannedEndDatetime" : formatedPlannedEndDatetime,
                    "description" : description,
                    "userID" : String(NSUserDefaults.standardUserDefaults().integerForKey("USERID")),
                    "status" : "initiated"
                    ] as [String: AnyObject]
                sender.enabled = false
                Alamofire.request(.POST, "\(urlGlobalBase)jsonAddAppointment.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var res = response.result.value as! [String: AnyObject]
                            //println(request)
                            //println(response)
                            //println(data)
                            //println(error)
                            var suc = res["success"] as! Int
                            if(suc==1) {
                                self.setSelectedMenu(0)
                                var alertView:UIAlertView = UIAlertView()
                                alertView.title = "Add appointment success!"
                                alertView.message = "New appointment Added!"
                                //alertView.delegate = self
                                alertView.addButtonWithTitle("OK")
                                alertView.show()
                            }
                            else {
                                sender.enabled = true
                                var alertView:UIAlertView = UIAlertView()
                                alertView.title = "Add appointment failed!"
                                alertView.message = "Parameters Error, please try again"
                                //alertView.delegate = self
                                alertView.addButtonWithTitle("OK")
                                alertView.show()
                            }
                        }
                        else {
                            //println(request)
                            //println(response)
                            //println(data)
                            //println(error)
                            sender.enabled = true
                            var alertView:UIAlertView = UIAlertView()
                            alertView.title = "Add appointment failed!"
                            alertView.message = "Server side error, please try again"
                            //alertView.delegate = self
                            alertView.addButtonWithTitle("OK")
                            alertView.show()
                        }
                }
                
                
            }
        }
        
    }
    
    func addLeftNavItemOnView()
    {
        let buttonEdit: UIButton = UIButton(type: UIButtonType.System) as UIButton
        buttonEdit.frame = CGRectMake(0, 0, 60, 40)
        buttonEdit.setTitle("Cancel", forState: UIControlState.Normal)
        buttonEdit.titleLabel!.font =  UIFont(name: "System", size: 17)
        buttonEdit.addTarget(self, action: "leftNavItemCancelClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let leftBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        self.navigationItem.setLeftBarButtonItem(leftBarButtonItemEdit, animated: false)
    }
    
    func leftNavItemCancelClick(sender:UIButton!)
    {
        print("leftNavItemCancelClick")
        setSelectedMenu(0)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    //    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    //        // Return the number of sections.
    //        return 1
    //    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return studentMakeAppointmentControlerTypes.allValues.count
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let (cellType, cellName, height, selectedHeight): (String, String, Int, Int) = studentMakeAppointmentControlerTypes.allValues[indexPath.row]
        var cell:UITableViewCell
        switch (cellType){
        case "textFieldTableViewCell" :
            cell = tableView.dequeueReusableCellWithIdentifier("textFieldTableViewCell") as! textFieldTableViewCell
            (cell as! textFieldTableViewCell).inputTextField.placeholder = cellName
            (cell as! textFieldTableViewCell).inputTextField.delegate = self;
            (cell as! textFieldTableViewCell).layoutMargins = UIEdgeInsetsZero;
            
        case "dateTimePickTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("dateTimePickTableViewCell") as! dateTimePickTableViewCell
            (cell as! dateTimePickTableViewCell).nameLabel.text = cellName
            var datetimeString: String
            if(cellName == "Ends"){
                datetimeString = DateTimeOperation.date2String(DateTimeOperation.addHours(NSDate(), additionalHours: 1), dateFormat: "MMM dd, YYYY hh:mm a")
                (cell as! dateTimePickTableViewCell).dateTimePicker.minimumDate = NSDate()
            }else{
                datetimeString = DateTimeOperation.date2String(NSDate(), dateFormat: "MMM dd, YYYY hh:mm a")
                (cell as! dateTimePickTableViewCell).dateTimePicker.minimumDate = NSDate()
            }
            (cell as! dateTimePickTableViewCell).dateTimeLabel.text = datetimeString
            
            (cell as! dateTimePickTableViewCell).dateTimePicker.hidden = true;
        case "textViewTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("textViewTableViewCell") as! textViewTableViewCell
            (cell as! textViewTableViewCell).inputTextView.delegate = self;
        case "spaceSeparator":
            cell = tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
            cell.contentView.backgroundColor = tableSeparatorLightColor
        default:
            cell = tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
        }
        if (indexPath.row == studentMakeAppointmentControlerTypes.allValues.count - 1){
            setTableViewCellStyle4SeparatorLine(cell)
        }else{
            if(indexPath.row < studentMakeAppointmentControlerTypes.allValues.count - 1 && (cellType == "spaceSeparator" || studentMakeAppointmentControlerTypes.allValues[indexPath.row+1].0 == "spaceSeparator")){
                setTableViewCellStyle4SeparatorLine(cell)
            }
        }
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        return cell
    }
    
    func setTableViewCellStyle4SeparatorLine(cell: UITableViewCell){
        if cell.respondsToSelector("setSeparatorInset:") {
            cell.separatorInset.left = CGFloat(0.0)
        }
        if cell.respondsToSelector("setLayoutMargins:") {
            cell.layoutMargins.left = CGFloat(0.0)
        }
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if let selectedCellIndexPath = selectedCellIndexPath {
            if selectedCellIndexPath == indexPath {
                return CGFloat(studentMakeAppointmentControlerTypes.allValues[indexPath.row].3)
            }
        }
        return CGFloat(studentMakeAppointmentControlerTypes.allValues[indexPath.row].2)
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected cell #\(indexPath.row)")
        hideSideMenuView ()
        
        let (cellType, cellName, height, selectedHeight): (String, String, Int, Int) = studentMakeAppointmentControlerTypes.allValues[indexPath.row]
        switch (cellType){
        case "dateTimePickTableViewCell":
            if let selectedCellIndexPath = selectedCellIndexPath {
                if selectedCellIndexPath == indexPath {
                    self.selectedCellIndexPath = nil
                } else {
                    let tmpCell:dateTimePickTableViewCell = tableView.cellForRowAtIndexPath(self.selectedCellIndexPath!) as! dateTimePickTableViewCell;
                    hideDateTimePicker(tmpCell)
                    print("tmpCell.dateTimePicker.hidden = \(tmpCell.dateTimePicker.hidden) at index \(self.selectedCellIndexPath!.row)")
                    self.selectedCellIndexPath = indexPath
                }
            } else {
                selectedCellIndexPath = indexPath
            }
            let currentCell:dateTimePickTableViewCell = tableView.cellForRowAtIndexPath(indexPath) as! dateTimePickTableViewCell;
            if(selectedCellIndexPath == nil){
                hideDateTimePicker(currentCell)
            }else{
                showDateTimePicker(currentCell)
            }
            print("currentCell.dateTimePicker.hidden = #\(currentCell.dateTimePicker.hidden)")
            tableView.beginUpdates()
            tableView.endUpdates()
        default:
            forceHideDateTimePicker()
        }
        self.view.endEditing(true)
    }
    
    func forceHideDateTimePicker(){
        if let selectedCellIndexPath = selectedCellIndexPath {
            var tmpCell:dateTimePickTableViewCell = tableView.cellForRowAtIndexPath(self.selectedCellIndexPath!) as! dateTimePickTableViewCell;
            hideDateTimePicker(tmpCell)
            print("tmpCell.dateTimePicker.hidden = \(tmpCell.dateTimePicker.hidden) at index \(self.selectedCellIndexPath!.row)")
            self.selectedCellIndexPath = nil
            tableView.beginUpdates()
            tableView.endUpdates()
        }
    }
    
    func hideDateTimePicker(tmpCell: dateTimePickTableViewCell){
        tmpCell.dateTimePicker.hidden = true;
        tmpCell.dateTimeLabel.textColor = UIColor.blackColor()
    }
    
    func showDateTimePicker(tmpCell: dateTimePickTableViewCell){
        tmpCell.dateTimePicker.hidden = false;
        tmpCell.dateTimeLabel.textColor = UIColor.redColor()
    }
    
    // delegate textView in ViewControler
    
    func textViewDidEndEditing(textView: UITextView) {
        if (textView.text == "") {
            textView.text = "Description"
            textView.textColor = UIColor.lightGrayColor()
            isEmptyDescriptionTextview = true
        }
        textView.resignFirstResponder()
    }
    
    func textViewDidBeginEditing(textView: UITextView){
        hideSideMenuView()
        forceHideDateTimePicker()
        if (textView.text == "Description"){
            textView.text = ""
            textView.textColor = UIColor.blackColor()
            isEmptyDescriptionTextview = false
        }
        let pointInTable = textView.convertPoint(textView.bounds.origin, toView: self.tableView)
        let currentCellIndexPathinTextEdit = self.tableView.indexPathForRowAtPoint(pointInTable)
        print("textView selected cell #\(currentCellIndexPathinTextEdit!.row)")
        
        if(isScollTableNeeded!){
            isScollTableNeeded = false
            tableView.scrollToRowAtIndexPath(currentCellIndexPathinTextEdit!, atScrollPosition: .Top, animated: true)
        }
        textView.becomeFirstResponder()
    }
    
    // delegate textField in ViewController
    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        hideSideMenuView()
        forceHideDateTimePicker()
        
        let pointInTable = textField.convertPoint(textField.bounds.origin, toView: self.tableView)
        let currentCellIndexPathinTextEdit = self.tableView.indexPathForRowAtPoint(pointInTable)
        print("textField selected cell #\(currentCellIndexPathinTextEdit!.row)")
        
        if(isScollTableNeeded!){
            isScollTableNeeded = false
            tableView.scrollToRowAtIndexPath(currentCellIndexPathinTextEdit!, atScrollPosition: .Top, animated: true)
        }
        textField.becomeFirstResponder()
    }
    
    
    func keyboardWillShow(notification: NSNotification) {
        isScollTableNeeded = true
        print("Keyboard is shown")
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
            let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height, right: 0)
            tableView.contentInset = contentInsets
            tableView.scrollIndicatorInsets = tableView.contentInset
            print("keyboard heigh \(keyboardSize.height)")
        }
        
        
    }
    
    func keyboardWillHide(notification: NSNotification) {
        isScollTableNeeded = false
        print("Keyboard is closed")
        let contentInsets = UIEdgeInsets(top: 30, left: 0, bottom: 0, right: 0)
        tableView.contentInset = contentInsets
        tableView.scrollIndicatorInsets = contentInsets
        
    }
    
}