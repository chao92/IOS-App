//
//  barCodeResultViewController.swift
//  Integrity_APP
//
//  Created by chao on 2/1/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit

class barCodeResultViewController: UIViewController {

    @IBOutlet weak var codeValue: UILabel!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var finish: UIButton!
    
    var userPicLink: String = ""
    var userFirstName: String = ""
    var userLastName: String = ""
    var userBarCodeValue: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        self.userName.text = "\(self.userFirstName),\(self.userLastName)"
        self.codeValue.text = self.userBarCodeValue
        let url = NSURL(string: "\(urlPicsBase)/\(userPicLink)")
        var myImage = UIImage()
        if let data = NSData(contentsOfURL: url!){
            myImage = UIImage(data: data)!
        }
        self.userImage.image = myImage
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func finishScan(sender: UIButton) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
