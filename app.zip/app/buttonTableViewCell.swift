//
//  buttonTableViewCell.swift
//  Integrity_APP
//
//  Created by chao on 1/27/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit

class buttonTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //print("activatedButtonTableViewCell")
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
