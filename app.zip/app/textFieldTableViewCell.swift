//
//  textFieldTableViewCell.swift
//  App
//
//  Created by Shuang Wang on 12/19/14.
//  Copyright (c) 2014 Shuang Wang. All rights reserved.
//

import UIKit

class textFieldTableViewCell: UITableViewCell, UITextFieldDelegate {

    @IBOutlet weak var inputTextField: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //inputTextField.delegate = self
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
//    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
//    {
//        textField.resignFirstResponder()
//        return true;
//    }
//    
//    func textFieldDidBeginEditing(textField: UITextField) {
//        println("textField selected cell 1")
//        textField.becomeFirstResponder()
//    }

}
