//
//  DateTimeOperations.swift
//  App
//
//  Created by Shuang Wang on 12/22/14.
//  Copyright (c) 2014 Shuang Wang. All rights reserved.
//

import UIKit

// Flashy swift... maybe...
func -(lhs:NSDate, rhs:NSDate) -> DateRange {
    return DateRange(startDate: rhs, endDate: lhs)
}

enum DateTimeOperation{
    static func string2Date(inputString: String, dateFormat: String)->NSDate {
        //println(inputString)
        let dateFormatter = NSDateFormatter()
        dateFormatter.locale = NSLocale.currentLocale()
        dateFormatter.dateFormat = dateFormat
        let date: NSDate? = dateFormatter.dateFromString(inputString)
        return date!
    }
    
    static func string2Date(inputString: String, dateStyle: NSDateFormatterStyle, timeStyle: NSDateFormatterStyle)->NSDate {
        let dateFormatter = NSDateFormatter()
        dateFormatter.locale = NSLocale.currentLocale()
        dateFormatter.dateStyle = dateStyle // NSDateFormatterStyle.MediumStyle
        dateFormatter.timeStyle = timeStyle // NSDateFormatterStyle.ShortStyle
        let date: NSDate? = dateFormatter.dateFromString(inputString)
        return date!
    }
    
    static func date2String(inputDate: NSDate, dateFormat: String)->String {
        let dateFormatter = NSDateFormatter()
        dateFormatter.locale = NSLocale.currentLocale()
        dateFormatter.dateFormat = dateFormat //"yyyy-MM-dd hh:mm:ss"
        //dateFormatter.timeStyle = NSDateFormatterStyle.ShortStyle
        return dateFormatter.stringFromDate(inputDate)
    }
    
    static func addDays(date: NSDate, additionalDays: Int) -> NSDate {
        // adding $additionalDays
        var components = NSDateComponents()
        components.day = additionalDays
        
        // important: NSCalendarOptions(0)
        let futureDate = NSCalendar.currentCalendar()
            .dateByAddingComponents(components, toDate: date, options: NSCalendarOptions(rawValue: 0))
        return futureDate!
    }
    
    static func addHours(date: NSDate, additionalHours: Int) -> NSDate {
        // adding $additionalDays
        var components = NSDateComponents()
        components.hour = additionalHours
        
        // important: NSCalendarOptions(0)
        let futureDate = NSCalendar.currentCalendar()
            .dateByAddingComponents(components, toDate: date, options: NSCalendarOptions(rawValue: 0))
        return futureDate!
    }
}



class DateRange {
    let startDate:NSDate
    let endDate:NSDate
    var calendar = NSCalendar.currentCalendar()
    var days: Int {
        return calendar.components(.Day, fromDate: startDate, toDate: endDate, options: []).day
    }
    var months: Int {
        return calendar.components(.Month, fromDate: startDate, toDate: endDate, options: []).month
    }

    var hours: Int {
        return calendar.components(.Hour, fromDate: startDate, toDate: endDate, options: []).hour
    }
    
    var minute: Int{
        return calendar.components(.Minute, fromDate: startDate, toDate: endDate, options: []).minute
    }
    
    var inBestDifferenceString: String{
        let mins = calendar.components(.Minute, fromDate: startDate, toDate: endDate, options: []).minute
        let hour = Int(ceil(CGFloat(mins)/60))
        let day = Int(ceil(CGFloat(mins)/1440))
        switch (true){
            case (mins >= 1440): // 7*24-1
                return "In \(day) days"
            case ((mins >= 60) && (mins < 1440)):
                return "In \(hour) hrs"
            case (mins >= 0 && mins < 60):
                return "In \(mins) mins"
            case ((mins < 0) && (mins > -60)):
                return "\(abs(mins)) mins ago"
            case ((mins <= -60) && (mins > -1440)):
                return "\(abs(hour)) hrs ago"
            case (mins <= -1440):
                return "\(abs(day)) days ago"
        default:
            return ""
        }
    }
    init(startDate:NSDate, endDate:NSDate) {
        self.startDate = startDate
        self.endDate = endDate
    }
}

