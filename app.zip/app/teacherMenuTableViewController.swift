//
//  teacherMenuTableViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit

struct teacherMenuTypes{
    class teacherMenuInf{
        var menuName: String = ""
        var viewControllerName:String = ""
        init(menuName : String, viewControllerName: String){
            self.menuName = menuName
            self.viewControllerName = viewControllerName
        }
    }
    static let allValues: [teacherMenuInf] = [teacherMenuInf(menuName : "Home",     viewControllerName:
        "teachMainViewController"),
        teacherMenuInf(menuName : "Appointments", viewControllerName: "appointmentHomeViewController"),
        teacherMenuInf(menuName : "Chat", viewControllerName: "ViewController"),
        //teacherMenuInf(menuName : "Make Appointment", viewControllerName: "makeAppointmentViewController"),
        teacherMenuInf(menuName : "Scan Barcode", viewControllerName: "scanCodabarViewController"),
        teacherMenuInf(menuName : "Account",  viewControllerName: "userAccountViewController"),
        teacherMenuInf(menuName : "Help",     viewControllerName: "userHelpViewController"),
        teacherMenuInf(menuName : "Logout",   viewControllerName: "loginViewController")]
}



class teacherMenuTableViewController: UITableViewController {
    var selectedMenuItem : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        //let storyboard = UIStoryboard(name: "Main", bundle: nil)
        //storyboard.instantiateViewControllerWithIdentifier("ViewController")

        // Customize apperance of table view
        tableView.contentInset = UIEdgeInsetsMake(64.0, 0, 0, 0) //
        tableView.separatorStyle = .None
        tableView.backgroundColor = UIColor.clearColor()
        tableView.scrollsToTop = false
        
        // Preserve selection between presentations
        self.clearsSelectionOnViewWillAppear = false
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "menuTableViewCell")
        tableView.selectRowAtIndexPath(NSIndexPath(forRow: selectedMenuItem, inSection: 0), animated: false, scrollPosition: .Middle)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return teacherMenuTypes.allValues.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("menuTableViewCell", forIndexPath: indexPath)
        
        //if (cell == nil) {
        //    cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "CELL")
        cell.backgroundColor = UIColor.clearColor()
        cell.textLabel?.textColor = UIColor.darkGrayColor()
        let selectedBackgroundView = UIView(frame: CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height))
        selectedBackgroundView.backgroundColor = UIColor.grayColor().colorWithAlphaComponent(0.2)
        cell.selectedBackgroundView = selectedBackgroundView
        //}
        
        cell.textLabel?.text = teacherMenuTypes.allValues[indexPath.row].menuName
        
        return cell
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 50.0
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        print("did select row: \(indexPath.row)")
        
        if (indexPath.row == selectedMenuItem) {
            return
        }
        selectedMenuItem = indexPath.row
        //addClass = "Add Class", account = "Account", help = "Help", logout = "Logout"
        //Present new view controller
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main",bundle: nil)
        let destViewController = mainStoryboard.instantiateViewControllerWithIdentifier(teacherMenuTypes.allValues[indexPath.row].viewControllerName) as UIViewController
        if(teacherMenuTypes.allValues[indexPath.row].menuName == "Logout"){
            let appDomain = NSBundle.mainBundle().bundleIdentifier
            NSUserDefaults.standardUserDefaults().removePersistentDomainForName(appDomain!)
            self.sideMenuController()?.setContentViewController(destViewController)
            self.sideMenuController()?.disableSideMenu()
        }
        else {
            sideMenuController()?.setContentViewController(destViewController)
        }
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    }
    */
    
}
