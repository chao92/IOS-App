//
//  appointmentHomeViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

struct appointmentStatusType{
    class appointmentStatusInf{
        var imageName: String = ""
        var title:String = ""
        var color: UIColor = UIColor.blueColor()
        init(imageName : String, title: String, color: UIColor){
            self.imageName = imageName
            self.title = title
            self.color = color;
        }
    }
    static let initiated: appointmentStatusInf = appointmentStatusInf(imageName: "published", title: "Published Appointments", color: UIColor.purpleColor())
    static let selected : appointmentStatusInf = appointmentStatusInf(imageName: "reserved" , title: "Reserved Appointments", color: UIColor.redColor())
    static let confirmed: appointmentStatusInf = appointmentStatusInf(imageName: "confirmed", title: "Confirmed Appointments", color: UIColor.blueColor())
    static let finished : appointmentStatusInf = appointmentStatusInf(imageName: "archived" , title: "Archieved Appointments", color: UIColor.brownColor())
    static let allAppointments : appointmentStatusInf = appointmentStatusInf(imageName: "menu" ,   title: "All Appointments", color: UIColor.blackColor())
    static let dictionary = ["Published Appointments": "initiated", "Reserved Appointments": "selected", "Confirmed Appointments": "confirmed","Archieved Appointments": "finished","All Appointments" : "allAppointments"]
}

class appointmentHomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{

    @IBOutlet var tableView: UITableView!
    var sections : [appointmentListTableViewSection] = [];
    
    var refreshControl = UIRefreshControl()
    var userID: String = ""
    var role: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //addRightNavItemOnView()
        addLeftNavItemOnView()
        // Do any additional setup after loading the view, typically from a nib.
        // register customized Nib for tableViewCell
        
        let prefs:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        self.userID = String(prefs.integerForKey("USERID") as Int)
        self.role = prefs.stringForKey("USERROLE")!
        
        initializeSections()
        let textFieldTableViewCellNib = UINib(nibName: "imageLabelTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "imageLabelTableViewCell")
        
        // Do any additional setup after loading the view.
        
        // set style for tableView
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
        refreshControlSetup()
    }
    
    override func viewDidAppear(animated: Bool) {
        getNewAppointment()
    }
    
    func refreshControlSetup(){
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: "getNewAppointment", forControlEvents:.ValueChanged)
        refreshControl.backgroundColor = UIColor.lightGrayColor();
        let currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
        refreshControl.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
        self.tableView.addSubview(refreshControl)
    }
    
    func getNewAppointment(){
        // let currentTime = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd HH-mm-ss")
        let param = [
            // "role" : "teacher",
            "userID" : userID,
            "status" : "initiated"
            //   "time" : currentTime
            ] as [String:AnyObject]
        
        Alamofire.request(.POST, "\(urlGlobalBase)jsonGetUnprocessedAppointments.php", parameters: param)
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var reports = response.result.value as! [[String:AnyObject]]
                    self.sections[0].appointmentInfArray.removeAll(keepCapacity: false)
                    for elem:[String:AnyObject] in reports {
                        self.sections[0].appointmentInfArray.append(appointmentInf(appointID: pv(elem["appointID"] as? String), proposer: pv(elem["proposer"] as? String), responsor: pv(elem["responsor"] as? String), topic: pv(elem["topic"] as? String), descriptions: pv(elem["descriptions"] as? String), plannedStartTime: pv(elem["plannedStartTime"] as? String), plannedEndTime: pv(elem["plannedEndTime"] as? String), actualStartTime: pv(elem["actualStartTime"] as? String), actualEndTime: pv(elem["actualEndTime"] as? String), status: pv(elem["status"] as? String), sessionID: pv(elem["sessionID"] as? String)))
                    }
                    self.sections[0].additionalAppointmentInfArray = getAdditionalAppointmentInf(self.sections[0].appointmentInfArray)
                    // self.sections[0].additionalClassInfArray = getAdditionalClassInf(self.sections[0].classInfArray)
                    var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss")
                    self.refreshControl.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                    self.refreshControl.endRefreshing()
                    self.tableView.reloadData()
                }
                else {
                    self.refreshControl.endRefreshing()
                    var alertView:UIAlertView = UIAlertView()
                    alertView.title = "Request upcoming appointments failed!"
                    alertView.message = "Cannot get access to server"
                    alertView.delegate = self
                    alertView.addButtonWithTitle("OK")
                    alertView.show()
                }
        }
        
        self.refreshControl.endRefreshing()
    }

    func initializeSections(){
        sections.append(appointmentListTableViewSection(sectionTitle: "Unprocessed Appointments"))
        sections.append(initializeSectionTabs())
    }
    func addLeftNavItemOnView()
    {
        let buttonEdit: UIButton = UIButton(type: UIButtonType.System) as UIButton
        buttonEdit.frame = CGRectMake(0, 0, 60, 40)
        buttonEdit.setTitle("Cancel", forState: UIControlState.Normal)
        buttonEdit.titleLabel!.font =  UIFont(name: "System", size: 17)
        buttonEdit.addTarget(self, action: "leftNavItemCancelClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let leftBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        self.navigationItem.setLeftBarButtonItem(leftBarButtonItemEdit, animated: false)
    }
    func leftNavItemCancelClick(sender:UIButton!)
    {
        print("leftNavItemCancelClick")
        setSelectedMenu(0)
    }
    
    func initializeSectionTabs() -> appointmentListTableViewSection{
        let currentSection = appointmentListTableViewSection(sectionTitle: "All Appointments")
        
        currentSection.addAppointmentInf(appointmentInf(userID: self.userID, topic: appointmentStatusType.initiated.title))
        currentSection.addAdditionalAppointmentInf(additionalAppointmentInf(imageName: appointmentStatusType.initiated.imageName, imageTintColor: appointmentStatusType.initiated.color))
        
        currentSection.addAppointmentInf(appointmentInf(userID: self.userID, topic: appointmentStatusType.selected.title))
        currentSection.addAdditionalAppointmentInf(additionalAppointmentInf(imageName: appointmentStatusType.selected.imageName, imageTintColor: appointmentStatusType.selected.color))
        
        currentSection.addAppointmentInf(appointmentInf(userID: self.userID, topic: appointmentStatusType.confirmed.title))
        currentSection.addAdditionalAppointmentInf(additionalAppointmentInf(imageName: appointmentStatusType.confirmed.imageName, imageTintColor: appointmentStatusType.confirmed.color))
        
        currentSection.addAppointmentInf(appointmentInf(userID: self.userID, topic: appointmentStatusType.finished.title))
        currentSection.addAdditionalAppointmentInf(additionalAppointmentInf(imageName: appointmentStatusType.finished.imageName, imageTintColor: appointmentStatusType.finished.color))
        
        currentSection.addAppointmentInf(appointmentInf(userID: self.userID, topic: appointmentStatusType.allAppointments.title))
        currentSection.addAdditionalAppointmentInf(additionalAppointmentInf(imageName: appointmentStatusType.allAppointments.imageName, imageTintColor: appointmentStatusType.allAppointments.color))
        
        return currentSection
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // handle tabelview
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return sections.count
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String {
        // do not display empty `Section`s
        if self.sections[section].getNumberOfAppointmentInf() != 0 {
            return self.sections[section].getSectionTitle()
        }
        return ""
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return max(self.sections[section].getNumberOfAppointmentInf(), 1)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 44
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell:imageLabelTableViewCell = tableView.dequeueReusableCellWithIdentifier("imageLabelTableViewCell") as! imageLabelTableViewCell
        if(self.sections[indexPath.section].appointmentInfArray.count == 0){
            cell.statusImageView.image = nil;
            cell.titleLabel.text = "No initial appointment"
            cell.timeLabel.text = ""
            cell.accessoryType = UITableViewCellAccessoryType.None
            cell.selectionStyle = UITableViewCellSelectionStyle.None
            return cell
        }
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        var currentAppointmentInf = self.sections[indexPath.section].getAppointmentInfAtIndex(indexPath.row)
        var currentAdditionalAppointmentInf = self.sections[indexPath.section].getAdditionalAppointmentInfAtIndex(indexPath.row)
        
        cell.statusImageView.image = UIImage(named: currentAdditionalAppointmentInf.imageName)?.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate);
        cell.statusImageView.tintColor = currentAdditionalAppointmentInf.imageTintColor
        cell.titleLabel.text = currentAppointmentInf.topic
        
        if(currentAppointmentInf.plannedStartTime != ""){
            cell.timeLabel.text = (DateTimeOperation.string2Date(currentAppointmentInf.plannedStartTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).inBestDifferenceString
        }
        else {
            cell.timeLabel.text = ""
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected section #\(indexPath.section) and cell #\(indexPath.row)")
        hideSideMenuView ()
        
        switch (indexPath.section) {
        case 0: // for upcoming appointment
        if(self.sections[indexPath.section].appointmentInfArray.count == 0){
        return
        }
        let secondTableViewController = userAppointmentDetailTableViewController()
        secondTableViewController.appointmentInfCell = sections[indexPath.section].appointmentInfArray[indexPath.row]
        secondTableViewController.title = sections[indexPath.section].appointmentInfArray[indexPath.row].topic
        //navigationItem.backBarButtonItem?.title = "Back"
        navigationController?.pushViewController(secondTableViewController, animated: true )
        
        case 1: // for all appointments
        let secondTableViewController = allAppointmentsTableViewController()
        //var condition = sections[indexPath.section].classInfArray[indexPath.row].status
        //condition += sections[indexPath.section].classInfArray[indexPath.row].teacherID
        //var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd HH:mm:ss")
        let appointmentStatus = appointmentStatusType.dictionary[sections[indexPath.section].appointmentInfArray[indexPath.row].topic]!
        //var sqlCondition = "WHERE teacherID = \(String(teacherID)) "
        secondTableViewController.role = self.role
        secondTableViewController.userID = self.userID
        
        if(sections[indexPath.section].appointmentInfArray[indexPath.row].topic == "Archieved Appointments"){
        //sqlCondition += "AND status = '\(classStatus)' AND plannedEndTime < '\(currentDateString)'"
        secondTableViewController.appointmentStatus = appointmentStatus
        secondTableViewController.viewMode = 0
        }
        else if(sections[indexPath.section].appointmentInfArray[indexPath.row].topic == "All Appointments"){
        //sqlCondition += "Limit 50"
        secondTableViewController.viewMode = 1
        }
        else{
        //sqlCondition += "AND status = '\(classStatus)' AND plannedEndTime > '\(currentDateString)'"
        secondTableViewController.appointmentStatus = appointmentStatus
        secondTableViewController.viewMode = 2
        }
        //secondTableViewController.sqlCondition = sqlCondition
        secondTableViewController.title = sections[indexPath.section].appointmentInfArray[indexPath.row].topic
        //navigationItem.backBarButtonItem?.title = "Back"
        navigationController?.pushViewController(secondTableViewController, animated: true )
        
        default:
        break
        }
    }
    
}

