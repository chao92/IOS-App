//
//  allAppointmentsTableViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/31/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

class allAppointmentsTableViewController: UITableViewController {
    
    var appointmentInfArray: [appointmentInf] = []
    var additionalAppointmentInfArray: [additionalAppointmentInf] = []
    //var sqlCondition:String = ""
    var role: String = ""
    var viewMode: Int = -1  // 0 for archived appointment; 1 for all appointment; 2 for undergoing appointment
    var userID: String = ""
    var appointmentStatus:String = ""


    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        let textFieldTableViewCellNib = UINib(nibName: "imageLabelTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "imageLabelTableViewCell")
        
        // Do any additional setup after loading the view.
        
        // set style for tableView
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
        refreshControlSetup()
    }
    
    override func viewDidAppear(animated: Bool) {
        getAppointment()
    }
    
    func getAppointment(){ // for refreshing
        
        self.refreshControl?.beginRefreshing()
        
        let currentTime = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd HH:mm:ss")
        let param = [
            "role" : self.role,
            "userID" : self.userID,
            "status" : self.appointmentStatus,
            "time" : currentTime
            ] as [String:AnyObject]
        
        if(role == "teacher" || role == "student") {
            if(viewMode == 0) {
                Alamofire.request(.POST, "\(urlGlobalBase)jsonGetFinishedAppointments.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var appointments = response.result.value as! [[String: AnyObject]]
                            self.appointmentInfArray.removeAll(keepCapacity: false)
                            for elem:[String:AnyObject] in appointments {
                                self.appointmentInfArray.append(appointmentInf(appointID: pv(elem["appointID"] as? String), proposer: pv(elem["proposer"] as? String), responsor: pv(elem["responsor"] as? String), topic: pv(elem["topic"] as? String), descriptions: pv(elem["description"] as? String), plannedStartTime: pv(elem["plannedStartTime"] as? String), plannedEndTime: pv(elem["plannedEndTime"] as? String), actualStartTime: pv(elem["actualStartTime"] as? String), actualEndTime: pv(elem["actualEndTime"] as? String), status: pv(elem["status"] as? String), sessionID: pv(elem["sessionID"] as? String)))
                            }
                            self.additionalAppointmentInfArray = getAdditionalAppointmentInf(self.appointmentInfArray)
                            self.refreshControl?.endRefreshing()
                            var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
                            self.refreshControl?.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                            self.tableView.reloadData()
                        }
                        else {
                            self.refreshControl?.endRefreshing()
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            //alert.delegate = self
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
            }
            else if(viewMode == 1) {
                Alamofire.request(.POST, "\(urlGlobalBase)jsonGetAllAppointments.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var appointments = response.result.value as! [[String: AnyObject]]
                            self.appointmentInfArray.removeAll(keepCapacity: false)
                            for elem:[String:AnyObject] in appointments {
                                self.appointmentInfArray.append(appointmentInf(appointID: pv(elem["appointID"] as? String), proposer: pv(elem["proposer"] as? String), responsor: pv(elem["responsor"] as? String), topic: pv(elem["topic"] as? String), descriptions: pv(elem["description"] as? String), plannedStartTime: pv(elem["plannedStartTime"] as? String), plannedEndTime: pv(elem["plannedEndTime"] as? String), actualStartTime: pv(elem["actualStartTime"] as? String), actualEndTime: pv(elem["actualEndTime"] as? String), status: pv(elem["status"] as? String), sessionID: pv(elem["sessionID"] as? String)))
                            }
                            self.additionalAppointmentInfArray = getAdditionalAppointmentInf(self.appointmentInfArray)
                            self.refreshControl?.endRefreshing()
                            var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
                            self.refreshControl?.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                            self.tableView.reloadData()
                        }
                        else {
                            self.refreshControl?.endRefreshing()
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            //alert.delegate = self
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
                
            }
            else if(viewMode == 2) {
                Alamofire.request(.POST, "\(urlGlobalBase)jsonGetStatusAppointments.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var appointments = response.result.value as! [[String: AnyObject]]
                            self.appointmentInfArray.removeAll(keepCapacity: false)
                            for elem:[String:AnyObject] in appointments {
                                self.appointmentInfArray.append(appointmentInf(appointID: pv(elem["appointID"] as? String), proposer: pv(elem["proposer"] as? String), responsor: pv(elem["responsor"] as? String), topic: pv(elem["topic"] as? String), descriptions: pv(elem["description"] as? String), plannedStartTime: pv(elem["plannedStartTime"] as? String), plannedEndTime: pv(elem["plannedEndTime"] as? String), actualStartTime: pv(elem["actualStartTime"] as? String), actualEndTime: pv(elem["actualEndTime"] as? String), status: pv(elem["status"] as? String), sessionID: pv(elem["sessionID"] as? String)))
                            }
                            self.additionalAppointmentInfArray = getAdditionalAppointmentInf(self.appointmentInfArray)
                            self.refreshControl?.endRefreshing()
                            var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
                            self.refreshControl?.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                            self.tableView.reloadData()
                        }
                        else {
                            self.refreshControl?.endRefreshing()
                            var alert:UIAlertView = UIAlertView()
                            alert.title = "Network Connection Fail"
                            alert.message = "Cannot connect to the server, please try again"
                            //alert.delegate = self
                            alert.addButtonWithTitle("OK")
                            alert.show()
                        }
                }
                
            }
            else {
                self.refreshControl?.endRefreshing()
                NSLog("viewMode Error")
            }
        }
        else {
            NSLog("role Error")
        }
        
        //classInfArray = jsonGetClassesByConditions("\(sqlCondition)")
        //additionalClassInfArray = getAdditionalClassInf(classInfArray)
        //self.tableView.reloadData()
        //self.refreshControl?.endRefreshing()
    }
    
    func refreshControlSetup(){
        let refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: "getNewClass", forControlEvents:.ValueChanged)
        refreshControl.backgroundColor = UIColor.lightGrayColor();
        self.refreshControl = refreshControl;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return self.appointmentInfArray.count
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 44
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var currentAppointmentInf = self.appointmentInfArray[indexPath.row]
        var currentAdditionalAppointmentInf = additionalAppointmentInfArray[indexPath.row]
        
        var cell:imageLabelTableViewCell = tableView.dequeueReusableCellWithIdentifier("imageLabelTableViewCell") as! imageLabelTableViewCell
        cell.statusImageView.image = UIImage(named: currentAdditionalAppointmentInf.imageName)?.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate);
        cell.statusImageView.tintColor = currentAdditionalAppointmentInf.imageTintColor
        cell.titleLabel.text = currentAppointmentInf.topic
        cell.timeLabel.text = (DateTimeOperation.string2Date(currentAppointmentInf.plannedStartTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).inBestDifferenceString
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected section #\(indexPath.section) and cell #\(indexPath.row)")
        hideSideMenuView ()
        switch (indexPath.section) {
        case 0: // getcurrent class
            let secondTableViewController = userAppointmentDetailTableViewController()
            navigationController?.pushViewController(secondTableViewController, animated: true )
            secondTableViewController.appointmentInfCell = appointmentInfArray[indexPath.row]
            secondTableViewController.title = appointmentInfArray[indexPath.row].topic
        default:
            break
        }
    }


    /*
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
