//
//  reportViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/25/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import MobileCoreServices
import MediaPlayer
import Photos
import Alamofire

enum reportControlerTypes {
    case tableViewCellCombo(type:String, name:String, height:Int, selectedHeight:Int)
    static let allValues = [
        //("spaceSeparator", "", 35, 35),
        ("textFieldTableViewCell", "Topic", 44, 44),
        ("spaceSeparator", "", 25, 25),
        // ("dateTimePickTableViewCell", "Starts", 44, 250),
        // ("spaceSeparator", "", 0, 0),
        // ("dateTimePickTableViewCell", "Ends", 44, 250),
        ("buttonTableViewCell","Pick Photos",40,40),
        ("buttonTableViewCell","Take Photos",40,40),
        
        ("spaceSeparator", "", 25, 25),
        ("textViewTableViewCell", "Description", 160, 160),
        //("spaceSeparator", "", 15, 15)
    ]
    //("imagePickTableViewCell", "", 150, 150)]
}


class reportViewController: UIViewController, UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate,UITextViewDelegate,UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var previewView: UICollectionView!
    @IBOutlet weak var tableView: UITableView!
    var selectedCellIndexPath: NSIndexPath?
    func findIndexPathByName(name: String) ->Int{
        for index in 0...reportControlerTypes.allValues.count-1{
            if(reportControlerTypes.allValues[index].1 == name){
                return index
            }
        }
        return -1 //NSIndexPath(forRow: -1, inSection: 0)
    }
    
    func findtableViewCellByName(name: String) ->UITableViewCell{
        let index = findIndexPathByName(name);
        return tableView.cellForRowAtIndexPath(NSIndexPath(forRow: index, inSection: 0))!
    }
    
    
    
    let tableSeparatorLightColor:UIColor = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1.0)
    var isScollTableNeeded: Bool? = false
    var isEmptyDescriptionTextview = true
    var assets: [DKAsset]?
    var imageLocalIdentifier: [String]=[]
    var imageStoreIdentifier: [String]=[]
    var manager = PHImageManager.defaultManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addRightNavItemOnView()
        addLeftNavItemOnView()
        
        
        let buttonTableViewCellNib = UINib(nibName: "buttonTableViewCell", bundle: nil)
        tableView.registerNib(buttonTableViewCellNib, forCellReuseIdentifier: "buttonTableViewCell")
        
        let textFieldTableViewCellNib = UINib(nibName: "textFieldTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "textFieldTableViewCell")
        
        //  let dateTimePickTableViewCellNib = UINib(nibName: "dateTimePickTableViewCell", bundle: nil)
        // tableView.registerNib(dateTimePickTableViewCellNib, forCellReuseIdentifier: "dateTimePickTableViewCell")
        
        let textViewTableViewCellNib = UINib(nibName: "textViewTableViewCell", bundle: nil)
        tableView.registerNib(textViewTableViewCellNib, forCellReuseIdentifier: "textViewTableViewCell")
        
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "emptyTableViewCell")
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        tableView.backgroundColor = tableSeparatorLightColor;
        // Do any additional setup after loading the view.
        
        // set style for tableView
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
        /*
        var label: UILabel = UILabel()
        label.frame = CGRectMake(0, 500, 100, 100)
        label.backgroundColor = UIColor.blackColor()
        label.textColor = UIColor.whiteColor()
        label.textAlignment = NSTextAlignment.Center
        label.text = "test label"
        tableView.addSubview(label)*/
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func showImagePickerWithAssetType(
        assetType: DKImagePickerControllerAssetType,
        allowMultipleType: Bool,
        sourceType: DKImagePickerControllerSourceType = [.Camera, .Photo],
        allowsLandscape: Bool,
        singleSelect: Bool) {
            
            let pickerController = DKImagePickerController()
            pickerController.assetType = assetType
            pickerController.allowsLandscape = allowsLandscape
            pickerController.allowMultipleTypes = allowMultipleType
            pickerController.sourceType = sourceType
            pickerController.singleSelect = singleSelect
            //			pickerController.showsCancelButton = true
            //			pickerController.showsEmptyAlbums = false
            //			pickerController.defaultAssetGroup = PHAssetCollectionSubtype.SmartAlbumFavorites
            pickerController.defaultSelectedAssets = self.assets
            
            pickerController.didSelectAssets = { [unowned self] (assets: [DKAsset]) in
                print("didSelectAssets")
                
                self.assets = assets
                self.previewView?.reloadData()
                
                //get the imageNameLists
                self.imageStoreIdentifier = []
                self.imageLocalIdentifier = self.getImageLocalIdentifier()
                print("getImageLocalIdentifier")
            }
            
            if UI_USER_INTERFACE_IDIOM() == .Pad {
                pickerController.modalPresentationStyle = .FormSheet;
            }
            
            self.presentViewController(pickerController, animated: true) {}
    }
    // Generate ImageName
    func randomStringWithLength (len : Int) -> NSString {
        
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        
        let randomString : NSMutableString = NSMutableString(capacity: len)
        
        for (var i=0; i < len; i++){
            let length = UInt32 (letters.length)
            let rand = arc4random_uniform(length)
            randomString.appendFormat("%C", letters.characterAtIndex(Int(rand)))
        }
        
        return randomString
    }
    
    
    func uploadImageData(localName:String,imageData:NSData){
        var url = NSURL(string: "http://app1.ucsd-dbmi.org/app/uploadImage.php")
        var request = NSMutableURLRequest(URL: url!)
        request.HTTPMethod = "POST"
        request.HTTPShouldHandleCookies = false
        request.timeoutInterval = 30
        
        let boundary = "----------SwIfTeRhTtPrEqUeStBoUnDaRy"
        let contentType = "multipart/form-data; boundary=\(boundary)"
        request.setValue(contentType, forHTTPHeaderField:"Content-Type")
        var body = NSMutableData();
        let tempData = NSMutableData()
        
        
        let fileName = localName
        let parameterName = "input"
        
        
        let mimeType = "image/jpeg"
        tempData.appendData("--\(boundary)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        let fileNameContentDisposition = (!fileName.isEmpty) ? "filename=\"\(fileName)\"" : ""
        print(fileNameContentDisposition)
        let contentDisposition = "Content-Disposition: form-data; name=\"\(parameterName)\"; \(fileNameContentDisposition)\r\n"
        tempData.appendData(contentDisposition.dataUsingEncoding(NSUTF8StringEncoding)!)
        tempData.appendData("Content-Type: \(mimeType)\r\n\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        
        tempData.appendData(imageData)
        tempData.appendData("\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        body.appendData(tempData)
        
        body.appendData("\r\n--\(boundary)--\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        
        request.setValue("\(body.length)", forHTTPHeaderField: "Content-Length")
        request.HTTPBody = body
        
        
        var response: AutoreleasingUnsafeMutablePointer<NSURLResponse?> = nil
        var error: AutoreleasingUnsafeMutablePointer<NSErrorPointer?> = nil
        
        do{
            var dataVal: NSData = try NSURLConnection.sendSynchronousRequest(request, returningResponse: response)
            let result = NSString(data:dataVal, encoding:NSUTF8StringEncoding)
            print("Synchronous result? \(result)")
        } catch (let e)
        {
            print(e)
        }
    }
    
    
    func retrieveImageWithIdentifer(localIdentifier:String, completion: (image:UIImage?) -> Void) {
        let fetchOptions = PHFetchOptions()
        fetchOptions.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.Image.rawValue)
        let fetchResults = PHAsset.fetchAssetsWithLocalIdentifiers([localIdentifier], options: fetchOptions)
        
        if fetchResults.count > 0 {
            if let imageAsset = fetchResults.objectAtIndex(0) as? PHAsset {
                let requestOptions = PHImageRequestOptions()
                requestOptions.deliveryMode = .HighQualityFormat
                manager.requestImageForAsset(imageAsset, targetSize: PHImageManagerMaximumSize, contentMode: .AspectFill, options: requestOptions, resultHandler: { (image, info) -> Void in
                    completion(image: image)
                })
            } else {
                completion(image: nil)
            }
        } else {
            completion(image: nil)
        }
    }
    
    func getImageLocalIdentifier()->[String]{
        self.imageLocalIdentifier = []
        print("number of assets: \(self.previewView?.numberOfItemsInSection(0))")
        if (self.assets != nil){
            for item in self.assets! {
                if #available(iOS 9.0, *) {
                    let resources = PHAssetResource.assetResourcesForAsset(item.originalAsset!)
                    resources
                    if let resources = resources.first {
                        var photoname = resources.assetLocalIdentifier
                        //print(photoname)
                        self.imageLocalIdentifier.append(photoname)
                    }
                } else {
                    // Fallback on earlier versions
                }
            }
        }
        return self.imageLocalIdentifier
    }
    
    
    //MARK: NavigationButtons
    
    func addRightNavItemOnView()
    {
        let buttonEdit: UIButton = UIButton(type: UIButtonType.System) as UIButton
        buttonEdit.frame = CGRectMake(0, 0, 40, 40)
        buttonEdit.setTitle("Add", forState: UIControlState.Normal)
        buttonEdit.titleLabel!.font =  UIFont(name: "System", size: 17)
        buttonEdit.addTarget(self, action: "rightNavItemAddClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        self.navigationItem.setRightBarButtonItem(rightBarButtonItemEdit, animated: false)
    }
    
    
    func rightNavItemAddClick(sender:UIButton!)
    {
        print("rightNavItemAddClick")
        //self.navigationItem.rightBarButtonItem?.enabled=false
        var topic:NSString = (findtableViewCellByName("Topic") as! textFieldTableViewCell).inputTextField.text! as NSString
        var description:NSString = (findtableViewCellByName("Description") as! textViewTableViewCell).inputTextView.text as NSString
        
        self.imageStoreIdentifier = []
        for item in self.imageLocalIdentifier {
            self.retrieveImageWithIdentifer(item, completion: { (image) -> Void in
                let retreivedImage = image
                let imageData = UIImageJPEGRepresentation(retreivedImage!, 0.5)
                let rString = self.randomStringWithLength(8) as String
                let rName = rString+".jpg"
                self.imageStoreIdentifier.append(rName)
                self.uploadImageData(rName, imageData: imageData!)
            })
            print("afterappen\(self.imageStoreIdentifier)")
            //print(item)
        }
        //getImageDBName
        print("imageDBName\(self.imageStoreIdentifier)")
        

        let time = dispatch_time(dispatch_time_t(DISPATCH_TIME_NOW), 4 * Int64(NSEC_PER_SEC))
        dispatch_after(time, dispatch_get_main_queue()) {
            if (topic == "" || description == "" || self.isEmptyDescriptionTextview) {
                print("topic is empty")
                var alertView:UIAlertView = UIAlertView()
                alertView.title = "Add report failed!"
                alertView.message = "Please provide both topic and description"
                alertView.delegate = self
                alertView.addButtonWithTitle("OK")
                alertView.show()
            }
            else{
                
                var currentDatetimeNSDate = NSDate()
                var currentDatetime = DateTimeOperation.date2String(currentDatetimeNSDate, dateFormat: "yyyy-MM-dd hh:mm:ss")
                let piclink = self.imageStoreIdentifier.joinWithSeparator(";")
                print("piclinkjoinwith;\(piclink)")
                var teacherID = NSUserDefaults.standardUserDefaults().integerForKey("USERID")
                //print("topic:\(topic) ; plannedStartTime:\(formatedPlannedStartDatetime) ; plannedEndTime:\(formatedPlannedEndDatetime) ; teacherID:\(teacherID) ")
                let param = [
                    "topic" : topic,
                    "reportTime" : currentDatetime,
                    "description" : description,
                    "teacherID" : String(NSUserDefaults.standardUserDefaults().integerForKey("USERID")),
                    "piclink" : piclink,
                    "status" : "initiated"
                    ] as [String: AnyObject]
                //print("piclink is \(piclink)")
                sender.enabled = false
                Alamofire.request(.POST, "\(urlGlobalBase)jsonAddReport.php", parameters: param)
                    .validate()
                    .responseJSON {
                        response in
                        if(response.result.isSuccess) {
                            var res = response.result.value as! [String: AnyObject]
                            //println(request)
                            //println(response)
                            //println(data)
                            //println(error)
                            //print(res["error_message"])
                            var suc = res["success"] as! Int
                            if(suc==1) {
                                self.setSelectedMenu(0)
                                var alertView:UIAlertView = UIAlertView()
                                alertView.title = "Add report success!"
                                alertView.message = "New Report Added!"
                                //alertView.delegate = self
                                alertView.addButtonWithTitle("OK")
                                alertView.show()
                            }
                            else {
                                sender.enabled = true
                                var alertView:UIAlertView = UIAlertView()
                                alertView.title = "Add report failed!"
                                alertView.message = res["error_message"] as! String
                                // alertView.message = "Parameters Error, please try again"
                                //alertView.delegate = self
                                alertView.addButtonWithTitle("OK")
                                alertView.show()
                            }
                        }
                        else {
                            //println(request)
                            //println(response)
                            //println(data)
                            //println(error)
                            print(response.result.debugDescription);
                            sender.enabled = true
                            var alertView:UIAlertView = UIAlertView()
                            alertView.title = "Add report failed!"
                            alertView.message = "Server side error, please try again"
                            //alertView.delegate = self
                            alertView.addButtonWithTitle("OK")
                            alertView.show()
                        }
                }
                
                
            }
            
        }
        
    }
    
    func addLeftNavItemOnView()
    {
        let buttonEdit: UIButton = UIButton(type: UIButtonType.System) as UIButton
        buttonEdit.frame = CGRectMake(0, 0, 60, 40)
        buttonEdit.setTitle("Cancel", forState: UIControlState.Normal)
        buttonEdit.titleLabel!.font =  UIFont(name: "System", size: 17)
        buttonEdit.addTarget(self, action: "leftNavItemCancelClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let leftBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        self.navigationItem.setLeftBarButtonItem(leftBarButtonItemEdit, animated: false)
    }
    func leftNavItemCancelClick(sender:UIButton!)
    {
        print("leftNavItemCancelClick")
        setSelectedMenu(0)
    }
    
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
    // MARK: Table View Data Source
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reportControlerTypes.allValues.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let (cellType, cellName, height, selectedHeight): (String, String, Int, Int) = reportControlerTypes.allValues[indexPath.row]
        var cell:UITableViewCell
        switch (cellType){
        case "buttonTableViewCell" :
            cell = tableView.dequeueReusableCellWithIdentifier("buttonTableViewCell") as! buttonTableViewCell
            (cell as! buttonTableViewCell).textLabel?.text = cellName
            (cell as! buttonTableViewCell).textLabel?.textAlignment = NSTextAlignment.Center
            (cell as! buttonTableViewCell).layoutMargins = UIEdgeInsetsZero;
        case "textFieldTableViewCell" :
            cell = tableView.dequeueReusableCellWithIdentifier("textFieldTableViewCell") as! textFieldTableViewCell
            (cell as! textFieldTableViewCell).inputTextField.placeholder = cellName
            (cell as! textFieldTableViewCell).inputTextField.delegate = self;
            (cell as! textFieldTableViewCell).layoutMargins = UIEdgeInsetsZero;
        case "textViewTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("textViewTableViewCell") as! textViewTableViewCell
            (cell as! textViewTableViewCell).inputTextView.delegate = self;
        case "spaceSeparator":
            cell = tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
            cell.contentView.backgroundColor = tableSeparatorLightColor
        default:
            cell = tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
        }
        
        if (indexPath.row == reportControlerTypes.allValues.count - 1){
            setTableViewCellStyle4SeparatorLine(cell)
        }else{
            if(indexPath.row < reportControlerTypes.allValues.count - 1 && (cellType == "spaceSeparator" || reportControlerTypes.allValues[indexPath.row+1].0 == "spaceSeparator")){
                setTableViewCellStyle4SeparatorLine(cell)
            }
        }
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        return cell
        
    }
    
    
    func setTableViewCellStyle4SeparatorLine(cell: UITableViewCell){
        if cell.respondsToSelector("setSeparatorInset:") {
            cell.separatorInset.left = CGFloat(0.0)
        }
        if cell.respondsToSelector("setLayoutMargins:") {
            cell.layoutMargins.left = CGFloat(0.0)
        }
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if let selectedCellIndexPath = selectedCellIndexPath {
            if selectedCellIndexPath == indexPath {
                return CGFloat(reportControlerTypes.allValues[indexPath.row].3)
            }
        }
        return CGFloat(reportControlerTypes.allValues[indexPath.row].2)
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected cell #\(indexPath.row)")
        hideSideMenuView ()
        
        let (cellType, cellName, height, selectedHeight): (String, String, Int, Int) = reportControlerTypes.allValues[indexPath.row]
        switch (cellType){
            
        case "buttonTableViewCell":
            print("buttonTableViewCell")
            let assetType = DKImagePickerControllerAssetType.AllAssets
            let allowMultipleType = true
            let singleSelect = false
            let allowsLandscape = false
            if cellName == "Pick Photos" {
                print("PickPhotos")
                let sourceType: DKImagePickerControllerSourceType = [.Camera, .Photo]
                showImagePickerWithAssetType(
                    assetType,
                    allowMultipleType: allowMultipleType,
                    sourceType: sourceType,
                    allowsLandscape: allowsLandscape,
                    singleSelect: singleSelect
                )
            }
            else{
                print("TakePhotos")
                let sourceType: DKImagePickerControllerSourceType = .Camera
                showImagePickerWithAssetType(
                    assetType,
                    allowMultipleType: allowMultipleType,
                    sourceType: sourceType,
                    allowsLandscape: allowsLandscape,
                    singleSelect: singleSelect
                )
            }
        default:
            self.view.endEditing(true)
            //           forceHideDateTimePicker()
        }
        self.view.endEditing(true)
    }
    //MARK: Delegate textView in ViewControler
    
    func textViewDidEndEditing(textView: UITextView) {
        if (textView.text == "") {
            textView.text = "Description"
            textView.textColor = UIColor.lightGrayColor()
            isEmptyDescriptionTextview = true
        }
        textView.resignFirstResponder()
    }
    
    func textViewDidBeginEditing(textView: UITextView){
        hideSideMenuView()
        //forceHideDateTimePicker()
        if (textView.text == "Description"){
            textView.text = ""
            textView.textColor = UIColor.blackColor()
            isEmptyDescriptionTextview = false
        }
        let pointInTable = textView.convertPoint(textView.bounds.origin, toView: self.tableView)
        let currentCellIndexPathinTextEdit = self.tableView.indexPathForRowAtPoint(pointInTable)
        print("textView selected cell #\(currentCellIndexPathinTextEdit!.row)")
        
        if(isScollTableNeeded!){
            isScollTableNeeded = false
            tableView.scrollToRowAtIndexPath(currentCellIndexPathinTextEdit!, atScrollPosition: .Top, animated: true)
        }
        textView.becomeFirstResponder()
    }
    
    
    
    // MARK: Delegate textField in ViewController
    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        hideSideMenuView()
        // forceHideDateTimePicker()
        
        let pointInTable = textField.convertPoint(textField.bounds.origin, toView: self.tableView)
        let currentCellIndexPathinTextEdit = self.tableView.indexPathForRowAtPoint(pointInTable)
        print("textField selected cell #\(currentCellIndexPathinTextEdit!.row)")
        
        if(isScollTableNeeded!){
            isScollTableNeeded = false
            tableView.scrollToRowAtIndexPath(currentCellIndexPathinTextEdit!, atScrollPosition: .Top, animated: true)
        }
        textField.becomeFirstResponder()
    }
    
    
    //MARK: PopWindow
    
    /*
    @IBAction func addImage(sender: AnyObject) {
    var alertController = UIAlertController()
    var cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel, handler: nil)
    
    var takePhotoAction = UIAlertAction(title: "Take Photo", style: UIAlertActionStyle.Default, handler: nil)
    
    var ChoosePhotoAction = UIAlertAction(title: "Choose from Photos", style: UIAlertActionStyle.Default, handler: nil)
    alertController.addAction(cancelAction)
    alertController.addAction(takePhotoAction)
    alertController.addAction(ChoosePhotoAction)
    self.presentViewController(alertController, animated: true, completion: nil)
    }
    */
    // MARK: - UICollectionViewDataSource, UICollectionViewDelegate methods
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.assets?.count ?? 0
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let asset = self.assets![indexPath.row]
        var cell: UICollectionViewCell?
        var imageView: UIImageView?
        
        if asset.isVideo {
            cell = collectionView.dequeueReusableCellWithReuseIdentifier("CellVideo", forIndexPath: indexPath)
            imageView = cell?.contentView.viewWithTag(1) as? UIImageView
        } else {
            cell = collectionView.dequeueReusableCellWithReuseIdentifier("CellImage", forIndexPath: indexPath)
            imageView = cell?.contentView.viewWithTag(1) as? UIImageView
        }
        
        if let cell = cell, imageView = imageView {
            let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
            let tag = indexPath.row + 1
            cell.tag = tag
            asset.fetchImageWithSize(layout.itemSize.toPixel(), completeBlock: { image, info in
                if cell.tag == tag {
                    imageView.image = image
                }
            })
        }
        
        return cell!
    }
    
    
}
