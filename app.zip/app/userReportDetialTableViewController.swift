//
//  userReportDetialTableViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//

import UIKit
import Alamofire

class userReportDetialTableViewController: UITableViewController {
    
    var reportInfCell: reportInf = reportInf()
    var sections: [tableViewSection] = []
    let statusDictionary = ["initiated": "Published", "replied" : "Replied"]
    var piclinks: [String]=[]
    
    var userID: String = ""
    var role: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let prefs:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        self.userID = String(prefs.integerForKey("USERID") as Int)
        self.role = prefs.stringForKey("USERROLE")!
        self.title = "Report Details"
        
        self.navigationItem.backBarButtonItem?.title = "Cancel"
        
        initializeSession()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        // register customized Nib for tableViewCell
        let textFieldTableViewCellNib = UINib(nibName: "textFieldTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "textFieldTableViewCell")
        
        let textViewTableViewCellNib = UINib(nibName: "textViewTableViewCell", bundle: nil)
        tableView.registerNib(textViewTableViewCellNib, forCellReuseIdentifier: "textViewTableViewCell")
        
        let imageTableViewCellNib = UINib(nibName: "imageTableViewCell", bundle: nil)
        tableView.registerNib(imageTableViewCellNib, forCellReuseIdentifier: "imageTableViewCell")
        
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "emptyTableViewCell")
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
        refreshControlSetup()
        
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        getReportInf()
    }
    
    func refreshControlSetup(){
        let refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: "getReportInf", forControlEvents:.ValueChanged)
        refreshControl.backgroundColor = UIColor.lightGrayColor();
        let currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
        refreshControl.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
        self.refreshControl = refreshControl;
    }
    
    func getReportInf(){
        
        var param = ["reportID" : reportInfCell.reportID] as [String : AnyObject]
        Alamofire.request(.POST, "\(urlGlobalBase)jsonGetReportInfByID.php", parameters: param)
            .validate()
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var dic = response.result.value as! [String: AnyObject]
                    var res = dic["success"] as! Int
                    if(res == 1) { // network request success
                        self.reportInfCell = reportInf(reportID: pv(dic["reportID"] as? String), reportor: pv(dic["reportor"] as? String), topic: pv(dic["topic"] as? String), descriptions: pv(dic["description"] as? String), piclink: pv(dic["piclink"] as? String), reportTime: pv(dic["reportTime"] as? String), status: pv(dic["status"] as? String))
                        self.updateSession()
                        self.refreshControl!.endRefreshing()
                        self.tableView.reloadData()
                        
                    }
                    else {
                        self.navigationController?.dismissViewControllerAnimated(true, completion: nil)
                    }
                }
                else { // error on network connection
                    self.refreshControl!.endRefreshing()
                    var alert:UIAlertView = UIAlertView()
                    alert.title = "Network Connection Fail"
                    alert.message = "Cannot connect to the server, please try again"
                    //alert.delegate = self
                    alert.addButtonWithTitle("OK")
                    alert.show()
                }
        }
        self.refreshControl!.endRefreshing()
    }
    
    func updateSession() {
        
        let s_time:String = DateTimeOperation.date2String(DateTimeOperation.string2Date(reportInfCell.reportTime, dateFormat: "yyyy-MM-dd HH:mm:ss"), dateFormat: "yy-MM-dd EE hh:mm:ss a")
        sections[1].tableCellArray[0].cellTitle = "Report Time: \(s_time)"
        sections[1].tableCellArray[1].cellTitle = "\(statusDictionary[reportInfCell.status]!)     (" + (DateTimeOperation.string2Date(reportInfCell.reportTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).inBestDifferenceString + ")"
        
        // updateReservationInf(role == "teacher" ? classInfCell.studentID : classInfCell.teacherID)
        
        sections[3].tableCellArray[0].cellTitle = reportInfCell.descriptions
        
        self.piclinks = reportInfCell.piclink.componentsSeparatedByString(";")
        
        
    }
    
    func initializeSession(){
        // for section 0 -- Report Topic
        let topic = reportInfCell.topic;
        sections.append(tableViewSection(sectionTitle: "Report Topic", tableCellArray: [textFieldTableViewCellType(cellTitle: topic, cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44)]))
        
        // for section 1 -- Report Status
        var status = "\(statusDictionary[reportInfCell.status]!)     ("
        status += (DateTimeOperation.string2Date(reportInfCell.reportTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).inBestDifferenceString
        status += ")"
        let s_time:String = DateTimeOperation.date2String(DateTimeOperation.string2Date(reportInfCell.reportTime, dateFormat: "yyyy-MM-dd HH:mm:ss"), dateFormat: "yy-MM-dd EE hh:mm:ss a")
        sections.append(tableViewSection(sectionTitle: "Report status", tableCellArray: [
            textFieldTableViewCellType(cellTitle: "Report Time: \(s_time)", cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44),
            textFieldTableViewCellType(cellTitle: status, cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44),
            ]))
        // for Section 2 Report Images
        let piclink = reportInfCell.piclink
        sections.append(tableViewSection(sectionTitle: "Pictures", tableCellArray: [textFieldTableViewCellType(cellTitle: piclink, cellTableViewCellName: "imageTableViewCell", cellHeight: 150)]))
        // for Section 3 Report information
        let description = reportInfCell.descriptions
        sections.append(tableViewSection(sectionTitle: "Description", tableCellArray: [textViewTableViewCellType(cellTitle: description, cellTableViewCellName: "textViewTableViewCell", cellHeight: 160)]))
        //for Section 4 Response Report
        sections.append(tableViewSection(sectionTitle: "Report response", tableCellArray: [
            textFieldTableViewCellType(cellTitle: "Submit response", cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44),
            textFieldTableViewCellType(cellTitle: "View responses", cellTableViewCellName: "textFieldTableViewCell", cellHeight: 44),
            ]))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setTableViewCellStyle(cell: UITableViewCell){
        if cell.respondsToSelector("setSeparatorInset:") {
            cell.separatorInset.left = CGFloat(0.0)
        }
        if cell.respondsToSelector("setLayoutMargins:") {
            cell.layoutMargins.left = CGFloat(0.0)
        }
        cell.selectionStyle = UITableViewCellSelectionStyle.None
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return sections.count
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String {
        // do not display empty `Section`s
        if self.sections[section].getNumberOfCells() != 0 {
            return self.sections[section].getSectionTitle()
        }
        return ""
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return 40
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.sections[section].getNumberOfCells()
    }
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if self.sections[indexPath.section].getNumberOfCells() != 0 {
            return self.sections[indexPath.section].tableCellArray[indexPath.row].cellHeight
        }else{
            return 44
        }
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: UITableViewCell
        if(self.sections[indexPath.section].getNumberOfCells() == 0){
            return tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
        }
        
        switch self.sections[indexPath.section].getTableCellTypeAtIndex(indexPath.row){
        case "textFieldTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("textFieldTableViewCell") as! textFieldTableViewCell
            //print(indexPath.section)
            var currentCell : textFieldTableViewCellType = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! textFieldTableViewCellType
            (cell as! textFieldTableViewCell).inputTextField.enabled = currentCell.textFieldEnabled
            //currentCell.cellTitle="tste"
            (cell as! textFieldTableViewCell).inputTextField.text = currentCell.cellTitle
            
            if(indexPath.section == 4){
                (cell as! textFieldTableViewCell).inputTextField.textAlignment = NSTextAlignment.Center
            }
            break
        case "textViewTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("textViewTableViewCell") as! textViewTableViewCell
            var currentCell : textViewTableViewCellType = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! textViewTableViewCellType
            (cell as! textViewTableViewCell).inputTextView.editable = currentCell.textViewEditable
            (cell as! textViewTableViewCell).inputTextView.text = currentCell.cellTitle
            (cell as! textViewTableViewCell).inputTextView.textColor = UIColor.blackColor()
            break
        case "imageTableViewCell":
            cell = tableView.dequeueReusableCellWithIdentifier("imageTableViewCell") as! imageTableViewCell
            //var currentCell : imageCollectionViewCellType = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! imageCollectionViewCellType
            var imagelocationX = 20
            var myImage = UIImage()
            for item in self.piclinks{
                print(item)
                let url = NSURL(string: "\(urlPicsBase)/\(item)")
                print(url)
                if let data = NSData(contentsOfURL: url!){
                    myImage = UIImage(data: data)!
                }
                //myImage = UIImage(named: "background")!
                //myImage.set
                var myImageView = UIImageView(image: myImage)
                myImageView.frame = CGRect(x: imagelocationX, y: 0, width: 150, height: 150)
                (cell as! imageTableViewCell).imageCollectionView.addSubview(myImageView)
                imagelocationX = imagelocationX + 170
            }
            
            break
        default:
            return tableView.dequeueReusableCellWithIdentifier("emptyTableViewCell")! as UITableViewCell
        }
        setTableViewCellStyle(cell)
        return cell
    }
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        //only teacher can submit response from this view
        if(indexPath.section==4 && indexPath.row==0 && self.role == "teacher"){
            let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main",bundle: nil)
            let destViewController = mainStoryboard.instantiateViewControllerWithIdentifier("responseSubmitViewController") as UIViewController
            (destViewController as! responseSubmitViewController).userID = self.userID
            (destViewController as! responseSubmitViewController).reportID = self.reportInfCell.reportID
            (destViewController as! responseSubmitViewController).from = "T" //from teacher
            (destViewController as! responseSubmitViewController).reportTopic = self.reportInfCell.topic
            (destViewController as! responseSubmitViewController).preResponseID = "" // first response
            self.navigationController?.pushViewController(destViewController, animated: true)
        }//show response
        else if (indexPath.section==4 && indexPath.row==1 ){
            let destViewController:UIViewController = UIStoryboard(name: "Main",bundle: nil).instantiateViewControllerWithIdentifier("responseListViewController") as UIViewController
            (destViewController as! responseListViewController).reportID = self.reportInfCell.reportID
            (destViewController as! responseListViewController).reportTopic = self.reportInfCell.topic
            self.navigationController?.pushViewController(destViewController, animated: true)
        }
        
    }
    
    
}
