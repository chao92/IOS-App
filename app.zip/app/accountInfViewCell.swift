//
//  textFieldTableViewCell.swift
//  App
//
//  Created by Yuqi Zheng on 03/10/15.
//  Copyright (c) 2015 Yuqi Zheng. All rights reserved.
//

import UIKit

class accountInfViewCell: UITableViewCell, UITextViewDelegate {
    
   
    @IBOutlet weak var titleTextView: UITextView!
    @IBOutlet weak var detailTextView: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        titleTextView.resignFirstResponder()
        detailTextLabel?.resignFirstResponder()
        
    
        
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
//    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
//    {
//        textField.resignFirstResponder()
//        return true;
//    }
//
//    func textFieldDidBeginEditing(textField: UITextField) {
//        println("textField selected cell 1")
//        textField.becomeFirstResponder()
//    }

}
