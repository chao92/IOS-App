//
//  changAccountViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.

import UIKit
import Alamofire

class changeAccountViewController: UITableViewController, UITextFieldDelegate{
    
    var userID:String = ""
    var field:String = ""
    var defaultContent:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let doneButton: UIButton = UIButton(type: UIButtonType.System) as UIButton
        doneButton.frame = CGRectMake(0, 0, 50, 40)
        doneButton.setTitle("Done", forState: UIControlState.Normal)
        doneButton.titleLabel!.font =  UIFont(name: "System", size: 17)
        doneButton.addTarget(self, action: "rightNavItemClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let rightBarButtonItemBack: UIBarButtonItem = UIBarButtonItem(customView: doneButton)
        self.navigationItem.setRightBarButtonItem(rightBarButtonItemBack, animated: true)
        
        self.title = field
        //self.tableView
        
        let textFieldTableViewCellNib = UINib(nibName: "textFieldTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "textFieldTableViewCell")
        let textViewTableViewCellNib = UINib(nibName: "textViewTableViewCell", bundle: nil)
        tableView.registerNib(textViewTableViewCellNib, forCellReuseIdentifier: "textViewTableViewCell")
        self.tableView.sectionFooterHeight = CGFloat(10)
        self.tableView.sectionHeaderHeight = CGFloat(10)
        self.tableView.backgroundColor = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1.0)
        self.tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        
    }
    
    func rightNavItemClick(sender: UIButton!) {
        print("rightNavItemClicked")
        var value:String
        if(field == "intro") {
            value = (self.tableView.cellForRowAtIndexPath(NSIndexPath(forRow: 0, inSection: 0)) as! textViewTableViewCell).inputTextView.text as String
        }
        else {
            value = (self.tableView.cellForRowAtIndexPath(NSIndexPath(forRow: 0, inSection: 0)) as! textFieldTableViewCell).inputTextField.text! as String
        }
        let param = [
            "userID" : self.userID,
            "field"  : self.field,
            "value"  : value
        ]
        sender.enabled = false
        Alamofire.request(.POST, "\(urlGlobalBase)jsonUpdateUserInf.php", parameters: param)
            .validate()
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var dic = response.result.value as! [String: AnyObject]
                    var res = dic["success"] as! Int
                    if(res == 1) {
                        self.navigationController?.popViewControllerAnimated(true)
                    }
                    else {
                        sender.enabled = true
                        var alertView:UIAlertView = UIAlertView()
                        alertView.title = "Update Failed!"
                        alertView.message = "parameter error, please try again"
                        alertView.addButtonWithTitle("OK")
                        alertView.show()
                    }
                }
                else {
                    sender.enabled = true
                    var alertView:UIAlertView = UIAlertView()
                    alertView.title = "Update Failed!"
                    alertView.message = "Cannot connect to server!"
                    alertView.addButtonWithTitle("OK")
                    alertView.show()
                }
  
        }
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 0) {
            return 1
        }
        return 0
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if(self.field == "intro") {
            return 160
        }
        return 44
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if(field == "intro") {
            var cell = tableView.dequeueReusableCellWithIdentifier("textViewTableViewCell") as! textViewTableViewCell
            cell.inputTextView.text = self.defaultContent
            cell.inputTextView.textColor = UIColor.blackColor()
            return cell
        }
        var cell = tableView.dequeueReusableCellWithIdentifier("textFieldTableViewCell") as! textFieldTableViewCell
        switch (self.field) {
            case "firstName":
                cell.inputTextField.placeholder = "First Name"
            case "lastName":
                cell.inputTextField.placeholder = "Last Name"
            case "email":
                cell.inputTextField.placeholder = "Email Address"
            default:
                cell.inputTextField.placeholder = ""
        }
        cell.inputTextField.text = self.defaultContent
        cell.inputTextField.delegate = self
        
        return cell
    }
    
    
}
