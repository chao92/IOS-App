//
//  userAccountViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.

import UIKit
import Alamofire

class userAccountViewController: UITableViewController{

    
    @IBOutlet weak var tableview: UITableView!
    
    var userInfCell = userInf()
    var sections : [tableViewSection] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let dateTimePickTableViewCellNib = UINib(nibName: "imageLabelButtonTableViewCell", bundle: nil)
        tableView.registerNib(dateTimePickTableViewCellNib, forCellReuseIdentifier: "imageLabelButtonTableViewCell")
        let accountInfViewCellNib = UINib(nibName: "accountInfViewCell", bundle: nil)
        tableView.registerNib(accountInfViewCellNib, forCellReuseIdentifier: "accountInfViewCell")
        tableview.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        tableview.tableFooterView = UIView(frame:CGRectZero)
        tableview.layoutMargins = UIEdgeInsetsZero
        tableview.backgroundColor = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1.0)
        
        initialization()
        //updateInf()
        
        let refreshController = UIRefreshControl()
        refreshController.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshController.addTarget(self, action: "updateInf", forControlEvents:.ValueChanged)
        refreshController.backgroundColor = UIColor.lightGrayColor();
        let currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
        refreshController.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
        self.refreshControl = refreshController
        
        let backButton: UIButton = UIButton(type: UIButtonType.System) as UIButton
        backButton.frame = CGRectMake(0, 0, 50, 40)
        backButton.setTitle("Home", forState: UIControlState.Normal)
        backButton.titleLabel!.font =  UIFont(name: "System", size: 17)
        backButton.addTarget(self, action: "leftNavItemClick:", forControlEvents: UIControlEvents.TouchUpInside)
        let leftBarButtonItemBack: UIBarButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.setLeftBarButtonItem(leftBarButtonItemBack, animated: true)
        
        self.navigationItem.title = "Account"
    }
    
    func initialization() {
        // section 1
        self.sections.append(tableViewSection(sectionTitle: "User Account", tableCellArray: [imageLabelButtonTableViewCellType(myUserInf: userInfCell, myImage: UIImage(named: "unknowFace")!, cellTitle: userInfCell.username, cellTableViewCellName: "imageLabelButtonTableViewCell", cellHeight: 160, buttonTitle: "", buttonEnabled: false)]))
        
        // section 2
        sections.append(tableViewSection(sectionTitle: "User Information", tableCellArray: [
            textFieldTableViewCellType(cellTitle: "First Name", cellTableViewCellName: "firstNameCell", cellHeight: 44),
            textFieldTableViewCellType(cellTitle: "Last Name", cellTableViewCellName: "lastNameCell", cellHeight: 44),
            textFieldTableViewCellType(cellTitle: "Email ", cellTableViewCellName: "emailCell", cellHeight: 44),
            textFieldTableViewCellType(cellTitle: "Introduction", cellTableViewCellName: "introCell", cellHeight: 160)]))
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        updateInf()
    }
    
    func leftNavItemClick(sender: UIButton!) {
        setSelectedMenu(0)
    }
    
    func updateInf() {
        var userID:Int = NSUserDefaults.standardUserDefaults().integerForKey("USERID")
        
        Alamofire.request(.POST, "\(urlGlobalBase)jsonGetUserInf.php", parameters: ["userID" : userID] as [String:AnyObject])
            .validate()
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var dic = response.result.value as! [String: AnyObject]
                    var res = dic["success"] as! Int
                    if(res==1) {
                        print("User Info update success!")
                        var user = userInf(ID: pv(dic["ID"] as? String), username: pv(dic["username"] as? String), password: "", email: pv(dic["email"] as? String), piclink: pv(dic["piclink"] as? String), firstName: pv(dic["firstName"] as? String), lastName: pv(dic["lastName"] as? String), role: pv(dic["role"] as? String), intro: pv(dic["intro"] as? String))
                        var myImage = UIImage(named: "unknowFace")!
                        if user.ID != "" && user.piclink != "" {
                            let url = NSURL(string: "\(urlPicsBase)/\(user.piclink)")
                            if let data = NSData(contentsOfURL: url!){
                                myImage = UIImage(data: data)!
                            }
                        }
                        self.userInfCell = user
                        (self.sections[0].tableCellArray[0] as! imageLabelButtonTableViewCellType).myImage = myImage
                        self.refreshControl?.endRefreshing()
                        self.tableview.reloadData()
                    }
                    else {
                        self.refreshControl?.endRefreshing()
                        var alert:UIAlertView = UIAlertView()
                        alert.title = "User Info update failed"
                        alert.message = "Cannot retrive user information"
                            //alert.delegate = self
                        alert.addButtonWithTitle("OK")
                        alert.show()
                    }
                }
                else {
                    self.refreshControl?.endRefreshing()
                    var alert:UIAlertView = UIAlertView()
                    alert.title = "Network Connection Fail"
                    alert.message = "Server side error, please try again"
                        //alert.delegate = self
                    alert.addButtonWithTitle("OK")
                    alert.show()
                }
            }
        
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return sections.count
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String {
        // do not display empty `Section`s
        if self.sections[section].getNumberOfCells() != 0 {
            return self.sections[section].getSectionTitle()
        }
        return ""
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return 25
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.sections[section].getNumberOfCells();
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if self.sections[indexPath.section].getNumberOfCells() != 0 {
            return self.sections[indexPath.section].tableCellArray[indexPath.row].cellHeight
        }
        else{
            return 44
        }
    }
    
    // display of each cell
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: UITableViewCell = UITableViewCell()
        var sectionTitle: String = self.sections[indexPath.section].sectionTitle
        if(sectionTitle == "User Account") {
            cell = tableview.dequeueReusableCellWithIdentifier("imageLabelButtonTableViewCell") as! imageLabelButtonTableViewCell
            var currentCell = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! imageLabelButtonTableViewCellType
            (cell as! imageLabelButtonTableViewCell).faceImageView.image = currentCell.myImage
            (cell as! imageLabelButtonTableViewCell).nameLabel.text = self.userInfCell.username
            (cell as! imageLabelButtonTableViewCell).nameLabel.adjustsFontSizeToFitWidth = true
            (cell as! imageLabelButtonTableViewCell).moreInfLabel.text = "AS a \(self.userInfCell.role)"
            (cell as! imageLabelButtonTableViewCell).actionButton.setTitle("change password", forState: UIControlState.Normal)
            //var res:Bool = userInfCell.ID != ""
            (cell as! imageLabelButtonTableViewCell).actionButton.enabled = (userInfCell.ID != "")
            (cell as! imageLabelButtonTableViewCell).actionButton.addTarget(self, action: "changePWButtonTapped:", forControlEvents: UIControlEvents.TouchUpInside)
        }
        else if(sectionTitle == "User Information") {
            var currentCell = self.sections[indexPath.section].getTableCellAtIndex(indexPath.row) as! textFieldTableViewCellType
            cell = tableView.dequeueReusableCellWithIdentifier("accountInfViewCell") as! accountInfViewCell
            (cell as! accountInfViewCell).titleTextView.text = currentCell.cellTitle
            (cell as! accountInfViewCell).titleTextView.editable = false
            (cell as! accountInfViewCell).detailTextView.editable = false
            switch (indexPath.row) {
                case 0:
                    (cell as! accountInfViewCell).detailTextView.text = "\(userInfCell.firstName)"
                case 1:
                    (cell as! accountInfViewCell).detailTextView.text = "\(userInfCell.lastName)"
                case 2:
                    (cell as! accountInfViewCell).detailTextView.text = "\(userInfCell.email)"
                case 3:
                    (cell as! accountInfViewCell).detailTextView.text = "\(userInfCell.intro)"
                default:
                    (cell as! accountInfViewCell).detailTextView.text = "undefined"
            }
            
            //text = currentCell.cellTableViewCellName
        }
        else {
            return tableview.dequeueReusableCellWithIdentifier("cell")! as UITableViewCell
        }
        
        if cell.respondsToSelector("setSeparatorInset:") {
            cell.separatorInset.left = CGFloat(0.0)
        }
        if cell.respondsToSelector("setLayoutMargins:") {
            cell.layoutMargins.left = CGFloat(0.0)
        }
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        return cell
    }
    
    // action when tapped each cell
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected section #\(indexPath.section), cell #\(indexPath.row)!")
        hideSideMenuView ()
        if(indexPath.section == 1) {
            let destViewController = changeAccountViewController()
            destViewController.userID = userInfCell.ID
            switch (indexPath.row) {
            case 0:
                destViewController.field = "firstName"
                destViewController.defaultContent = userInfCell.firstName
            case 1:
                destViewController.field = "lastName"
                destViewController.defaultContent = userInfCell.lastName
            case 2:
                destViewController.field = "email"
                destViewController.defaultContent = userInfCell.email
            case 3:
                destViewController.field = "intro"
                destViewController.defaultContent = userInfCell.intro
            default:
                hideSideMenuView()
                destViewController.field = ""
                destViewController.defaultContent = ""
            }
            self.navigationItem.backBarButtonItem?.title = "Cancel"
            self.navigationController?.pushViewController(destViewController, animated: true)
        }
        else {
            hideSideMenuView()
        }
    }
    
    func changePWButtonTapped(sender: UIButton!) {
        print("change password button tapped")
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main",bundle: nil)
        let destViewController = mainStoryboard.instantiateViewControllerWithIdentifier("changePasswordVIewController") as UIViewController
        (destViewController as! changePasswordViewController).userID = userInfCell.ID
        self.navigationController?.pushViewController(destViewController, animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
