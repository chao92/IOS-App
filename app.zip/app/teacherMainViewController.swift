//
//  ViewController.swift
//  Integrity_APP
//
//  Created by chao on 1/29/16.
//  Copyright © 2016 Shuang Wang. All rights reserved.
//


import UIKit
import Alamofire

class teacherMainViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    
    @IBOutlet weak var tableView: UITableView!
    var reportSections : [reportListTableViewSection] = [];
    
    var refreshControl = UIRefreshControl()
    var teacherID:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // register customized Nib for tableViewCell
        let prefs:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        self.teacherID = String(prefs.integerForKey("USERID") as Int)
        
        initializeSections()
        let textFieldTableViewCellNib = UINib(nibName: "imageLabelTableViewCell", bundle: nil)
        tableView.registerNib(textFieldTableViewCellNib, forCellReuseIdentifier: "imageLabelTableViewCell")
        
        // Do any additional setup after loading the view.
        
        // set style for tableView
        tableView.tableFooterView = UIView(frame:CGRectZero)
        tableView.layoutMargins = UIEdgeInsetsZero
        refreshControlSetup()
    }
    
    override func viewDidAppear(animated: Bool) {
        //getNewClass()
        getNewReport()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        navigationController?.navigationBar.hidden = false
    }
    
    func refreshControlSetup(){
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: "getNewReport", forControlEvents:.ValueChanged)
        refreshControl.backgroundColor = UIColor.lightGrayColor();
        let currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss a")
        refreshControl.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
        self.tableView.addSubview(refreshControl)
    }
    
    func getNewReport(){
       // let currentTime = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd HH-mm-ss")
        let param = [
           // "role" : "teacher",
            "userID" : teacherID,
            "status" : "initiated"
         //   "time" : currentTime
            ] as [String:AnyObject]
        
        Alamofire.request(.POST, "\(urlGlobalBase)jsonGetUnprocessedReports.php", parameters: param)
            .responseJSON {
                response in
                if(response.result.isSuccess) {
                    var reports = response.result.value as! [[String:AnyObject]]
                    self.reportSections[0].reportInfArray.removeAll(keepCapacity: false)
                    for elem:[String:AnyObject] in reports {
                        self.reportSections[0].reportInfArray.append(reportInf(reportID: pv(elem["reportID"] as? String), reportor: pv(elem["reportor"] as? String), topic: pv(elem["topic"] as? String), descriptions: pv(elem["descriptions"] as? String), piclink: pv(elem["piclink"] as? String), reportTime: pv(elem["reportTime"] as? String), status: pv(elem["status"] as? String)))
                            /*append(reportInf(reportID: pv(elem["reportID"] as? String), reportor: pv(elem["reportor"] as? String), topic: pv(elem["topic"] as? String), description: pv(elem["description"] as? String), piclink: pv(elem["piclink"] as? String),
                            reportTime: pv(elem["reportTime"] as? String), status: pv(elem["status"] as? String),response: pv(elem["response"] as? String)))*/
                    }
                    self.reportSections[0].additionalReportInfArray = getAdditionalReportInf(self.reportSections[0].reportInfArray)
                   // self.sections[0].additionalClassInfArray = getAdditionalClassInf(self.sections[0].classInfArray)
                    var currentDateString = DateTimeOperation.date2String(NSDate(), dateFormat: "yyyy-MM-dd hh:mm:ss")
                    self.refreshControl.attributedTitle = NSAttributedString(string: "Last updated on \(currentDateString)")
                    self.refreshControl.endRefreshing()
                    self.tableView.reloadData()
                }
                else {
                    self.refreshControl.endRefreshing()
                    var alertView:UIAlertView = UIAlertView()
                    alertView.title = "Request upcoming classes failed!"
                    alertView.message = "Cannot get access to server"
                    alertView.delegate = self
                    alertView.addButtonWithTitle("OK")
                    alertView.show()
                }
        }
        
        //sections[0] = initializeSection0()
        //self.tableView.reloadData()
        self.refreshControl.endRefreshing()
    }
    func initializeSections(){
        reportSections.append(reportListTableViewSection(sectionTitle: "Unprocessed Reports"))
        //getNewClass()
        reportSections.append(initializeSectionTabs())
    }
    
    
    func initializeSectionTabs() -> reportListTableViewSection{
        let currentSection = reportListTableViewSection(sectionTitle: "All Reports")
        
        currentSection.addReportInf(reportInf(userID: self.teacherID, topic: reportStatusType.initiated.title))
        currentSection.addAdditionalReportInf(additionalReportInf(imageName: reportStatusType.initiated.imageName, imageTintColor: reportStatusType.initiated.color))
        
        currentSection.addReportInf(reportInf(userID: self.teacherID, topic: reportStatusType.replied.title))
        currentSection.addAdditionalReportInf(additionalReportInf(imageName: reportStatusType.replied.imageName, imageTintColor: reportStatusType.replied.color))
        currentSection.addReportInf(reportInf(userID: self.teacherID, topic: reportStatusType.finished.title))
        currentSection.addAdditionalReportInf(additionalReportInf(imageName: reportStatusType.finished.imageName, imageTintColor: reportStatusType.finished.color))
        currentSection.addReportInf(reportInf(userID: self.teacherID, topic: reportStatusType.allReports.title))
        currentSection.addAdditionalReportInf(additionalReportInf(imageName: reportStatusType.allReports.imageName, imageTintColor: reportStatusType.allReports.color))
        
        return currentSection
    }
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

//    @IBAction func backTapped(sender: AnyObject) {
//        //self.performSegueWithIdentifier("goto_homeFromTeacher", sender: self)
//        //self.navigationController?.navigationBarHidden = true
//        self.dismissViewControllerAnimated(true, completion: nil)
//        hideSideMenuView()
//    }
    
    @IBAction func toggleSideMenu(sender: AnyObject) {
        toggleSideMenuView()
    }
    
    // handle tabelview
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
            // Return the number of sections.
        return reportSections.count
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String {
            // do not display empty `Section`s
            if self.reportSections[section].getNumberOfReportInf() != 0 {
                return self.reportSections[section].getSectionTitle()
            }
            return ""
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return max(self.reportSections[section].getNumberOfReportInf(), 1)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 44
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell:imageLabelTableViewCell = tableView.dequeueReusableCellWithIdentifier("imageLabelTableViewCell") as! imageLabelTableViewCell
        if(self.reportSections[indexPath.section].reportInfArray.count == 0){
            cell.statusImageView.image = nil;
            cell.titleLabel.text = "No Unprocessed reports"
            cell.timeLabel.text = ""
            cell.accessoryType = UITableViewCellAccessoryType.None
            cell.selectionStyle = UITableViewCellSelectionStyle.None
            return cell
        }
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        var currentReportInf = self.reportSections[indexPath.section].getReportInfAtIndex(indexPath.row)
        var currentAdditionalReportInf = self.reportSections[indexPath.section].getAdditionalReportInfAtIndex(indexPath.row)
        
        
        cell.statusImageView.image = UIImage(named: currentAdditionalReportInf.imageName)?.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate);
        cell.statusImageView.tintColor = currentAdditionalReportInf.imageTintColor
        cell.titleLabel.text = currentReportInf.topic
        
        if(currentReportInf.reportTime != ""){
            cell.timeLabel.text = (DateTimeOperation.string2Date(currentReportInf.reportTime, dateFormat: "yyyy-MM-dd HH:mm:ss") - NSDate()).inBestDifferenceString
        }
        else {
            cell.timeLabel.text = ""
        }  

        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("You selected section #\(indexPath.section) and cell #\(indexPath.row)")
        hideSideMenuView ()
        
        switch (indexPath.section) {
        case 0: // getcurrent class
            if(self.reportSections[indexPath.section].reportInfArray.count == 0){
                return
            }
            let secondTableViewController = userReportDetialTableViewController()
            secondTableViewController.reportInfCell = reportSections[indexPath.section].reportInfArray[indexPath.row]
            secondTableViewController.title = reportSections[indexPath.section].reportInfArray[indexPath.row].topic
            //navigationItem.backBarButtonItem?.title = "Back"
            navigationController?.pushViewController(secondTableViewController, animated: true )
        case 1: // for all reports
            let secondTableViewController = allReportTableViewController()
            let reportStatus = reportStatusType.dictionary[reportSections[indexPath.section].reportInfArray[indexPath.row].topic]!
            secondTableViewController.role = "student"
            secondTableViewController.userID = teacherID
            if(reportSections[indexPath.section].reportInfArray[indexPath.row].topic == "Published Reports"){
                secondTableViewController.reportStatus = reportStatus
                secondTableViewController.viewMode = 0
            }else if (reportSections[indexPath.section].reportInfArray[indexPath.row].topic == "Replied Reports"){
                secondTableViewController.reportStatus = reportStatus
                secondTableViewController.viewMode = 2
            }
            else if(reportSections[indexPath.section].reportInfArray[indexPath.row].topic == "Archieved Reports"){
                secondTableViewController.reportStatus = reportStatus
                secondTableViewController.viewMode = 1
            }
            else{//.topic=="All Reports" all reports
                secondTableViewController.reportStatus = reportStatus
                secondTableViewController.viewMode = 3
            }
            //secondTableViewController.sqlCondition = sqlCondition
            secondTableViewController.title = reportSections[indexPath.section].reportInfArray[indexPath.row].topic
            //navigationItem.backBarButtonItem?.title = "Back"
            navigationController?.pushViewController(secondTableViewController, animated: true)
        default:
            break
        }
    }
    
}

